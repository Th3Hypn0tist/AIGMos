from __future__ import annotations

from typing import Any

from .common import coerce_jsonish_list
from .errors import QCallError
from .profile import read_q_override, resolve_think_value


_Q_SAMPLER_DEFAULTS = {
    "temperature": 0.6,
    "top_k": 20,
    "top_p": 0.95,
    "repeat_penalty": 1.0,
}

_Q_STOP_DEFAULTS = ["<|im_start|>", "<|im_end|>"]


def ensure_q_sampler_state(state, profile_name: str = "default") -> None:
    return None


def _coerce_sampler_number(raw: Any, *, key: str, as_int: bool):
    if raw in (None, ""):
        return None
    try:
        number = int(raw) if as_int else float(raw)
    except Exception as exc:
        raise QCallError(f"invalid sampler value for {key}: {raw}") from exc
    if key == "top_k" and number < 0:
        raise QCallError("invalid sampler value for top_k: must be >= 0")
    if key in ("temperature", "top_p", "repeat_penalty") and float(number) < 0:
        raise QCallError(f"invalid sampler value for {key}: must be >= 0")
    return number


def resolve_q_sampler_values(profile: dict, state, profile_name: str) -> dict[str, Any]:
    values: dict[str, Any] = {}
    runtime_overlay_applied = bool(profile.get("__q_runtime_overlay_applied__"))

    q_overrides = {
        "temperature": None if runtime_overlay_applied else read_q_override(state, profile_name, "temperature"),
        "heat": None if runtime_overlay_applied else read_q_override(state, profile_name, "heat"),
        "top_k": None if runtime_overlay_applied else read_q_override(state, profile_name, "top_k"),
        "top_p": None if runtime_overlay_applied else read_q_override(state, profile_name, "top_p"),
        "repeat_penalty": None if runtime_overlay_applied else read_q_override(state, profile_name, "repeat_penalty"),
        "stop": None if runtime_overlay_applied else read_q_override(state, profile_name, "stop"),
        "max_tokens": None if runtime_overlay_applied else read_q_override(state, profile_name, "max_tokens"),
        "seed": None if runtime_overlay_applied else read_q_override(state, profile_name, "seed"),
        "num_ctx": None if runtime_overlay_applied else read_q_override(state, profile_name, "num_ctx"),
    }

    numeric_fields = (("temperature", False), ("top_k", True), ("top_p", False), ("repeat_penalty", False))
    for key, as_int in numeric_fields:
        raw = q_overrides.get(key)
        if key == "temperature" and raw in (None, ""):
            raw = q_overrides.get("heat")
        if raw in (None, ""):
            raw = profile.get(key)
        if raw in (None, "") and key == "temperature":
            raw = profile.get("heat")
        if raw in (None, ""):
            raw = _Q_SAMPLER_DEFAULTS[key]
        coerced = _coerce_sampler_number(raw, key=key, as_int=as_int)
        if coerced is not None:
            values[key] = coerced

    stop_values = coerce_jsonish_list(q_overrides.get("stop"))
    if not stop_values:
        raw_stop = profile.get("stop")
        if isinstance(raw_stop, str):
            raw_stop = raw_stop.strip()
            if raw_stop:
                stop_values = coerce_jsonish_list(raw_stop)
        elif isinstance(raw_stop, (list, tuple)):
            stop_values = [str(item) for item in raw_stop if str(item)]
    if not stop_values:
        stop_values = list(_Q_STOP_DEFAULTS)
    values["stop"] = stop_values

    for extra_key in ("max_tokens", "seed", "num_ctx"):
        extra_value = q_overrides.get(extra_key)
        if extra_value in (None, ""):
            extra_value = profile.get(extra_key)
        if extra_value not in (None, ""):
            values[extra_key] = extra_value

    think_value = resolve_think_value(profile, None if runtime_overlay_applied else state, profile_name)
    if think_value is not None:
        values["think"] = think_value

    return values


def get_q_sampler_state(state, profile_name: str = "default") -> dict[str, Any]:
    values = dict(_Q_SAMPLER_DEFAULTS)
    values["stop"] = list(_Q_STOP_DEFAULTS)
    return values


__all__ = [
    "ensure_q_sampler_state",
    "get_q_sampler_state",
    "resolve_q_sampler_values",
]
