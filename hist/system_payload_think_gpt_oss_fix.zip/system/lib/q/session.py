from __future__ import annotations

from typing import Any, Callable

from .errors import QCallError
from .live import chunk_q_live, done_q_live, fail_q_live, open_q_live
from .profile import get_profile, resolve_profile_name, resolve_think_value
from .prompt import expand_prompt_symbols
from .providers import decode_qc_output, profile_has_stream, extract_chat, strip_inline_think_markup
from .roles import normalize_role_name, resolve_role_value
from .state import merge_thinking_stream, append_response_stream, write_text_symbol, load_chat, load_role, open_chat_entry, save_chat, write_chat_entry
from .symbols import (
    chat_symbol_for_runtime,
    q_runtime_root_for_parser,
    response_symbol_for_runtime,
    role_symbol_for_runtime,
    system_prompt_symbol_for_runtime,
    thinking_symbol_for_runtime,
)
from .transport import call_profile, stream_profile
from .common import coerce_bool, normalize_think_value, think_is_enabled, read_state_value


def _coerce_toggle(value: Any, default: bool = True) -> bool:
    raw = coerce_bool(value, None)
    if raw is None:
        return bool(default)
    return bool(raw)


def _runtime_role_snapshot(state, q_root: str) -> dict[str, Any]:
    if not q_root:
        return {}
    role_branch = read_state_value(state, f'{q_root}:role', {})
    if isinstance(role_branch, dict):
        return dict(role_branch)
    return {}


def _runtime_role_value(state, q_root: str, key: str, default: Any = None) -> Any:
    value = read_state_value(state, f'{q_root}:role:{key}', None)
    return default if value in (None, '') else value


def _resolve_q_effective_profile(base_profile: dict[str, Any], state, q_root: str) -> dict[str, Any]:
    effective = dict(base_profile or {})
    runtime_role = _runtime_role_snapshot(state, q_root)
    for key, value in runtime_role.items():
        if key in {'title', 'system_prompt'}:
            continue
        if value in (None, ''):
            continue
        effective[key] = value
    return effective


def _resolve_think_from_runtime_or_profile(profile: dict[str, Any], state, q_root: str, profile_name: str):
    return resolve_think_value(profile, None, profile_name)


def _resolve_stream_enabled(profile: dict[str, Any], state, q_root: str) -> bool:
    return bool(profile_has_stream(profile))


def _resolve_show_thinking(state, q_root: str) -> bool:
    runtime_value = _runtime_role_value(state, q_root, 'view_thinking', None)
    return _coerce_toggle(runtime_value, True)


def prepare_q_session(parser, command_token: str, prompt: str) -> dict:
    profile_name = resolve_profile_name(parser, command_token, 'q')
    profile = get_profile(parser, profile_name)

    q_state_root = q_runtime_root_for_parser(parser)
    if not q_state_root:
        raise QCallError('q requires an active q runtime root')
    chat_symbol = chat_symbol_for_runtime(parser, profile_name)
    role_symbol = role_symbol_for_runtime(parser, profile_name)
    system_prompt_symbol = system_prompt_symbol_for_runtime(parser, profile_name)
    if not chat_symbol or not role_symbol or not system_prompt_symbol:
        raise QCallError('q runtime symbols missing for active q root')
    chat = load_chat(parser.state, chat_symbol)
    effective_profile = _resolve_q_effective_profile(profile, parser.state, q_state_root)
    effective_profile['__q_runtime_overlay_applied__'] = True
    effective_profile['__q_runtime_root__'] = q_state_root
    role = load_role(parser.state, system_prompt_symbol)
    expanded_prompt = expand_prompt_symbols(parser, prompt)
    think_value = _resolve_think_from_runtime_or_profile(effective_profile, parser.state, q_state_root, profile_name)
    show_thinking = _resolve_show_thinking(parser.state, q_state_root)
    stream_enabled = _resolve_stream_enabled(effective_profile, parser.state, q_state_root)
    role_ref = str(read_state_value(parser.state, role_symbol, '') or '')

    return {
        'profile_name': profile_name,
        'profile': effective_profile,
        'base_profile': profile,
        'state': parser.state,
        'q_state_root': q_state_root,
        'chat_symbol': chat_symbol,
        'role_symbol': role_symbol,
        'role_ref': role_ref,
        'system_prompt_symbol': system_prompt_symbol,
        'prompt': prompt,
        'expanded_prompt': expanded_prompt,
        'role': role,
        'chat': chat,
        'stream_enabled': 1 if stream_enabled else 0,
        'think_value': think_value,
        'show_thinking': show_thinking,
    }


def run_nonstream_session(session: dict) -> str:
    payload = call_profile(
        session['profile'],
        session['expanded_prompt'],
        role=session['role'],
        chat=session['chat'],
        state=session.get('state'),
        profile_name=session.get('profile_name', 'default'),
        think_value=session.get('think_value'),
    )
    return strip_inline_think_markup(extract_chat(payload, session['profile'].get('chat_message_tag')))


def q_chat(parser, command_token: str, prompt: str, on_chunk: Callable[[str, str, str, str], None] | None = None, on_done: Callable[[str, str, str], None] | None = None) -> dict:
    session = prepare_q_session(parser, command_token, prompt)
    profile_name = session['profile_name']
    chat_symbol = session['chat_symbol']
    response_symbol = response_symbol_for_runtime(parser, profile_name)
    thinking_symbol = thinking_symbol_for_runtime(parser, profile_name)
    think_value = session.get('think_value')
    thinking_enabled = think_is_enabled(think_value, None)
    show_thinking = bool(session.get('show_thinking', True))

    write_text_symbol(parser.state, response_symbol, '', 'response_reset')
    write_text_symbol(parser.state, thinking_symbol, '', 'thinking_reset')

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key='', prompt=prompt, response='', thinking='')

    if not session['stream_enabled']:
        final_text = run_nonstream_session(session)
        chat_log = dict(session['chat'])
        key = str(max([int(k) for k in chat_log.keys() if str(k).isdigit()] + [0]) + 1)
        chat_log[key] = {'prompt': prompt, 'response': final_text, 'done': 1}
        save_chat(parser.state, chat_symbol, chat_log)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}

    key = open_chat_entry(parser.state, chat_symbol, prompt)
    final_text = ''
    final_thinking = ''
    last_written_response = ''

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response='', thinking='')

    try:
        for event in stream_profile(session['profile'], session['expanded_prompt'], role=session['role'], chat=session['chat'], state=session.get('state'), profile_name=session.get('profile_name', 'default'), think_value=session.get('think_value')):
            raw_thinking_chunk = strip_inline_think_markup(event.get('thinking') or '')
            content_chunk = strip_inline_think_markup(event.get('content') or '')
            event_done = 1 if int(event.get('done') or 0) == 1 else 0

            thinking_chunk = raw_thinking_chunk
            if thinking_enabled is False:
                thinking_chunk = ''

            if thinking_chunk:
                final_thinking = merge_thinking_stream(final_thinking, thinking_chunk)
            if content_chunk:
                final_text = append_response_stream(final_text, content_chunk)

            visible_response = strip_inline_think_markup(final_text)
            visible_thinking = ''
            if show_thinking and not visible_response and final_thinking:
                visible_thinking = final_thinking

            write_text_symbol(parser.state, response_symbol, visible_response, 'response_partial')
            write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
            if visible_response != last_written_response:
                write_chat_entry(parser.state, chat_symbol, key, prompt, visible_response, done=0)
                last_written_response = visible_response
            chunk_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=visible_response, thinking=visible_thinking)

            if callable(on_chunk) and (thinking_chunk or content_chunk):
                on_chunk(content_chunk or thinking_chunk, visible_response, chat_symbol, key)

            if event_done == 1:
                break

        final_text = strip_inline_think_markup(final_text)
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')

        if callable(on_done):
            on_done(final_text, chat_symbol, key)

    except Exception:
        final_text = strip_inline_think_markup(final_text)
        visible_thinking = ''
        if show_thinking and not final_text and final_thinking:
            visible_thinking = final_thinking
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=0)
        write_text_symbol(parser.state, response_symbol, final_text, 'response_partial')
        write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
        fail_q_live(parser, 'q stream interrupted', profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking=visible_thinking)
        raise

    return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}


def _parse_qc_command_token(command_token: str) -> tuple[str, str]:
    token = str(command_token or '').strip()
    if token == 'qc':
        return 'default', ''
    if not token.startswith('qc'):
        raise QCallError('usage: qc[.<profile>][.r.<role>] <output> <prompt...>')
    tail = token[2:]
    if not tail:
        return 'default', ''
    if not tail.startswith('.'):
        raise QCallError('usage: qc[.<profile>][.r.<role>] <output> <prompt...>')
    tail = tail[1:]
    if tail.startswith('r.'):
        return 'default', normalize_role_name(tail[2:])
    if '.r.' in tail:
        profile_name, role_name = tail.split('.r.', 1)
        return profile_name or 'default', normalize_role_name(role_name)
    return tail or 'default', ''


def qc_raw(parser, command_token: str, *args: Any) -> dict:
    flat_args: list[Any] = []
    for item in args:
        if isinstance(item, (list, tuple)):
            flat_args.extend(item)
        else:
            flat_args.append(item)
    if not flat_args:
        raise QCallError('qc requires prompt')
    prompt = ' '.join(str(x) for x in flat_args).strip()
    if not prompt:
        raise QCallError('qc requires prompt')

    profile_name, role_name = _parse_qc_command_token(command_token)
    profile = get_profile(parser, profile_name)

    effective_profile = dict(profile)
    effective_profile['__q_runtime_overlay_applied__'] = True
    effective_profile['__q_runtime_root__'] = ''
    role_prompt = ''
    think_value = resolve_think_value(effective_profile, None, profile_name)
    if role_name:
        role_info = resolve_role_value(parser.state, role_name)
        if str(role_info.get('kind') or '') != 'preset':
            raise QCallError(f'role preset not found: {role_name}')
        role_prompt = str(role_info.get('system_prompt') or '')
        for key, value in dict(role_info.get('profile_overrides') or {}).items():
            effective_profile[key] = value
        if 'think' in dict(role_info.get('profile_overrides') or {}):
            think_value = normalize_think_value(role_info['profile_overrides'].get('think'), think_value)

    payload = call_profile(effective_profile, expand_prompt_symbols(parser, prompt), role=role_prompt, chat={}, state=parser.state, profile_name=profile_name, think_value=think_value)
    output = decode_qc_output(payload, effective_profile.get('chat_message_tag'))
    return {'profile': profile_name, 'output': output, 'decoded': output}


__all__ = [
    'prepare_q_session',
    'run_nonstream_session',
    'q_chat',
    'qc_raw',
]
