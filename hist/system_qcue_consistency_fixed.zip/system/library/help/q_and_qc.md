# q and qc

## Summary

`q` and `qc` are AI modules inside AIGMos.
They are not the definition of AIGMos itself.

## q

`q` is the stateful chat-style module.
Typical runtime data lives under the active `|` instance.

Examples:

```text
|HELP:q:ch
|HELP:q:role:think
|HELP:q:role:stream
|HELP:q:role:view_thinking
```

## qc

`qc` is the more structured single-call module.
Use it when you want decoded / targeted output rather than a chat history loop.

## Why both exist

- `q` fits conversational or iterative operator interaction
- `qc` fits more constrained structured tasks

## Do not overdefine the system by these modules

Correct:

```text
AIGMos contains q and qc.
```

Incorrect:

```text
AIGMos is mainly a q/qc chat framework.
```

## q queue truth

`q` scheduling data is canonical under `#SYSTEM:Qcue`.

Rules:

- per alias queue is FIFO
- per q root there is one active slot
- queue states are `waiting`, `running`, `done`, `error`
- runtime lock/wake/thread state is not canonical queue data

Useful inspection targets:

```text
cat #SYSTEM:Qcue
#SYSTEM:Qcue:aliases:<alias>:queue
#SYSTEM:Qcue:aliases:<alias>:active
#SYSTEM:Qcue:aliases:<alias>:history
```


## Q cue canonical state

- `#SYSTEM:Qcue` is the canonical queue-data store.
- Per-alias queue order, active-slot ownership, and history live under `#SYSTEM:Qcue`.
- Root-local q fields such as `|<q_root>:prompt`, `:response`, `:thinking_text`, `:error`, and `:status` are active render-cache fields only.
- Queued items must not overwrite active q-root live fields before they are actually started.
