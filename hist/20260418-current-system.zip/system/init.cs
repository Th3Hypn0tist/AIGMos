reload help
reload roles
reload prompts
reload routines
new |Q /q
new |HELP /help
new |QQ /q
new |HH /help
new |QMON /qmon
bind alt-1 |CS
bind alt-2 |Q
bind alt-3 |HELP
bind alt-4 |QQ
bind alt-5 |HH
bind alt-6 |QMON
