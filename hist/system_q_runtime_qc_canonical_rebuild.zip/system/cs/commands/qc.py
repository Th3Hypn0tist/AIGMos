from __future__ import annotations

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse


from system.cs.command_args import parse_command_output_tail_raw
from system.lib.q.errors import QCallError
from system.lib.q.session import qc_raw
from system.state.api import write_value


command = "qc"
help_short = 'qc[.<profile>][.r.<role>] <output> <prompt...>'
help_full = """stateless structured q call

rules:
- output target is explicit
- no chat history is written
- accepted decoded output types: string, list, dict
- returns [ok] after writing decoded output to target

examples:
  qc #out hello
  qc.coder #out $prompt
  qc.r.system/help #out hello
"""

def _qc_writer_name(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    return f"q:{clean}"


def _write_qc_output(parser, output_symbol: str, payload, profile_name: str) -> None:
    out = write_value(
        parser.state,
        output_symbol,
        payload,
        writer=_qc_writer_name(profile_name),
        op="qc",
    )
    if out.get("error"):
        raise QCallError(str(out["error"]))


def handler(line: str, parser) -> HandlerResponse:
    try:
        command_token, output_symbol, prompt = parse_command_output_tail_raw(
            line,
            usage="usage: qc[.<profile>] <output> <prompt...>",
            label="qc",
        )
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)

    if not isinstance(output_symbol, str) or output_symbol[:1] not in "$#&":
        return HandlerResponse(error=str('qc output must start with $, # or &' or ""), force_render=True)

    try:
        out = qc_raw(parser, command_token, prompt)
        _write_qc_output(
            parser,
            output_symbol,
            out["decoded"],
            out.get("profile", "default"),
        )
    except QCallError as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)

    return HandlerResponse(buffer_output=str("[ok]" or ""), force_render=True)

def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )

