from __future__ import annotations

from typing import Any

from . import definitions
from . import state as layout_state
from . import store as layout_store
from .bindings import create_layout_binding
from .focus import switch_active
from .instances import _runtime, _default_startup_layout_handle, create_instance, _write_meta_for_instance
from .lib.handles import normalize_handle, route_name as _route_name, binding_name as _binding_name


def _active_handle_for_store(ctx) -> str:
    runtime = _runtime(ctx)
    active = str(runtime.get("active_handle") or "").strip()
    if active:
        return active
    persisted = layout_state.get_meta(ctx, "|LAYOUT", "active_handle", "")
    return str(persisted or "").strip()


def _layout_store_payload(ctx) -> dict[str, Any]:
    runtime = _runtime(ctx)
    bindings: dict[str, Any] = {}
    for handle, binding in dict(runtime.get("bindings") or {}).items():
        clean_handle = str(handle or "").strip()
        if not clean_handle:
            continue
        item = dict(binding or {})
        bindings[clean_handle] = {
            "route_name": _route_name(item.get("route_name") or _binding_name(clean_handle)),
            "tree": item.get("tree"),
            "specs": list(item.get("specs") or []),
        }

    instances: dict[str, Any] = {}
    for handle, instance in dict(runtime.get("instances") or {}).items():
        if instance is None:
            continue
        clean_handle = str(getattr(instance, "handle", handle) or "").strip()
        if not clean_handle:
            continue
        parent_layout = str(getattr(instance, "parent_layout", "") or "").strip()
        if parent_layout:
            continue
        instances[clean_handle] = {
            "module": str(getattr(instance, "MODULE", "") or "").strip().lower(),
            "config": dict(getattr(instance, "config", {}) or {}),
            "title": str(getattr(instance, "title", "") or ""),
            "prompt": str(getattr(instance, "prompt", "") or ""),
        }

    return {
        "version": layout_store.STORE_VERSION,
        "active_handle": _active_handle_for_store(ctx),
        "bindings": bindings,
        "instances": instances,
    }


def _persist_runtime(ctx) -> None:
    runtime = _runtime(ctx)
    if runtime.get("_restoring_store"):
        return
    if int(runtime.get("_persist_suspended") or 0) > 0:
        return
    state = ctx.get("state") if isinstance(ctx, dict) else None
    if state is None:
        return
    layout_store.save_layout_store(state, _layout_store_payload(ctx))


def _binding_specs_from_store(route_name: str, item: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    tree = item.get("tree")
    specs = item.get("specs")
    if isinstance(specs, list) and specs:
        return list(specs), tree if isinstance(tree, dict) else tree
    if isinstance(tree, dict):
        try:
            return list(definitions.flatten_module_specs(tree)), tree
        except Exception:
            pass
    parsed = definitions.parse_layout_definition(_route_name(route_name))
    return list(definitions.flatten_module_specs(parsed)), parsed


def _restore_runtime_from_store(ctx) -> None:
    runtime = _runtime(ctx)
    state = ctx.get("state") if isinstance(ctx, dict) else None
    if state is None:
        return
    payload = layout_store.load_layout_store(state)
    if not isinstance(payload, dict):
        payload = {}

    bindings = payload.get("bindings") if isinstance(payload.get("bindings"), dict) else {}
    instances = payload.get("instances") if isinstance(payload.get("instances"), dict) else {}

    runtime["_restoring_store"] = True
    runtime["_persist_suspended"] = int(runtime.get("_persist_suspended") or 0) + 1
    try:
        for handle in sorted(bindings.keys()):
            item = bindings.get(handle)
            if not isinstance(item, dict):
                continue
            clean_handle = normalize_handle(handle)
            route_name = _route_name(item.get("route_name") or _binding_name(clean_handle))
            specs, tree = _binding_specs_from_store(route_name, item)
            create_layout_binding(ctx, clean_handle, route_name, specs, tree=tree)

        for handle in sorted(instances.keys()):
            if handle in runtime.get("bindings", {}):
                continue
            item = instances.get(handle)
            if not isinstance(item, dict):
                continue
            module_name = str(item.get("module") or "").strip().lower()
            if not module_name:
                continue
            clean_handle = normalize_handle(handle)
            inst = create_instance(ctx, module_name, clean_handle, dict(item.get("config") or {}), start=True)
            title = str(item.get("title") or "").strip()
            prompt = str(item.get("prompt") or "").strip()
            if title:
                inst.title = title
            if prompt:
                inst.prompt = prompt
            _write_meta_for_instance(ctx, inst)
    finally:
        runtime["_persist_suspended"] = max(0, int(runtime.get("_persist_suspended") or 0) - 1)
        runtime["_restoring_store"] = False

    active = str(payload.get("active_handle") or layout_state.get_meta(ctx, "|LAYOUT", "active_handle", "") or "").strip()
    if active:
        try:
            runtime["active_handle"] = normalize_handle(active)
        except Exception:
            runtime["active_handle"] = ""


def reload_layout(ctx) -> list[str]:
    from .focus import bootstrap
    from .instances import ensure_instance

    runtime = _runtime(ctx)
    active = runtime.get("active_handle") or _default_startup_layout_handle()
    runtime['bindings'] = {}
    runtime['instances'] = {}
    runtime['focus'] = {}
    runtime['bootstrapped'] = False
    if isinstance(ctx, dict):
        ctx['_layout_frame_cache'] = {}
        ctx['layout_ui'] = {'editors': {}, 'modules': {}}
        flags = ctx.setdefault('flags', {})
        flags['layout_dirty_modules'] = set()
        flags['layout_hard_redraw'] = True
        flags['force_render'] = True
    bootstrap(ctx)
    if active:
        try:
            ensure_instance(ctx, active)
            switch_active(ctx, active)
        except Exception:
            switch_active(ctx, _default_startup_layout_handle())
    return sorted([binding["route_name"] for binding in runtime["bindings"].values()])
