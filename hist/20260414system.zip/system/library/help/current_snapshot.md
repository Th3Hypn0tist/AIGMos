# Current snapshot

AIGMos currently uses:

- `|` for layout instance handles
- lowercase `q` and `qc`
- `new |<instance> /<module-or-layout>` for layout creation
- bound layouts from `.tmpl` files
- q-aware layouts and read-only q monitoring through `qmon`

Important rule:

- `|instance` is the runtime identity
- `<layout title="...">` provides the default display title
