# AIGMos help index

This folder is the runtime-side help reference bundle.

Use it together with:

- `docs/help/`
- `system/library/layout/help.tmpl`
- `system/library/prompts/explanations/help`

Quick start:

```text
new |HELP /help
```

Main topics:

- current snapshot overview
- command surface
- layouts and help
- q and qc
- troubleshooting
