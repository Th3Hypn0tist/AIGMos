from __future__ import annotations

from typing import Any

from .common import read_state_value

_ROLE_PROFILE_KEYS = (
    "temperature",
    "top_k",
    "top_p",
    "repeat_penalty",
    "stop",
    "max_tokens",
    "seed",
    "num_ctx",
    "thinking",
    "think",
)


def normalize_role_ref(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    if raw.startswith("#ROLES:"):
        body = raw[len("#ROLES:"):].strip()
    else:
        body = raw.strip("/").replace("/", ":")
    if not body:
        return ""
    if not body.endswith('.role'):
        body = f"{body}.role"
    return f"#ROLES:{body}"


def read_role_preset(state, value: Any) -> dict[str, Any]:
    symbol = normalize_role_ref(value)
    if not symbol:
        return {}
    payload = read_state_value(state, symbol, None)
    return dict(payload) if isinstance(payload, dict) else {}


def resolve_role_value(state, value: Any) -> dict[str, Any]:
    raw = str(value or "").strip()
    symbol = normalize_role_ref(raw)
    if symbol:
        preset = read_role_preset(state, symbol)
        if preset:
            role_text = str(preset.get('system') or '')
            profile_overrides = {
                key: preset[key]
                for key in _ROLE_PROFILE_KEYS
                if key in preset and preset.get(key) not in (None, "")
            }
            return {
                'kind': 'preset',
                'role_ref': symbol,
                'role_text': role_text,
                'profile_overrides': profile_overrides,
                'preset': preset,
            }
    return {
        'kind': 'raw',
        'role_ref': '',
        'role_text': raw,
        'profile_overrides': {},
        'preset': {},
    }


__all__ = [
    'normalize_role_ref',
    'read_role_preset',
    'resolve_role_value',
]
