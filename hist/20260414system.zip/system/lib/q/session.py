from __future__ import annotations

from typing import Any, Callable

from .errors import QCallError
from .live import chunk_q_live, done_q_live, fail_q_live, open_q_live
from .profile import get_profile, resolve_profile_name, set_active_profile
from .prompt import expand_prompt_symbols
from .providers import decode_qc_output, profile_has_stream, extract_chat
from .sampler import ensure_q_sampler_state
from .state import merge_thinking_stream, append_response_stream, write_text_symbol, load_chat, load_role, open_chat_entry, save_chat, write_chat_entry
from .symbols import (
    chat_symbol_for_runtime,
    response_symbol_for_runtime,
    role_symbol_for_runtime,
    system_prompt_symbol_for_runtime,
    thinking_symbol_for_runtime,
)
from .transport import call_profile, stream_profile


def prepare_q_session(parser, command_token: str, prompt: str) -> dict:
    profile_name = resolve_profile_name(parser, command_token, "q")
    profile = get_profile(parser, profile_name)
    ensure_q_sampler_state(parser.state, profile_name)
    set_active_profile(parser, profile_name)

    chat_symbol = chat_symbol_for_runtime(parser, profile_name)
    role_symbol = role_symbol_for_runtime(parser, profile_name)
    system_prompt_symbol = system_prompt_symbol_for_runtime(parser, profile_name)
    chat = load_chat(parser.state, chat_symbol)
    role = load_role(parser.state, system_prompt_symbol) or load_role(parser.state, role_symbol)
    expanded_prompt = expand_prompt_symbols(parser, prompt)

    return {
        "profile_name": profile_name,
        "profile": profile,
        "state": parser.state,
        "chat_symbol": chat_symbol,
        "role_symbol": role_symbol,
        "system_prompt_symbol": system_prompt_symbol,
        "prompt": prompt,
        "expanded_prompt": expanded_prompt,
        "role": role,
        "chat": chat,
        "stream_enabled": 1 if profile_has_stream(profile) else 0,
    }


def run_nonstream_session(session: dict) -> str:
    payload = call_profile(session["profile"], session["expanded_prompt"], role=session["role"], chat=session["chat"], state=session.get("state"), profile_name=session.get("profile_name", "default"))
    return extract_chat(payload, session["profile"].get("chat_message_tag"))


def q_chat(parser, command_token: str, prompt: str, on_chunk: Callable[[str, str, str, str], None] | None = None, on_done: Callable[[str, str, str], None] | None = None) -> dict:
    session = prepare_q_session(parser, command_token, prompt)
    profile_name = session["profile_name"]
    chat_symbol = session["chat_symbol"]
    response_symbol = response_symbol_for_runtime(parser, profile_name)
    thinking_symbol = thinking_symbol_for_runtime(parser, profile_name)

    write_text_symbol(parser.state, response_symbol, "", "response_reset")
    write_text_symbol(parser.state, thinking_symbol, "", "thinking_reset")

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key="", prompt=prompt, response="", thinking="")

    if not session["stream_enabled"]:
        final_text = run_nonstream_session(session)
        chat_log = dict(session["chat"])
        key = str(max([int(k) for k in chat_log.keys() if str(k).isdigit()] + [0]) + 1)
        chat_log[key] = {"prompt": prompt, "response": final_text, "done": 1}
        save_chat(parser.state, chat_symbol, chat_log)
        write_text_symbol(parser.state, response_symbol, "", "response_finalize")
        write_text_symbol(parser.state, thinking_symbol, "", "thinking_finalize")
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking="")
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {"profile": profile_name, "chat_symbol": chat_symbol, "response_symbol": response_symbol, "thinking_symbol": thinking_symbol, "chat_key": key, "message": final_text}

    key = open_chat_entry(parser.state, chat_symbol, prompt)
    final_text = ""
    final_thinking = ""
    saw_done = False

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response="", thinking="")

    try:
        for event in stream_profile(session["profile"], session["expanded_prompt"], role=session["role"], chat=session["chat"], state=session.get("state"), profile_name=session.get("profile_name", "default")):
            thinking_chunk = str(event.get("thinking") or "")
            content_chunk = str(event.get("content") or "")
            event_done = 1 if int(event.get("done") or 0) == 1 else 0

            if thinking_chunk:
                final_thinking = merge_thinking_stream(final_thinking, thinking_chunk)
            if content_chunk:
                final_text = append_response_stream(final_text, content_chunk)

            visible_thinking = "" if final_text else final_thinking
            write_text_symbol(parser.state, response_symbol, final_text, "response_partial")
            write_text_symbol(parser.state, thinking_symbol, visible_thinking, "thinking_partial")
            chunk_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking=visible_thinking)

            if callable(on_chunk) and (thinking_chunk or content_chunk):
                on_chunk(content_chunk or thinking_chunk, final_text, chat_symbol, key)

            if event_done == 1:
                saw_done = True
                break

        done_final = 1
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=done_final)
        write_text_symbol(parser.state, response_symbol, "", "response_finalize")
        write_text_symbol(parser.state, thinking_symbol, "", "thinking_finalize")
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking="")

        if callable(on_done):
            on_done(final_text, chat_symbol, key)

    except Exception:
        visible_thinking = "" if final_text else final_thinking
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=0)
        write_text_symbol(parser.state, response_symbol, final_text, "response_partial")
        write_text_symbol(parser.state, thinking_symbol, visible_thinking, "thinking_partial")
        fail_q_live(parser, "q stream interrupted", profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking=visible_thinking)
        raise

    return {"profile": profile_name, "chat_symbol": chat_symbol, "response_symbol": response_symbol, "thinking_symbol": thinking_symbol, "chat_key": key, "message": final_text}


def qc_raw(parser, command_token: str, *args: Any) -> dict:
    flat_args: list[Any] = []
    for item in args:
        if isinstance(item, (list, tuple)):
            flat_args.extend(item)
        else:
            flat_args.append(item)
    if not flat_args:
        raise QCallError("qc requires prompt")
    prompt = " ".join(str(x) for x in flat_args).strip()
    if not prompt:
        raise QCallError("qc requires prompt")

    profile_name = resolve_profile_name(parser, command_token, "qc")
    profile = get_profile(parser, profile_name)
    ensure_q_sampler_state(parser.state, profile_name)
    expanded_prompt = expand_prompt_symbols(parser, prompt)
    payload = call_profile(profile, expanded_prompt, role="", chat={}, state=parser.state, profile_name=profile_name)
    decoded = decode_qc_output(payload, profile.get("chat_message_tag"))
    return {"profile": profile_name, "decoded": decoded, "raw": payload}


__all__ = ["prepare_q_session", "run_nonstream_session", "q_chat", "qc_raw"]
