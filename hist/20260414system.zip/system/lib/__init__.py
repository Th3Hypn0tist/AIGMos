"""System shared libraries."""
