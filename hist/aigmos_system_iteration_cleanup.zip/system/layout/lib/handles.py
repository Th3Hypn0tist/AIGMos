from __future__ import annotations


def normalize_handle(raw: str) -> str:
    text = str(raw or '').strip()
    if not text:
        raise ValueError('layout handle cannot be empty')
    if not text.startswith('|'):
        raise ValueError('layout handle must start with |')
    body = text[1:].strip()
    if not body:
        raise ValueError('layout handle cannot be empty')
    if ':' in body:
        raise ValueError('layout handle cannot contain :')
    parts = [part for part in body.split('.') if part != '']
    if not parts:
        raise ValueError('layout handle cannot be empty')
    head = parts[0].upper()
    tail = parts[1:]
    return '|' + '.'.join([head, *tail])


def route_name(route: str) -> str:
    token = str(route or '').strip()
    if token.startswith('/'):
        token = token[1:]
    return token.strip()


def layout_handle_from_route(route: str) -> str:
    token = route_name(route)
    if not token:
        raise ValueError('layout route cannot be empty')
    base, dot, suffix = token.partition('.')
    head = base.upper()
    return f'|{head}.{suffix}' if suffix else f'|{head}'


def display_name(handle: str) -> str:
    return str(handle or '').strip().lstrip('|')


def binding_name(binding_handle: str) -> str:
    return display_name(binding_handle).split('.', 1)[0]


def instance_suffix(binding_handle: str, tag: str, ordinal: int) -> str:
    return f'{tag}{int(ordinal)}'


def instance_handle(binding_handle: str, storage_prefix: str, tag: str, ordinal: int) -> str:
    owner = display_name(binding_handle)
    suffix = instance_suffix(binding_handle, tag, ordinal)
    return f'|{storage_prefix}.{owner}.{suffix}'


def state_root_for_handle(raw_handle: str) -> str:
    clean = str(raw_handle or '').strip()
    if not clean:
        return '|Q:q'
    if clean.startswith('|'):
        if ':' in clean:
            return clean
        return normalize_handle(clean)
    if clean.startswith('$'):
        return clean
    return '|Q:q'


def state_root_for_target(raw_target: str) -> str:
    clean = str(raw_target or '').strip()
    if not clean:
        return ''
    if clean.startswith('|'):
        if ':' in clean:
            return clean
        return normalize_handle(clean)
    if clean.startswith('$'):
        return clean
    return ''
