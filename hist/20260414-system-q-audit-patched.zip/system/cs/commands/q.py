# system/cs/commands/q.py

from __future__ import annotations

from system.cs.command_args import parse_command_tail_raw
from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_runtime
from system.lib.q.errors import QCallError
from system.lib.q.session import q_chat


command = "q"
help_short = 'q[.profile] <prompt...>'
help_full = """stateful chat command

rules:
- streams assistant output into active q state
- writes chat history to the current q runtime root (:ch)
- reads optional role from the current q runtime root (:role / :system_prompt)
- reads optional runtime params from the active q runtime root and profile defaults

examples:
  q hello
  q $prompt
  q.coder explain #code:main
"""

def handler(line: str, parser):
    try:
        command_token, prompt = parse_command_tail_raw(
            line,
            usage="usage: q[.<profile>] <prompt...>",
            label="q",
        )
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ""))

    final_message = ""

    try:
        def _on_chunk(_chunk: str, full_text: str, _chat_symbol: str, _key: str) -> None:
            nonlocal final_message
            final_message = str(full_text or "")
            force_render(parser)

        def _on_done(full_text: str, _chat_symbol: str, _key: str) -> None:
            nonlocal final_message
            final_message = str(full_text or "")
            force_render(parser)

        out = q_chat(
            parser,
            command_token,
            prompt,
            on_chunk=_on_chunk,
            on_done=_on_done,
        )

        returned_message = str((out or {}).get("message") or "")
        if len(returned_message) > len(final_message):
            final_message = returned_message

    except QCallError as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)

    force_render(parser)
    if bool(get_runtime(parser, "layout_self_route", False)):
        return HandlerResponse(buffer_output="", force_render=True)
    return HandlerResponse(buffer_output=str(final_message or ""), force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
