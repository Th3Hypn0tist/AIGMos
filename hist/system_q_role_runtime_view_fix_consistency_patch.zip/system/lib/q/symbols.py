from __future__ import annotations

from system.cs.runtime_ctx import get_layout_caller_handle, get_runtime


def q_sampler_prefix_for_profile(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    if clean == "default":
        return "$Q"
    return f"$Q.{clean}"


def q_state_prefix_for_profile(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    if clean == "default":
        return "$Q"
    return f"$Q.{clean}"


def q_state_prefix_for_handle(handle: str) -> str:
    clean = str(handle or "").strip()
    if not clean.startswith("|"):
        return ""
    body = clean[1:].strip()
    if not body:
        return ""
    if ':' not in clean:
        return ""
    return clean


def q_runtime_root_for_state(state) -> str:
    runtime = getattr(state, "_aigmos_runtime", None)
    if isinstance(runtime, dict):
        root = str(runtime.get("q_state_root") or "").strip()
        if root:
            return root
        handle = str(runtime.get("layout_caller_handle") or "").strip()
        from_handle = q_state_prefix_for_handle(handle)
        if from_handle:
            return from_handle
    return ""


def q_runtime_root_for_parser(parser) -> str:
    root = str(get_runtime(parser, "q_state_root", "") or "").strip()
    if root:
        return root
    handle = get_layout_caller_handle(parser)
    from_handle = q_state_prefix_for_handle(handle)
    if from_handle:
        return from_handle
    return ""


def q_state_prefix_for_state(state, profile_name: str = "default") -> str:
    return q_runtime_root_for_state(state)


def q_state_prefix_for_runtime(parser, profile_name: str = "default") -> str:
    return q_runtime_root_for_parser(parser)


def role_runtime_prefix_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:role"


def role_runtime_prefix_for_runtime(parser, profile_name: str = "default") -> str:
    root = q_state_prefix_for_runtime(parser, profile_name)
    return f"{root}:role" if root else ""


def role_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:role_ref"


def system_prompt_symbol_for_profile(profile_name: str) -> str:
    return f"{role_runtime_prefix_for_profile(profile_name)}:system_prompt"


def chat_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:ch"


def chat_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    root = q_state_prefix_for_runtime(parser, profile_name)
    return f"{root}:ch" if root else ""


def get_active_chat_symbol(parser) -> str:
    value = get_runtime(parser, "q_chat_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return chat_symbol_for_runtime(parser, "default") or ""


def response_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:view:response"


def response_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    root = q_state_prefix_for_runtime(parser, profile_name)
    return f"{root}:view:response" if root else ""


def get_active_response_symbol(parser) -> str:
    value = get_runtime(parser, "q_response_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return response_symbol_for_runtime(parser, "default") or ""


def thinking_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:view:thinking"


def thinking_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    root = q_state_prefix_for_runtime(parser, profile_name)
    return f"{root}:view:thinking" if root else ""


def get_active_thinking_symbol(parser) -> str:
    value = get_runtime(parser, "q_thinking_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return thinking_symbol_for_runtime(parser, "default") or ""


def role_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    root = q_state_prefix_for_runtime(parser, profile_name)
    return f"{root}:role_ref" if root else ""


def system_prompt_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    role_root = role_runtime_prefix_for_runtime(parser, profile_name)
    return f"{role_root}:system_prompt" if role_root else ""


__all__ = [
    "q_sampler_prefix_for_profile",
    "q_state_prefix_for_profile",
    "q_state_prefix_for_handle",
    "q_runtime_root_for_state",
    "q_runtime_root_for_parser",
    "q_state_prefix_for_state",
    "q_state_prefix_for_runtime",
    "role_runtime_prefix_for_profile",
    "role_runtime_prefix_for_runtime",
    "role_symbol_for_profile",
    "system_prompt_symbol_for_profile",
    "chat_symbol_for_profile",
    "chat_symbol_for_runtime",
    "get_active_chat_symbol",
    "response_symbol_for_profile",
    "response_symbol_for_runtime",
    "get_active_response_symbol",
    "thinking_symbol_for_profile",
    "thinking_symbol_for_runtime",
    "get_active_thinking_symbol",
    "role_symbol_for_runtime",
    "system_prompt_symbol_for_runtime",
]
