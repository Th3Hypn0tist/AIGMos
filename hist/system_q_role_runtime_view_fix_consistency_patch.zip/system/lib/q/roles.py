from __future__ import annotations

from typing import Any

from .common import coerce_bool, normalize_think_value, read_state_value

_ROLE_RUNTIME_KEYS = (
    'title',
    'temperature',
    'top_k',
    'top_p',
    'repeat_penalty',
    'max_tokens',
    'seed',
    'num_ctx',
    'think',
    'stream',
    'view_thinking',
    'model',
    'stop',
)


def normalize_role_name(value: Any) -> str:
    raw = str(value or '').strip()
    if not raw:
        return ''
    if raw.startswith('#ROLES:'):
        raw = raw[len('#ROLES:'):].strip()
        raw = raw[:-5] if raw.endswith('.role') else raw
        raw = raw[:-7] if raw.endswith('.system') else raw
        return raw.replace(':', '/')
    raw = raw.strip('/').replace('\\', '/').replace(':', '/')
    if raw.endswith('.role'):
        raw = raw[:-5]
    if raw.endswith('.system'):
        raw = raw[:-7]
    return raw.strip('/')


def role_symbol_from_name(value: Any, suffix: str = '.role') -> str:
    name = normalize_role_name(value)
    if not name:
        return ''
    body = name.replace('/', ':')
    if suffix and not suffix.startswith('.'):
        suffix = '.' + suffix
    return f'#ROLES:{body}{suffix or ""}'


def read_role_preset(state, value: Any) -> dict[str, Any]:
    symbol = role_symbol_from_name(value, '.role')
    if not symbol:
        return {}
    payload = read_state_value(state, symbol, None)
    return dict(payload) if isinstance(payload, dict) else {}


def read_role_system_prompt(state, value: Any) -> str:
    symbol = role_symbol_from_name(value, '.system')
    if not symbol:
        return ''
    return str(read_state_value(state, symbol, '') or '')


def normalize_role_runtime_value(key: str, value: Any) -> Any:
    if value in (None, ''):
        return None
    key = str(key or '').strip()
    if key in {'stream', 'view_thinking'}:
        return coerce_bool(value, None)
    if key == 'think':
        return normalize_think_value(value, None)
    if key in {'top_k', 'max_tokens', 'seed', 'num_ctx'}:
        try:
            return int(value)
        except Exception:
            return None
    if key in {'temperature', 'top_p', 'repeat_penalty'}:
        try:
            return float(value)
        except Exception:
            return None
    if key == 'stop':
        if isinstance(value, list):
            return [str(item) for item in value if str(item)]
        return value
    return value


def build_role_runtime_snapshot(state, value: Any) -> dict[str, Any]:
    role_name = normalize_role_name(value)
    if not role_name:
        return {'role_ref': '', 'role': {}, 'system_prompt': ''}
    preset = read_role_preset(state, role_name)
    system_prompt = read_role_system_prompt(state, role_name)
    role_data: dict[str, Any] = {}
    for key, raw in dict(preset or {}).items():
        if raw in (None, ''):
            continue
        normalized = normalize_role_runtime_value(key, raw)
        if normalized in (None, ''):
            continue
        role_data[str(key)] = normalized
    if system_prompt:
        role_data['system_prompt'] = system_prompt
    return {'role_ref': role_name, 'role': role_data, 'system_prompt': system_prompt}


def resolve_role_value(state, value: Any) -> dict[str, Any]:
    snapshot = build_role_runtime_snapshot(state, value)
    role_name = snapshot.get('role_ref') or ''
    role_data = dict(snapshot.get('role') or {})
    system_prompt = str(snapshot.get('system_prompt') or '')
    if not role_name:
        return {
            'kind': 'empty',
            'role': '',
            'role_ref': '',
            'system_prompt': '',
            'profile_overrides': {},
            'preset': {},
            'runtime_role': {},
        }
    if role_data or system_prompt:
        profile_overrides = {
            key: role_data[key]
            for key in _ROLE_RUNTIME_KEYS
            if key in role_data and key != 'title'
        }
        return {
            'kind': 'preset',
            'role': role_name,
            'role_ref': role_name,
            'system_prompt': system_prompt,
            'profile_overrides': profile_overrides,
            'preset': read_role_preset(state, role_name),
            'runtime_role': role_data,
        }
    return {
        'kind': 'missing',
        'role': role_name,
        'role_ref': role_name,
        'system_prompt': '',
        'profile_overrides': {},
        'preset': {},
        'runtime_role': {},
    }


__all__ = [
    'normalize_role_name',
    'role_symbol_from_name',
    'read_role_preset',
    'read_role_system_prompt',
    'normalize_role_runtime_value',
    'build_role_runtime_snapshot',
    'resolve_role_value',
]
