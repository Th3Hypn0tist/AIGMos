reload help
reload roles
reload prompts
reload routines
