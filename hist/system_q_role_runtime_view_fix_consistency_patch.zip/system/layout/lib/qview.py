from __future__ import annotations

from typing import Any
import re

from .. import state as layout_state
from .editor import get_module_ui
from .scroll import viewport_head, viewport_tail
from .wrap import wrap_text

_THINK_TAG_RE = re.compile(r"</?think>", re.IGNORECASE)


def _clean_visible(value: Any) -> str:
    return _THINK_TAG_RE.sub("", str(value or ""))


def sorted_chat_keys(chat: dict[str, Any]) -> list[Any]:
    def sort_key(item: Any):
        text = str(item)
        return (0, int(text)) if text.isdigit() else (1, text)
    return sorted(chat.keys(), key=sort_key)


def _live_packet_for(ctx, chat_symbol: str) -> tuple[dict[str, Any], Any]:
    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    live_packet: dict[str, Any] = {}
    chat: Any = layout_state.get_value(ctx, chat_symbol, {})
    if parser is None:
        return live_packet, chat
    try:
        from system.lib.q.live import get_live_chat, get_live_packet

        chat = get_live_chat(parser, chat_symbol)
        live_packet = get_live_packet(parser)
    except Exception:
        pass
    return live_packet, chat


def read_q_state(ctx, instance) -> dict[str, Any]:
    target_root = str(getattr(instance, "primary_target", "") or "").strip()
    chat_symbol = str(getattr(instance, "view_target", "") or "").strip()
    show_thinking_raw = layout_state.get_value(ctx, f"{target_root}:role:view_thinking", True)
    if isinstance(show_thinking_raw, bool):
        show_thinking = show_thinking_raw
    else:
        show_thinking = str(show_thinking_raw if show_thinking_raw is not None else "true").strip().lower() not in {"0", "false", "no", "off"}
    live_packet, chat = _live_packet_for(ctx, chat_symbol)
    return {
        "target_root": target_root,
        "chat_symbol": chat_symbol,
        "chat": chat,
        "prompt": _clean_visible(layout_state.get_value(ctx, f"{target_root}:prompt", "") or ""),
        "response": _clean_visible(layout_state.get_value(ctx, f"{target_root}:view:response", "") or ""),
        "thinking": _clean_visible(layout_state.get_value(ctx, f"{target_root}:view:thinking", "") or ""),
        "error": _clean_visible(layout_state.get_value(ctx, f"{target_root}:error", "") or ""),
        "cue": str(layout_state.get_value(ctx, f"{target_root}:cue", "") or "").strip(),
        "live_packet": live_packet,
        "show_thinking": show_thinking,
    }


def _extend_wrapped(dst: list[str], raw: str, width: int) -> None:
    dst.extend(wrap_text(raw, width) or [""])


def _append_chat_entry(dst: list[str], prompt: str, response: str, error: str, width: int) -> None:
    if prompt:
        _extend_wrapped(dst, f"Q> {prompt}", width)
    if response:
        _extend_wrapped(dst, f"A> {response}", width)
        dst.append("")
    if error:
        _extend_wrapped(dst, f"[ERROR] {error}", width)
        dst.append("")


def render_q_lines(ctx, instance, width: int, height: int, flow: str = "top") -> list[str]:
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    flow = str(flow or "top").strip().lower()
    ui = get_module_ui(ctx, getattr(instance, "handle", ""))
    follow = bool(ui.get("follow", True))
    scroll = max(0, int(ui.get("scroll", 0) or 0))

    state = read_q_state(ctx, instance)
    live_packet = state["live_packet"]
    live_chat_symbol = str(live_packet.get("chat_symbol") or "")
    live_key = str(live_packet.get("key") or "")
    live_prompt = _clean_visible(live_packet.get("prompt") or "")
    live_response = _clean_visible(live_packet.get("response") or "")
    live_thinking = _clean_visible(live_packet.get("thinking") or "")
    live_done = 1 if int(live_packet.get("done") or 0) == 1 else 0

    is_live_for_target = (
        live_done == 0
        and live_chat_symbol == state["chat_symbol"]
        and bool(live_key)
    )

    all_lines: list[str] = []
    if is_live_for_target:
        if live_thinking and not live_response and state["show_thinking"]:
            if live_prompt:
                _extend_wrapped(all_lines, f"Q> {live_prompt}", width)
            _extend_wrapped(all_lines, f"[THINKING] {live_thinking}", width)
        elif live_response:
            if live_prompt:
                _extend_wrapped(all_lines, f"Q> {live_prompt}", width)
            _extend_wrapped(all_lines, f"[RESPONSE] {live_response}", width)
    else:
        cue_value = state["cue"]
        if cue_value:
            cue_line = cue_value if cue_value.startswith("[CUE") else f"[CUE: {cue_value}]"
            _extend_wrapped(all_lines, cue_line, width)
        chat = state["chat"]
        if isinstance(chat, dict) and chat:
            keys = sorted_chat_keys(chat)
            iterable = keys if flow == "top" else list(reversed(keys))
            for key in iterable:
                item = chat.get(key) or {}
                if not isinstance(item, dict):
                    continue
                _append_chat_entry(
                    all_lines,
                    _clean_visible(item.get("prompt") or ""),
                    _clean_visible(item.get("response") or ""),
                    _clean_visible(item.get("error") or ""),
                    width,
                )
        elif state["thinking"] and not state["response"] and state["show_thinking"]:
            if state["prompt"]:
                _extend_wrapped(all_lines, f"Q> {state['prompt']}", width)
            _extend_wrapped(all_lines, f"[THINKING] {state['thinking']}", width)
        elif state["response"]:
            if state["prompt"]:
                _extend_wrapped(all_lines, f"Q> {state['prompt']}", width)
            _extend_wrapped(all_lines, f"[RESPONSE] {state['response']}", width)
        elif state["error"]:
            _extend_wrapped(all_lines, f"[ERROR] {state['error']}", width)

    if not all_lines:
        all_lines = [""]
    if flow != "top":
        all_lines = list(reversed(all_lines))

    if follow:
        ui["scroll"] = 0
        return viewport_tail(all_lines, height, 0)
    if flow == "top":
        return viewport_tail(all_lines, height, scroll)
    return viewport_head(all_lines, height, scroll)


def clear_q_state(ctx, module_handle: str, instance, *, clear_data: bool) -> bool:
    if clear_data:
        base = str(getattr(instance, "primary_target", "") or "").strip()
        if base:
            layout_state.set_value(ctx, f"{base}:ch", {})
            layout_state.set_value(ctx, f"{base}:cue", "")
            layout_state.set_value(ctx, f"{base}:view:response", "")
            layout_state.set_value(ctx, f"{base}:view:thinking", "")
            layout_state.set_value(ctx, f"{base}:prompt", "")
            layout_state.set_value(ctx, f"{base}:error", "")
    ui = get_module_ui(ctx, module_handle)
    ui["follow"] = True
    ui["scroll"] = 0
    return True


__all__ = [
    "sorted_chat_keys",
    "read_q_state",
    "render_q_lines",
    "clear_q_state",
]
