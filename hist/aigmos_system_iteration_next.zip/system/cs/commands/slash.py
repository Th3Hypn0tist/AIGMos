from __future__ import annotations

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse


from datetime import datetime

from system.adapters.registry import build_extra_routes, reload_adapters
from system.boot import GREETING_TEXT
from system.config import load_config, require_osc_in_config
from system.cs.command_registry import reload_commands
from system.lib.q.profile import set_active_profile
from system.lib.q.transport import health_q_profile
from system.cs.runtime_ctx import (
    force_render,
    get_ctx,
    get_layout_caller_handle,
    get_runtime,
    set_flag,
    set_running,
    set_runtime,
)
from system.cs.state_ops import delete_result, set_result
from system.inputs.registry import create_input, list_input_names, reload_inputs
from system.runtime.osc import OSCInServer

command = "/"
help_short = '/help [/cmd] | /time | /greeting | /clear | reload ... | /health q[.alias] | /exit'
help_full = """local slash command surface

subcommands:
- /help [cmd]      list short help or one full help
- /time            print local time to buffer
- /greeting        print greeting
- /clear           clear current layout modules and queue redraw
- reload [...]     reload help/roles/prompts/routines/layout/config/commands/adapters/inputs/all
- /cs              switch active layout to cs template instance
- /q               switch active layout to q template instance
- /monitor[.alias] switch active layout to monitor instance
- /health q[.x]    GET q profile health_url
- /exit            stop app
"""

SLASH_HELP = {
    "/help": "/help [cmd] -> list short help or one full help",
    "/time": "/time -> print local time to buffer",
    "/exit": "/exit -> stop app",
    "/greeting": "/greeting -> print greeting",
    "/clear": "/clear -> call clear() on clearable modules in the current layout instance and queue hard terminal redraw",
    "reload": "reload [help|roles|role <name>|prompts|routines|layout|config|commands|adapters|inputs|all] -> reload selected subsystems",
    "/cs": "/cs -> switch active layout to cs template instance",
    "/q": "/q -> switch active layout to q template instance",
    "/monitor": "/monitor[.<alias>] -> switch active layout to monitor instance",
    "/health": "/health q[.<alias>] -> GET q profile health_url",
}

CONFIG_PREFIX = "#SYSTEM:config:"
_RELOADABLE = ("config", "commands", "layout", "adapters", "inputs")


def _queue_hard_redraw(parser) -> None:
    try:
        from system.layout import terminal as layout_terminal  # type: ignore

        ctx = get_ctx(parser)
        if isinstance(ctx, dict):
            layout_terminal.queue_hard_redraw(ctx)
    except Exception:
        pass


def _force_hard_render(parser) -> None:
    _queue_hard_redraw(parser)
    force_render(parser)


def _resolve_q_alias(token: str) -> str:
    if "." not in token:
        return "default"
    return token.split(".", 1)[1].strip() or "default"


def _state_set(parser, symbol: str, value, *, op: str = "slash_set") -> None:
    set_result(parser.state, symbol, value, writer="parser:/", op=op)


def _state_delete(parser, symbol: str, *, op: str = "slash_delete") -> None:
    delete_result(parser.state, symbol, writer="parser:/", op=op)


def _list_all_symbols(parser) -> list[str]:
    out = parser.state.list_symbols()
    if out["error"]:
        raise RuntimeError(out["error"])
    return [symbol for symbol in (out["result"] or []) if isinstance(symbol, str)]


def _delete_config_mirror(parser) -> None:
    for symbol in _list_all_symbols(parser):
        if symbol.startswith(CONFIG_PREFIX):
            _state_delete(parser, symbol, op="slash_delete_config_mirror")


def _mirror_config_leafs(parser, data, prefix=("SYSTEM", "config")) -> None:
    if isinstance(data, dict):
        for key, value in data.items():
            key = str(key)
            if key == "":
                raise ValueError("empty config key during mirror")
            _mirror_config_leafs(parser, value, prefix + (key,))
        return

    if isinstance(data, list):
        for idx, value in enumerate(data):
            _mirror_config_leafs(parser, value, prefix + (str(idx),))
        return

    target = "#" + ":".join(prefix)
    _state_set(parser, target, data, op="slash_mirror_config")


def _reload_config(parser) -> dict:
    config = load_config()

    _delete_config_mirror(parser)
    _mirror_config_leafs(parser, config)

    set_runtime(parser, "config", config)

    ctx = get_ctx(parser)
    if isinstance(ctx, dict):
        ctx["config"] = config

    active_profile = str(get_runtime(parser, "q_profile", "default") or "default").strip() or "default"
    try:
        set_active_profile(parser, active_profile)
    except Exception:
        set_active_profile(parser, "default")

    return config


def _reload_commands_only(parser) -> list[str]:
    parser.registry = reload_commands()
    return sorted(parser.registry.keys())


def _reload_layout_only(parser) -> list[str]:
    from system.layout import registry as layout_registry  # type: ignore

    ctx = get_ctx(parser)
    return layout_registry.reload_layout(ctx)


def _reload_adapters_only(parser) -> list[str]:
    ctx = get_ctx(parser)
    config = ctx.get("config") if isinstance(ctx, dict) else None

    names = reload_adapters()

    state = ctx.get("state") if isinstance(ctx, dict) else None
    old_routes = list(ctx.get("state_routes") or []) if isinstance(ctx, dict) else []
    for prefix, _adapter in old_routes:
        try:
            state.unregister_route(prefix)
        except Exception:
            pass

    extra_routes = build_extra_routes(config)
    if state is not None:
        for prefix, adapter in extra_routes:
            state.register_route(prefix, adapter)

    if isinstance(ctx, dict):
        ctx["state_routes"] = list(extra_routes)
    return names


def _restart_osc_input(parser) -> None:
    ctx = get_ctx(parser)
    if not isinstance(ctx, dict):
        return

    old_server = ctx.get("osc_server")
    if old_server is not None and hasattr(old_server, "stop"):
        try:
            old_server.stop()
        except Exception:
            pass
        try:
            old_server.join(timeout=1.0)
        except Exception:
            pass

    osc_input = create_input("osc", backend=ctx.get("mem_adapter"), root_symbol="#OSC")
    bind_ip, port, buffer_size = require_osc_in_config(ctx["state"])
    osc_server = OSCInServer(bind_ip, port, buffer_size, osc_input)
    osc_server.start()

    ctx["osc_input"] = osc_input
    ctx["osc_server"] = osc_server
    ctx["input_types"] = list_input_names()
    parser.runtime["osc_input"] = osc_input


def _reload_inputs_only(parser) -> list[str]:
    names = reload_inputs()
    _restart_osc_input(parser)
    ctx = get_ctx(parser)
    if isinstance(ctx, dict):
        ctx["input_types"] = names
    return names


def _parse_reload_targets(tokens: list[str]) -> list[str]:
    if len(tokens) <= 1:
        return ["config"]

    raw = " ".join(tokens[1:]).strip()
    if not raw:
        return ["config"]

    normalized = raw.replace(",", "/").replace(" ", "/")
    parts = [part.strip().lower() for part in normalized.split("/") if part.strip()]
    if not parts:
        return ["config"]

    if "all" in parts:
        return list(_RELOADABLE)

    seen: list[str] = []
    for part in parts:
        if part not in _RELOADABLE:
            raise ValueError(f"unknown reload target: {part}")
        if part not in seen:
            seen.append(part)
    return seen


def _reload_selected(parser, targets: list[str]) -> list[str]:
    completed: list[str] = []

    for target in targets:
        if target == "config":
            _reload_config(parser)
        elif target == "commands":
            _reload_commands_only(parser)
        elif target == "layout":
            _reload_layout_only(parser)
        elif target == "adapters":
            _reload_adapters_only(parser)
        elif target == "inputs":
            _reload_inputs_only(parser)
        else:
            raise ValueError(f"unknown reload target: {target}")
        completed.append(target)

    return completed


def _switch_layout(parser, route: str) -> None:
    from system.layout import registry as layout_registry  # type: ignore

    ctx = get_ctx(parser)
    resolved = layout_registry.ensure_instance(ctx, route)
    handle = getattr(resolved, "handle", resolved)
    layout_registry.switch_active(ctx, str(handle))


def _clear_current_layout_modules(parser) -> list[str]:
    from system.layout import registry as layout_registry  # type: ignore

    ctx = get_ctx(parser)
    handle = get_layout_caller_handle(parser)
    return layout_registry.clear_layout_modules(ctx, handle or None)



def handler(line: str, parser):
    tokens = line.split()
    subcmd = tokens[0].lower()

    if subcmd == "/help":
        if len(tokens) == 1:
            items = []
            for name, short in parser.get_short_help().items():
                items.append(short if name == "/" else f"{name} -> {short}")
            return HandlerResponse(buffer_output=str('\n'.join(items) or ""))

        target = tokens[1]
        if target.startswith("/"):
            text = SLASH_HELP.get(target, "")
            if text:
                return HandlerResponse(buffer_output=str(text or ""))

        text = parser.get_full_help(target)
        if not text:
            return HandlerResponse(error=str(f'help not found: {target}' or ""))
        return HandlerResponse(buffer_output=str(text or ""))

    if subcmd == "/time":
        return HandlerResponse(buffer_output=str(datetime.now().strftime('%Y-%m-%d %H:%M:%S') or ""))

    if subcmd == "/exit":
        parser.should_exit = True
        set_running(parser, False)
        set_flag(parser, "force_render", True)
        return HandlerResponse(buffer_output=str('[ok] exit' or ""))

    if subcmd == "/greeting":
        return HandlerResponse(buffer_output=str(GREETING_TEXT or ""))

    if subcmd == "/clear":
        try:
            _clear_current_layout_modules(parser)
        except Exception as exc:
            return HandlerResponse(error=str(str(exc) or ""))

        _force_hard_render(parser)
        return HandlerResponse()

    if subcmd == "/reload":
        try:
            targets = _parse_reload_targets(tokens)
            completed = _reload_selected(parser, targets)
        except Exception as exc:
            return HandlerResponse(error=str(str(exc) or ""))
        force_render(parser)
        return HandlerResponse(buffer_output=str(f"[ok] reloaded: {'/'.join(completed)}" or ""))

    if subcmd == "/monitor" or subcmd.startswith("/monitor."):
        try:
            route = "/monitor" + (subcmd[len("/monitor"):] if subcmd.startswith("/monitor.") else "")
            _switch_layout(parser, route)
        except Exception as exc:
            return HandlerResponse(error=str(str(exc) or ""))
        force_render(parser)
        return HandlerResponse()
        force_render(parser)
        return HandlerResponse()

    if subcmd == "/q" or subcmd.startswith("/q."):
        if len(tokens) != 1:
            return HandlerResponse(error=str('usage: /q[.<alias>]' or ""))

        alias = _resolve_q_alias(subcmd)
        try:
            set_active_profile(parser, alias)
            _switch_layout(parser, subcmd)
        except Exception as exc:
            return HandlerResponse(error=str(str(exc) or ""))
        force_render(parser)
        return HandlerResponse()

    if subcmd == "/health":
        if len(tokens) != 2:
            return HandlerResponse(error=str('usage: /health q[.<alias>]' or ""))

        target = tokens[1].lower()
        if not (target == "q" or target.startswith("q.")):
            return HandlerResponse(error=str('usage: /health q[.<alias>]' or ""))

        try:
            alias = _resolve_q_alias(target)
            return HandlerResponse(buffer_output=str(health_q_profile(parser, alias) or ""))
        except Exception as exc:
            return HandlerResponse(error=str(str(exc) or ""))

    return HandlerResponse(error=str(f'unknown slash command: {subcmd}' or ""))

def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )

