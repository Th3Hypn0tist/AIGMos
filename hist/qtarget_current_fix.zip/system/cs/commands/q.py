# system/cs/commands/q.py

from __future__ import annotations

from system.cs.command_args import parse_command_tail_raw
from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_ctx, get_layout_caller_handle, get_runtime, set_runtime
from system.layout.lib.targets import resolve_querytarget
from system.lib.q.errors import QCallError
from system.lib.q.session import q_chat


command = "q"
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful query command

rules:
- q always requires an explicit querytarget
- relative targets like |:q resolve against the current layout instance
- streams assistant output into the resolved q runtime root (:ch)
- reads optional role from the resolved q runtime root (:role:name / :role:system_prompt)
- reads optional runtime params from the resolved q runtime root :role:* subtree and profile defaults

examples:
  q |:q hello
  q |HELP:q explain #HELP:README.md
  q.coder |:q explain #code:main
"""


def _parse_target_and_prompt(tail: str, usage: str) -> tuple[str, str]:
    raw = str(tail or '')
    parts = raw.split(None, 1)
    if len(parts) != 2:
        raise ValueError(usage)
    target = str(parts[0] or '').strip()
    prompt = str(parts[1] or '')
    if not target or not prompt.strip():
        raise ValueError(usage)
    return target, prompt


def _resolve_target(parser, raw_target: str) -> str:
    caller = str(get_layout_caller_handle(parser) or '').strip()
    return resolve_querytarget(raw_target, caller)


def handler(line: str, parser):
    usage = 'usage: q[.<profile>] <target> <prompt...>'
    try:
        command_token, tail = parse_command_tail_raw(
            line,
            usage=usage,
            label='q',
        )
        raw_target, prompt = _parse_target_and_prompt(tail, usage)
        resolved_target = _resolve_target(parser, raw_target)
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ''))

    final_message = ''
    previous_q_root = get_runtime(parser, 'q_state_root', '')

    try:
        set_runtime(parser, 'q_state_root', resolved_target)

        def _on_chunk(_chunk: str, full_text: str, _chat_symbol: str, _key: str) -> None:
            nonlocal final_message
            final_message = str(full_text or '')
            force_render(parser)

        def _on_done(full_text: str, _chat_symbol: str, _key: str) -> None:
            nonlocal final_message
            final_message = str(full_text or '')
            force_render(parser)

        out = q_chat(
            parser,
            command_token,
            prompt,
            on_chunk=_on_chunk,
            on_done=_on_done,
        )

        returned_message = str((out or {}).get('message') or '')
        if len(returned_message) > len(final_message):
            final_message = returned_message

    except QCallError as exc:
        return HandlerResponse(error=str(str(exc) or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ''), force_render=True)
    finally:
        set_runtime(parser, 'q_state_root', previous_q_root)

    force_render(parser)
    if bool(get_runtime(parser, 'layout_self_route', False)):
        return HandlerResponse(buffer_output='', force_render=True)
    return HandlerResponse(buffer_output=str(final_message or ''), force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
