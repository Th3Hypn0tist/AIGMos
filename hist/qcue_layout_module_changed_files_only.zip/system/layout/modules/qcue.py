from __future__ import annotations

from typing import Any

from system.layout.lib.border import content_rect
from system.layout.lib.payload import finalize_payload
from system.layout.lib.scroll import handle_scroll_key, viewport_head, viewport_tail
from system.layout.lib.spec import flow_attr
from system.layout.lib.wrap import wrap_text
from system.lib.q.qcue import QCUE_ROOT, qcue_state_get

MODULE = "qcue"
DEFAULT_PROMPT = "cs> "
FOCUSABLE = True


def get_targets(handle: str, config: dict[str, Any] | None = None) -> tuple[str, str]:
    return QCUE_ROOT, QCUE_ROOT


def measure(ctx, binding_handle: str, spec: dict[str, Any], width: int, instance) -> dict[str, Any]:
    return {"min_h": 1, "scalable_y": True}


def _sorted_numeric_items(value: Any) -> list[tuple[str, Any]]:
    if isinstance(value, list):
        return [(str(idx), item) for idx, item in enumerate(value)]
    if not isinstance(value, dict):
        return []

    def sort_key(pair: tuple[str, Any]) -> tuple[int, int | str]:
        key = str(pair[0] or "")
        return (0, int(key)) if key.isdigit() else (1, key)

    return sorted(((str(key), item) for key, item in value.items()), key=sort_key)


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split())


def _preview(value: Any, limit: int = 72) -> str:
    text = _clean_text(value)
    if len(text) <= limit:
        return text
    return text[: max(1, limit - 1)].rstrip() + "…"


def _int_attr(attrs: dict[str, Any], key: str, default: int, minimum: int = 1) -> int:
    try:
        return max(int(minimum), int(attrs.get(key, default) or default))
    except Exception:
        return max(int(minimum), int(default))


def _kind_filter(attrs: dict[str, Any]) -> str:
    raw = str(attrs.get("kind") or attrs.get("show") or "all").strip().lower()
    return raw if raw in {"q", "qc", "all"} else "all"


def _alias_filter(attrs: dict[str, Any]) -> str:
    return str(attrs.get("alias") or "").strip()


def _target_filter(attrs: dict[str, Any]) -> str:
    return str(attrs.get("target") or attrs.get("qtarget") or "").strip()


def _matches(task: dict[str, Any], *, kind: str, alias: str, target: str) -> bool:
    task_kind = str(task.get("kind") or "q").strip().lower() or "q"
    task_alias = str(task.get("alias") or "").strip()
    task_root = str(task.get("q_root") or "").strip()
    if kind != "all" and task_kind != kind:
        return False
    if alias and task_alias != alias:
        return False
    if target and task_root != target:
        return False
    return True


def _task_line(task: dict[str, Any], label: str) -> str:
    kind = str(task.get("kind") or "q").strip().lower() or "q"
    alias = str(task.get("alias") or "default").strip() or "default"
    task_id = str(task.get("task_id") or "")
    q_root = str(task.get("q_root") or "").strip()
    prompt = _preview(task.get("prompt") or "")
    output_symbol = str(task.get("output_symbol") or "").strip()

    parts = [label, kind.upper()]
    if task_id:
        parts.append(f"#{task_id}")
    parts.append(f"[{alias}]")
    if q_root:
        parts.append(q_root)
    if kind == "qc" and output_symbol:
        parts.append(f"-> {output_symbol}")
    line = " ".join(parts)
    if prompt:
        line = f"{line}  {prompt}"
    return line


def _collect_sections(ctx, attrs: dict[str, Any]) -> tuple[list[str], dict[str, int]]:
    state = ctx.get("state") if isinstance(ctx, dict) else None
    data = qcue_state_get(state)
    aliases = dict(data.get("aliases") or {})
    active = dict(data.get("active") or {})

    kind = _kind_filter(attrs)
    alias_filter = _alias_filter(attrs)
    target_filter = _target_filter(attrs)

    q_running: list[str] = []
    q_waiting: list[str] = []
    qc_running: list[str] = []
    qc_waiting: list[str] = []

    counts = {"q_running": 0, "q_waiting": 0, "qc_running": 0, "qc_waiting": 0}

    for alias in sorted(str(name) for name in aliases.keys()):
        alias_data = aliases.get(alias) if isinstance(aliases.get(alias), dict) else {}
        queue_items = _sorted_numeric_items(alias_data.get("queue"))
        queue_total = len(queue_items)
        for pos, (_key, item) in enumerate(queue_items, start=1):
            if not isinstance(item, dict):
                continue
            task = dict(item)
            task.setdefault("alias", alias)
            task_kind = str(task.get("kind") or "q").strip().lower() or "q"
            task_root = str(task.get("q_root") or "").strip()
            task_id = str(task.get("task_id") or "")
            active_entry = dict(active.get(task_root) or {}) if task_root else {}
            is_q_active = bool(task_kind == "q" and task_root and str(active_entry.get("task_id") or "") == task_id)
            status = "running" if is_q_active else str(task.get("status") or "waiting").strip().lower()
            task["status"] = status
            if not _matches(task, kind=kind, alias=alias_filter, target=target_filter):
                continue
            if task_kind == "q" and status == "running":
                q_running.append(_task_line(task, "[RUN]"))
                counts["q_running"] += 1
            elif task_kind == "q":
                q_waiting.append(_task_line(task, f"[CUE {pos}/{queue_total}]"))
                counts["q_waiting"] += 1
            elif status == "running":
                qc_running.append(_task_line(task, "[RUN]"))
                counts["qc_running"] += 1
            else:
                qc_waiting.append(_task_line(task, f"[CUE {pos}/{queue_total}]"))
                counts["qc_waiting"] += 1

    lines: list[str] = []
    lines.append(
        f"Qcue  q:{counts['q_running']}/{counts['q_waiting']}  qc:{counts['qc_running']}/{counts['qc_waiting']}"
    )

    if q_running:
        lines.append("")
        lines.append("Q RUNNING")
        lines.extend(q_running)
    if q_waiting:
        lines.append("")
        lines.append("Q WAITING")
        lines.extend(q_waiting)
    if qc_running:
        lines.append("")
        lines.append("QC RUNNING")
        lines.extend(qc_running)
    if qc_waiting:
        lines.append("")
        lines.append("QC WAITING")
        lines.extend(qc_waiting)

    if len(lines) == 1:
        lines.append("")
        lines.append("[QUEUE EMPTY]")

    return lines, counts


def _visible_lines(ctx, module_handle: str, lines: list[str], width: int, height: int, flow: str) -> list[str]:
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    follow = bool(ui.get("follow", True))
    scroll = max(0, int(ui.get("scroll", 0) or 0))

    wrapped: list[str] = []
    for raw in lines or [""]:
        wrapped.extend(wrap_text(raw, width) or [""])

    if not wrapped:
        wrapped = [""]

    if follow:
        ui["scroll"] = 0
        if flow == "top":
            return viewport_head(wrapped, height, 0)
        return viewport_tail(wrapped, height, 0)

    if flow == "top":
        return viewport_head(wrapped, height, scroll)
    return viewport_tail(wrapped, height, scroll)


def build_payload(ctx, binding_handle: str, spec: dict[str, Any], rect: dict[str, int], instance):
    attrs = dict(spec.get("attrs") or {})
    flow = flow_attr(MODULE, attrs)
    inner_rect = content_rect(attrs, rect)
    lines, _counts = _collect_sections(ctx, attrs)
    visible = _visible_lines(
        ctx,
        instance.handle,
        lines,
        max(1, int(inner_rect.get("w", 1) or 1)),
        max(1, int(inner_rect.get("h", 1) or 1)),
        flow,
    )
    return finalize_payload(ctx, instance.handle, visible or [""], attrs, MODULE, rect)


def handle_key(ctx, module_handle: str, key: int) -> bool:
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    if handle_scroll_key(ui, key, kind="q"):
        layout_input._mark_dirty(ctx)
        return True
    return False


def clear(ctx, module_handle: str, instance):
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    ui["follow"] = True
    ui["scroll"] = 0
    return True
