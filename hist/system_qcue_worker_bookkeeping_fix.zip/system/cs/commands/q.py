from __future__ import annotations

import threading

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_layout_caller_handle
from system.lib.q.errors import QCallError
from system.lib.q.qcue import (
    qcue_claim_next_runnable,
    qcue_complete,
    qcue_lock,
    qcue_runtime,
    qcue_set_started,
    qcue_started,
    qcue_thread_get,
    qcue_thread_set,
    qcue_wake,
    qcue_wake_event,
    qcue_enqueue,
)
from system.lib.q.session import q_chat
from system.lib.q.state import write_text_symbol
from system.layout.lib.targets import resolve_querytarget

command = 'q'
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful chat/query dispatch

rules:
- target is explicit
- dispatches query asynchronously
- does not return successful assistant output to command buffer
- queue truth lives in #SYSTEM:Qcue
- q-root live fields are active-render cache only
- queued items do not overwrite active q-root live state
- one global active slot per q runtime root; queued FIFO per profile alias

examples:
  q |:q hello
  q |HELP:q explain #HELP:README.md
  q.coder |:q refactor this
"""


def _parse_q_target_prompt(line: str) -> tuple[str, str, str]:
    raw = str(line or '').strip()
    parts = raw.split(maxsplit=2)
    if len(parts) < 3:
        raise ValueError('usage: q[.profile] <target> <prompt...>')
    command_token, target, prompt = parts[0], parts[1], parts[2]
    if not prompt or not prompt.strip():
        raise ValueError('q requires prompt')
    return command_token, target, prompt


def _alias_from_command_token(command_token: str) -> str:
    return str(command_token.split('.', 1)[1] if '.' in command_token else 'default').strip() or 'default'


def _set_active_live_state(parser, q_root: str, prompt: str, alias: str, *, clear_error: bool = True) -> None:
    clean_root = str(q_root or '').strip()
    clean_alias = str(alias or '').strip()
    if not clean_root:
        return
    # q-root fields are active-render cache only. Queue truth stays in #SYSTEM:Qcue.
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_active_set')
    write_text_symbol(parser.state, f'{clean_root}:status', 'running', 'status_running')
    write_text_symbol(parser.state, f'{clean_root}:response', '', 'response_reset')
    write_text_symbol(parser.state, f'{clean_root}:thinking_text', '', 'thinking_reset')
    write_text_symbol(parser.state, f'{clean_root}:queue_alias', clean_alias, 'queue_alias_active_set')
    if clear_error:
        write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_reset')


def _start_worker(parser, task: dict[str, str]) -> None:
    q_root = str(task.get('q_root') or '')
    task_id = str(task.get('task_id') or '')
    alias = str(task.get('alias') or '')
    prompt = str(task.get('prompt') or '')

    try:
        if q_root:
            _set_active_live_state(parser, q_root, prompt, alias, clear_error=True)

        def _worker() -> None:
            try:
                def _on_chunk(_chunk: str, _full_text: str, _chat_symbol: str, _key: str) -> None:
                    force_render(parser)

                def _on_done(_full_text: str, _chat_symbol: str, _key: str) -> None:
                    force_render(parser)

                q_chat(
                    parser,
                    str(task.get('command_token') or 'q'),
                    prompt,
                    q_root_override=q_root,
                    queue_meta={
                        'alias': alias,
                        'q_root': q_root,
                        'task_id': task_id,
                    },
                    on_chunk=_on_chunk,
                    on_done=_on_done,
                )
            except Exception as exc:
                bookkeeping_error = None
                if q_root:
                    try:
                        write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_error')
                        write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_error_status')
                    except Exception:
                        pass
                if alias and task_id:
                    try:
                        qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                    except Exception as bk_exc:
                        bookkeeping_error = bk_exc
                if bookkeeping_error is not None:
                    if q_root:
                        try:
                            write_text_symbol(parser.state, f'{q_root}:error', f'worker bookkeeping error: {bookkeeping_error}', 'q_async_bookkeeping_error')
                            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_bookkeeping_error_status')
                        except Exception:
                            pass
                    raise bookkeeping_error from exc
                force_render(parser)
            finally:
                qcue_wake(parser)
                force_render(parser)

        thread = threading.Thread(target=_worker, name=f'q-worker-{task_id or "?"}', daemon=True)
        thread.start()
    except Exception as exc:
        if q_root:
            write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_start_error')
            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_start_error_status')
        bookkeeping_error = None
        if alias and task_id:
            try:
                qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                qcue_wake(parser)
            except Exception as bk_exc:
                bookkeeping_error = bk_exc
        if bookkeeping_error is not None:
            if q_root:
                try:
                    write_text_symbol(parser.state, f'{q_root}:error', f'worker-start bookkeeping error: {bookkeeping_error}', 'q_async_start_bookkeeping_error')
                    write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_start_bookkeeping_error_status')
                except Exception:
                    pass
            raise bookkeeping_error from exc
        raise


def _scheduler_loop(parser) -> None:
    runtime = qcue_runtime(parser)
    wake = qcue_wake_event(parser)
    try:
        while True:
            wake.wait()
            while True:
                wake.clear()
                task = qcue_claim_next_runnable(parser)
                if task is None:
                    break
                try:
                    _start_worker(parser, task)
                except Exception as exc:
                    runtime['last_error'] = str(exc or '')
                    q_root = str(task.get('q_root') or '')
                    alias = str(task.get('alias') or '')
                    task_id = str(task.get('task_id') or '')
                    if q_root:
                        try:
                            write_text_symbol(parser.state, f'{q_root}:error', f'scheduler start error: {exc}', 'q_scheduler_start_error')
                            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_scheduler_start_error_status')
                        except Exception:
                            pass
                    if alias and task_id:
                        qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                    qcue_wake(parser)
                    force_render(parser)
                    continue
    except Exception as exc:
        runtime['last_error'] = str(exc or '')
        raise
    finally:
        with qcue_lock(parser):
            qcue_thread_set(parser, None)
            qcue_set_started(parser, False)


def _ensure_scheduler(parser) -> None:
    runtime = qcue_runtime(parser)
    thread = threading.Thread(target=_scheduler_loop, args=(parser,), name='q-cue-scheduler', daemon=True)
    with qcue_lock(parser):
        existing = qcue_thread_get(parser)
        if qcue_started(parser) and existing is not None and existing.is_alive():
            return
        qcue_thread_set(parser, None)
        qcue_set_started(parser, False)

    try:
        thread.start()
    except Exception:
        with qcue_lock(parser):
            qcue_thread_set(parser, None)
            qcue_set_started(parser, False)
        raise

    with qcue_lock(parser):
        qcue_thread_set(parser, thread)
        qcue_set_started(parser, True)
        runtime['last_error'] = ''


def _enqueue_query(parser, command_token: str, q_root: str, prompt: str) -> None:
    alias = _alias_from_command_token(command_token)
    qcue_enqueue(parser, alias, command_token, q_root, prompt)
    _ensure_scheduler(parser)
    qcue_wake(parser)
    force_render(parser)


def handler(line: str, parser):
    try:
        command_token, raw_target, prompt = _parse_q_target_prompt(line)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    try:
        q_root = resolve_querytarget(raw_target, get_layout_caller_handle(parser))
        _enqueue_query(parser, command_token, q_root, prompt)
    except QCallError as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    return HandlerResponse(buffer_output='', force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
