from __future__ import annotations

from typing import Any, Callable

from .errors import QCallError
from .live import chunk_q_live, done_q_live, fail_q_live, open_q_live
from .profile import get_profile, resolve_profile_name, set_active_profile
from .prompt import expand_prompt_symbols
from .providers import decode_qc_output, profile_has_stream, extract_chat, strip_inline_think_markup
from .roles import resolve_role_value
from .sampler import ensure_q_sampler_state
from .state import merge_thinking_stream, append_response_stream, write_text_symbol, load_chat, load_role, open_chat_entry, save_chat, write_chat_entry
from .symbols import exact_q_state_root_for_runtime
from .transport import call_profile, stream_profile
from .common import clean_model_value, coerce_bool, coerce_jsonish_list, normalize_think_value, think_is_enabled, read_state_value


def _coerce_toggle(value: Any, default: bool = True) -> bool:
    clean = str(value or '').strip().lower()
    if not clean:
        return bool(default)
    if clean in {'0', 'false', 'no', 'off'}:
        return False
    if clean in {'1', 'true', 'yes', 'on'}:
        return True
    return bool(default)


def _resolve_show_thinking(state, q_root: str) -> bool:
    raw = read_state_value(state, f'{q_root}:view:show_thinking', 'on')
    return _coerce_toggle(raw, True)


def _require_exact_q_root(parser) -> str:
    q_root = exact_q_state_root_for_runtime(parser)
    if not q_root:
        raise QCallError('q requires active q runtime root')
    return q_root


_Q_RUNTIME_PROFILE_FIELDS = (
    'model',
    'stream',
    'think',
    'temperature',
    'top_k',
    'top_p',
    'repeat_penalty',
    'max_tokens',
    'seed',
    'num_ctx',
    'stop',
)


def _normalize_runtime_profile_field(key: str, value: Any) -> Any:
    if value in (None, ''):
        return None
    if key == 'model':
        return clean_model_value(value)
    if key == 'stream':
        return coerce_bool(value, None)
    if key == 'think':
        return normalize_think_value(value, None)
    if key == 'top_k':
        try:
            return int(value)
        except Exception:
            return None
    if key in {'temperature', 'top_p', 'repeat_penalty'}:
        try:
            return float(value)
        except Exception:
            return None
    if key in {'max_tokens', 'seed', 'num_ctx'}:
        try:
            return int(value)
        except Exception:
            return None
    if key == 'stop':
        stop_values = coerce_jsonish_list(value)
        return stop_values if stop_values else None
    return value


def _runtime_profile_overrides(state, q_root: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key in _Q_RUNTIME_PROFILE_FIELDS:
        raw = read_state_value(state, f'{q_root}:{key}', None)
        value = _normalize_runtime_profile_field(key, raw)
        if value not in (None, ''):
            out[key] = value
    return out


def _build_runtime_q_profile(parser, profile_name: str, q_root: str) -> dict[str, Any]:
    profile = get_profile(parser, profile_name, include_runtime_overrides=False)
    effective = dict(profile)
    effective.update(_runtime_profile_overrides(parser.state, q_root))
    return effective


def prepare_q_session(parser, command_token: str, prompt: str) -> dict:
    profile_name = resolve_profile_name(parser, command_token, 'q')
    q_state_root = _require_exact_q_root(parser)
    profile = _build_runtime_q_profile(parser, profile_name, q_state_root)
    set_active_profile(parser, profile_name)

    chat_symbol = f'{q_state_root}:ch'
    role_symbol = f'{q_state_root}:role'
    system_prompt_symbol = f'{q_state_root}:system_prompt'
    response_symbol = f'{q_state_root}:view:response'
    thinking_symbol = f'{q_state_root}:view:thinking'
    chat = load_chat(parser.state, chat_symbol)
    role = load_role(parser.state, system_prompt_symbol)
    expanded_prompt = expand_prompt_symbols(parser, prompt)
    think_value = profile.get('think')
    show_thinking = _resolve_show_thinking(parser.state, q_state_root)

    return {
        'profile_name': profile_name,
        'profile': profile,
        'state': parser.state,
        'q_state_root': q_state_root,
        'chat_symbol': chat_symbol,
        'role_symbol': role_symbol,
        'system_prompt_symbol': system_prompt_symbol,
        'response_symbol': response_symbol,
        'thinking_symbol': thinking_symbol,
        'prompt': prompt,
        'expanded_prompt': expanded_prompt,
        'role': role,
        'chat': chat,
        'stream_enabled': 1 if profile_has_stream(profile) else 0,
        'think_value': think_value,
        'show_thinking': show_thinking,
    }


def run_nonstream_session(session: dict) -> str:
    payload = call_profile(
        session['profile'],
        session['expanded_prompt'],
        role=session['role'],
        chat=session['chat'],
        state=None,
        profile_name=session.get('profile_name', 'default'),
        think_value=session.get('think_value'),
    )
    return strip_inline_think_markup(extract_chat(payload, session['profile'].get('chat_message_tag')))


def q_chat(parser, command_token: str, prompt: str, on_chunk: Callable[[str, str, str, str], None] | None = None, on_done: Callable[[str, str, str], None] | None = None) -> dict:
    session = prepare_q_session(parser, command_token, prompt)
    profile_name = session['profile_name']
    chat_symbol = session['chat_symbol']
    response_symbol = session['response_symbol']
    thinking_symbol = session['thinking_symbol']
    think_value = session.get('think_value')
    thinking_enabled = think_is_enabled(think_value, None)
    show_thinking = bool(session.get('show_thinking', True))

    write_text_symbol(parser.state, response_symbol, '', 'response_reset')
    write_text_symbol(parser.state, thinking_symbol, '', 'thinking_reset')

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key='', prompt=prompt, response='', thinking='')

    if not session['stream_enabled']:
        final_text = run_nonstream_session(session)
        chat_log = dict(session['chat'])
        key = str(max([int(k) for k in chat_log.keys() if str(k).isdigit()] + [0]) + 1)
        chat_log[key] = {'prompt': prompt, 'response': final_text, 'done': 1}
        save_chat(parser.state, chat_symbol, chat_log)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}

    key = open_chat_entry(parser.state, chat_symbol, prompt)
    final_text = ''
    final_thinking = ''
    last_written_response = ''

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response='', thinking='')

    try:
        for event in stream_profile(session['profile'], session['expanded_prompt'], role=session['role'], chat=session['chat'], state=None, profile_name=session.get('profile_name', 'default'), think_value=session.get('think_value')):
            raw_thinking_chunk = strip_inline_think_markup(event.get('thinking') or '')
            content_chunk = strip_inline_think_markup(event.get('content') or '')
            event_done = 1 if int(event.get('done') or 0) == 1 else 0

            thinking_chunk = raw_thinking_chunk
            if thinking_enabled is False:
                thinking_chunk = ''

            if thinking_chunk:
                final_thinking = merge_thinking_stream(final_thinking, thinking_chunk)
            if content_chunk:
                final_text = append_response_stream(final_text, content_chunk)

            visible_response = strip_inline_think_markup(final_text)
            visible_thinking = ''
            if show_thinking and not visible_response and final_thinking:
                visible_thinking = final_thinking

            write_text_symbol(parser.state, response_symbol, visible_response, 'response_partial')
            write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
            if visible_response != last_written_response:
                write_chat_entry(parser.state, chat_symbol, key, prompt, visible_response, done=0)
                last_written_response = visible_response
            chunk_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=visible_response, thinking=visible_thinking)

            if callable(on_chunk) and (thinking_chunk or content_chunk):
                on_chunk(content_chunk or thinking_chunk, visible_response, chat_symbol, key)

            if event_done == 1:
                break

        final_text = strip_inline_think_markup(final_text)
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')

        if callable(on_done):
            on_done(final_text, chat_symbol, key)

    except Exception:
        final_text = strip_inline_think_markup(final_text)
        visible_thinking = ''
        if show_thinking and not final_text and final_thinking:
            visible_thinking = final_thinking
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=0)
        write_text_symbol(parser.state, response_symbol, final_text, 'response_partial')
        write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
        fail_q_live(parser, 'q stream interrupted', profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking=visible_thinking)
        raise

    return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}




def _parse_qc_token(command_token: str) -> tuple[str, str]:
    token = str(command_token or '').strip()
    if token == 'qc':
        return 'default', ''
    if not token.startswith('qc'):
        raise QCallError('usage: qc[.<profile>][.r.<role>] <output> <prompt...>')
    if token.startswith('qc.r.'):
        return 'default', token[len('qc.r.'):].strip()
    if token.startswith('qc.'):
        tail = token[len('qc.'):].strip()
        if '.r.' in tail:
            profile_name, role_name = tail.split('.r.', 1)
            return (profile_name.strip() or 'default', role_name.strip())
        return tail or 'default', ''
    raise QCallError('usage: qc[.<profile>][.r.<role>] <output> <prompt...>')



def qc_raw(parser, command_token: str, *args: Any) -> dict:
    flat_args: list[Any] = []
    for item in args:
        if isinstance(item, (list, tuple)):
            flat_args.extend(item)
        else:
            flat_args.append(item)
    if not flat_args:
        raise QCallError('qc requires prompt')
    prompt = ' '.join(str(x) for x in flat_args).strip()
    if not prompt:
        raise QCallError('qc requires prompt')

    profile_name, role_name = _parse_qc_token(command_token)
    profile = get_profile(parser, profile_name, include_runtime_overrides=False)
    role_text = ''
    if role_name:
        resolved = resolve_role_value(parser.state, role_name)
        if str(resolved.get('kind') or '') != 'preset':
            raise QCallError(f'qc role preset not found: {role_name}')
        profile = dict(profile)
        profile.update(dict(resolved.get('profile_overrides') or {}))
        role_text = str(resolved.get('system_prompt') or '')

    payload = call_profile(profile, expand_prompt_symbols(parser, prompt), role=role_text, chat={}, state=None, profile_name=profile_name, think_value=profile.get('think'))
    output = decode_qc_output(payload, profile.get('chat_message_tag'))
    return {'profile': profile_name, 'output': output, 'decoded': output}


__all__ = [
    'prepare_q_session',
    'run_nonstream_session',
    'q_chat',
    'qc_raw',
]
