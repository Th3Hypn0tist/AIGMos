from __future__ import annotations

from typing import Any
import threading

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_layout_caller_handle
from system.lib.q.errors import QCallError
from system.lib.q.qcue import (
    qcue_active_get,
    qcue_active_set,
    qcue_alias_get,
    qcue_alias_set,
    qcue_claim_next_runnable,
    qcue_enqueue,
    qcue_lock,
    qcue_queue_pop,
    qcue_queue_push,
    qcue_runtime,
    qcue_set_started,
    qcue_started,
    qcue_state_get,
    qcue_state_set,
    qcue_thread_set,
    qcue_wake,
    qcue_wake_event,
    qcue_seq_next,
)
from system.lib.q.session import q_chat
from system.lib.q.state import write_text_symbol
from system.layout.lib.targets import resolve_querytarget

command = 'q'
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful chat/query dispatch

rules:
- target is explicit
- dispatches query asynchronously
- does not return successful assistant output to command buffer
- writes prompt/status into q runtime immediately
- queue truth lives in #SYSTEM:Qcue
- one active slot per q runtime root; queued FIFO per profile alias

examples:
  q |:q hello
  q |HELP:q explain #HELP:README.md
  q.coder |:q refactor this
"""


def _parse_q_target_prompt(line: str) -> tuple[str, str, str]:
    raw = str(line or '').strip()
    parts = raw.split(maxsplit=2)
    if len(parts) < 3:
        raise ValueError('usage: q[.profile] <target> <prompt...>')
    command_token, target, prompt = parts[0], parts[1], parts[2]
    if not prompt or not prompt.strip():
        raise ValueError('q requires prompt')
    return command_token, target, prompt


def _alias_from_command_token(command_token: str) -> str:
    return str(command_token.split('.', 1)[1] if '.' in command_token else 'default').strip() or 'default'


# canonical #SYSTEM:Qcue wrappers kept here so command-side code stays explicit

def _qcue_state_get(parser_or_state) -> dict[str, Any]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_state_get(state)


def _qcue_state_set(parser_or_state, data: dict[str, Any]) -> dict[str, Any]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_state_set(state, data)


def _qcue_alias_get(parser_or_state, alias: str) -> dict[str, Any]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_alias_get(state, alias)


def _qcue_alias_set(parser_or_state, alias: str, alias_data: dict[str, Any]) -> dict[str, Any]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_alias_set(state, alias, alias_data)


def _qcue_queue_push(parser_or_state, alias: str, entry: dict[str, Any]) -> dict[str, Any]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_queue_push(state, alias, entry)


def _qcue_queue_pop(parser_or_state, alias: str, index: str | int | None = None):
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_queue_pop(state, alias, index)


def _qcue_active_get(parser_or_state, alias: str) -> dict[str, str]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_active_get(state, alias)


def _qcue_active_set(parser_or_state, alias: str, active: dict[str, str]) -> dict[str, str]:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_active_set(state, alias, active)


def _qcue_seq_next(parser_or_state) -> str:
    state = getattr(parser_or_state, 'state', parser_or_state)
    return qcue_seq_next(state)


def _set_prompt_status(parser, q_root: str, prompt: str, status: str, *, clear_error: bool = True) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_set')
    write_text_symbol(parser.state, f'{clean_root}:status', str(status or ''), 'status_set')
    write_text_symbol(parser.state, f'{clean_root}:response', '', 'response_reset')
    write_text_symbol(parser.state, f'{clean_root}:thinking_text', '', 'thinking_reset')
    if clear_error:
        write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_reset')


def _start_worker(parser, task: dict[str, Any]) -> None:
    def _worker() -> None:
        q_root = str(task.get('q_root') or '')
        task_id = str(task.get('task_id') or '')
        alias = str(task.get('alias') or '')
        try:
            def _on_chunk(_chunk: str, _full_text: str, _chat_symbol: str, _key: str) -> None:
                force_render(parser)

            def _on_done(_full_text: str, _chat_symbol: str, _key: str) -> None:
                force_render(parser)

            q_chat(
                parser,
                str(task.get('command_token') or 'q'),
                str(task.get('prompt') or ''),
                q_root_override=q_root,
                queue_meta={
                    'alias': alias,
                    'q_root': q_root,
                    'task_id': task_id,
                },
                on_chunk=_on_chunk,
                on_done=_on_done,
            )
        except Exception as exc:
            if q_root:
                try:
                    write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_error')
                    write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_error_status')
                except Exception:
                    pass
            force_render(parser)
        finally:
            qcue_wake(parser)
            force_render(parser)

    threading.Thread(target=_worker, name=f'q-worker-{task.get("task_id") or "?"}', daemon=True).start()


def _scheduler_loop(parser) -> None:
    wake = qcue_wake_event(parser)
    while True:
        wake.wait()
        while True:
            wake.clear()
            task = qcue_claim_next_runnable(parser)
            if task is None:
                break
            _start_worker(parser, task)


def _ensure_scheduler(parser) -> None:
    runtime = qcue_runtime(parser)
    with qcue_lock(parser):
        if qcue_started(parser):
            return
        qcue_set_started(parser, True)
    thread = threading.Thread(target=_scheduler_loop, args=(parser,), name='q-cue-scheduler', daemon=True)
    qcue_thread_set(parser, thread)
    runtime['thread'] = thread
    thread.start()


def _enqueue_query(parser, command_token: str, q_root: str, prompt: str) -> None:
    alias = _alias_from_command_token(command_token)
    task = qcue_enqueue(parser, alias, command_token, q_root, prompt)
    if q_root:
        _set_prompt_status(parser, q_root, prompt, 'waiting', clear_error=True)
    _ensure_scheduler(parser)
    qcue_wake(parser)
    force_render(parser)


def handler(line: str, parser):
    try:
        command_token, raw_target, prompt = _parse_q_target_prompt(line)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    try:
        q_root = resolve_querytarget(raw_target, get_layout_caller_handle(parser))
        _enqueue_query(parser, command_token, q_root, prompt)
    except QCallError as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    return HandlerResponse(buffer_output='', force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
