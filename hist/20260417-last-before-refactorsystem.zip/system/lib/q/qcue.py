from __future__ import annotations

from typing import Any
import threading

from system.cs.runtime_ctx import runtime_map
from system.state.api import read_value, write_value


QCUE_ROOT = '#SYSTEM:Qcue'
QCUE_WRITER = 'qcue'
_VALID_STATUSES = {'waiting', 'running', 'done', 'error'}


def _runtime(parser) -> dict[str, Any]:
    rt = runtime_map(parser)
    cue = rt.get('q_cue')
    if isinstance(cue, dict):
        lock = cue.get('lock')
        wake = cue.get('wake')
        if isinstance(lock, threading.RLock().__class__) and isinstance(wake, threading.Event):
            return cue
    cue = {
        'lock': threading.RLock(),
        'wake': threading.Event(),
        'started': False,
        'thread': None,
    }
    rt['q_cue'] = cue
    return cue


def qcue_runtime(parser) -> dict[str, Any]:
    return _runtime(parser)


def qcue_lock(parser):
    return _runtime(parser)['lock']


def qcue_wake(parser) -> None:
    _runtime(parser)['wake'].set()


def qcue_wake_event(parser):
    return _runtime(parser)['wake']


def qcue_started(parser) -> bool:
    return bool(_runtime(parser).get('started'))


def qcue_set_started(parser, value: bool) -> None:
    _runtime(parser)['started'] = bool(value)


def qcue_thread_get(parser):
    return _runtime(parser).get('thread')


def qcue_thread_set(parser, thread) -> None:
    _runtime(parser)['thread'] = thread


def _normalize_status(value: Any, default: str = 'waiting') -> str:
    text = str(value or '').strip().lower()
    return text if text in _VALID_STATUSES else default


def _task_payload(task: Any, *, alias: str = '') -> dict[str, Any]:
    data = dict(task) if isinstance(task, dict) else {}
    out = {
        'task_id': str(data.get('task_id') or ''),
        'q_root': str(data.get('q_root') or ''),
        'prompt': str(data.get('prompt') or ''),
        'status': _normalize_status(data.get('status'), 'waiting'),
    }
    command_token = str(data.get('command_token') or '')
    if command_token:
        out['command_token'] = command_token
    clean_alias = str(data.get('alias') or alias or '')
    if clean_alias:
        out['alias'] = clean_alias
    error = str(data.get('error') or '')
    if error:
        out['error'] = error
    return out


def _sorted_numeric_items(value: Any) -> list[tuple[str, Any]]:
    if isinstance(value, list):
        return [(str(idx), item) for idx, item in enumerate(value)]
    if not isinstance(value, dict):
        return []

    def _key(pair: tuple[str, Any]):
        key = str(pair[0])
        return (0, int(key)) if key.isdigit() else (1, key)

    return sorted(((str(key), item) for key, item in value.items()), key=_key)


def _queue_payload(value: Any, *, alias: str = '') -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for _old_key, item in _sorted_numeric_items(value):
        if not isinstance(item, dict):
            continue
        out[str(len(out))] = _task_payload(item, alias=alias)
    return out


def _history_payload(value: Any, *, alias: str = '') -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for key, item in _sorted_numeric_items(value):
        if not isinstance(item, dict):
            continue
        payload = _task_payload(item, alias=alias)
        task_id = str(payload.get('task_id') or key or '')
        if not task_id:
            continue
        payload['task_id'] = task_id
        out[task_id] = payload
    return out


def _active_payload(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    out: dict[str, str] = {}
    for key, item in value.items():
        q_root = str(key or '').strip()
        task_id = str(item or '').strip()
        if q_root and task_id:
            out[q_root] = task_id
    return out


def _alias_payload(alias: str, value: Any) -> dict[str, Any]:
    src = dict(value) if isinstance(value, dict) else {}
    return {
        'queue': _queue_payload(src.get('queue'), alias=alias),
        'active': _active_payload(src.get('active')),
        'history': _history_payload(src.get('history'), alias=alias),
    }


def _state_payload(value: Any) -> dict[str, Any]:
    src = dict(value) if isinstance(value, dict) else {}
    try:
        seq = int(src.get('seq') or 0)
    except Exception:
        seq = 0
    aliases_raw = src.get('aliases') if isinstance(src.get('aliases'), dict) else {}
    aliases: dict[str, dict[str, Any]] = {}
    for key, item in aliases_raw.items():
        alias = str(key or '').strip()
        if not alias:
            continue
        aliases[alias] = _alias_payload(alias, item)
    return {
        'seq': max(0, seq),
        'aliases': aliases,
    }


def qcue_state_get(state) -> dict[str, Any]:
    raw = read_value(state, QCUE_ROOT, {})
    return _state_payload(raw)


def qcue_state_set(state, data: dict[str, Any]) -> dict[str, Any]:
    payload = _state_payload(data)
    out = write_value(state, QCUE_ROOT, payload, writer=QCUE_WRITER, op='qcue_set')
    if out.get('error'):
        raise RuntimeError(str(out.get('error') or 'failed to write #SYSTEM:Qcue'))
    return payload


def qcue_alias_get(state, alias: str) -> dict[str, Any]:
    clean = str(alias or '').strip() or 'default'
    data = qcue_state_get(state)
    return _alias_payload(clean, (data.get('aliases') or {}).get(clean))


def qcue_alias_set(state, alias: str, alias_data: dict[str, Any]) -> dict[str, Any]:
    clean = str(alias or '').strip() or 'default'
    data = qcue_state_get(state)
    aliases = dict(data.get('aliases') or {})
    aliases[clean] = _alias_payload(clean, alias_data)
    data['aliases'] = aliases
    qcue_state_set(state, data)
    return aliases[clean]


def qcue_active_get(state, alias: str) -> dict[str, str]:
    return dict(qcue_alias_get(state, alias).get('active') or {})


def qcue_active_set(state, alias: str, active: dict[str, str]) -> dict[str, str]:
    alias_data = qcue_alias_get(state, alias)
    alias_data['active'] = _active_payload(active)
    return dict(qcue_alias_set(state, alias, alias_data).get('active') or {})


def qcue_seq_next(state_or_data) -> str:
    if isinstance(state_or_data, dict) and 'aliases' in state_or_data and 'seq' in state_or_data:
        data = state_or_data
        data['seq'] = int(data.get('seq') or 0) + 1
        return str(data['seq'])
    data = qcue_state_get(state_or_data)
    task_id = qcue_seq_next(data)
    qcue_state_set(state_or_data, data)
    return task_id


def _queue_items(alias_data: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    return [(key, dict(item)) for key, item in _sorted_numeric_items(alias_data.get('queue')) if isinstance(item, dict)]


def qcue_queue_push(state_or_alias, alias_or_entry, entry: dict[str, Any] | None = None) -> dict[str, Any]:
    state = state_or_alias
    alias = str(alias_or_entry or '').strip() or 'default'
    payload = _task_payload(entry, alias=alias)
    data = qcue_state_get(state)
    aliases = dict(data.get('aliases') or {})
    alias_data = _alias_payload(alias, aliases.get(alias))
    queue = _queue_payload(alias_data.get('queue'), alias=alias)
    queue[str(len(queue))] = payload
    alias_data['queue'] = queue
    aliases[alias] = alias_data
    data['aliases'] = aliases
    qcue_state_set(state, data)
    return payload


def qcue_queue_pop(state_or_alias, alias: str | None = None, index: str | int | None = None):
    state = state_or_alias
    clean_alias = str(alias or '').strip() or 'default'
    data = qcue_state_get(state)
    aliases = dict(data.get('aliases') or {})
    alias_data = _alias_payload(clean_alias, aliases.get(clean_alias))
    items = _queue_items(alias_data)
    if not items:
        return None
    picked_key = None
    if index is None:
        picked_key = items[0][0]
    else:
        idx_text = str(index)
        for key, _item in items:
            if key == idx_text:
                picked_key = key
                break
    if picked_key is None:
        return None
    task = dict((alias_data.get('queue') or {}).get(picked_key) or {})
    queue = dict(alias_data.get('queue') or {})
    queue.pop(picked_key, None)
    alias_data['queue'] = _queue_payload(queue, alias=clean_alias)
    aliases[clean_alias] = alias_data
    data['aliases'] = aliases
    qcue_state_set(state, data)
    return _task_payload(task, alias=clean_alias)


def qcue_enqueue(parser, alias: str, command_token: str, q_root: str, prompt: str) -> dict[str, Any]:
    clean_alias = str(alias or '').strip() or 'default'
    clean_q_root = str(q_root or '').strip()
    with qcue_lock(parser):
        data = qcue_state_get(parser.state)
        task_id = qcue_seq_next(data)
        entry = _task_payload({
            'task_id': task_id,
            'alias': clean_alias,
            'q_root': clean_q_root,
            'command_token': str(command_token or 'q'),
            'prompt': str(prompt or ''),
            'status': 'waiting',
        }, alias=clean_alias)
        aliases = dict(data.get('aliases') or {})
        alias_data = _alias_payload(clean_alias, aliases.get(clean_alias))
        queue = _queue_payload(alias_data.get('queue'), alias=clean_alias)
        queue[str(len(queue))] = entry
        alias_data['queue'] = queue
        aliases[clean_alias] = alias_data
        data['aliases'] = aliases
        qcue_state_set(parser.state, data)
    return entry


def qcue_claim_next_runnable(parser) -> dict[str, Any] | None:
    with qcue_lock(parser):
        data = qcue_state_get(parser.state)
        aliases = dict(data.get('aliases') or {})
        for alias in sorted(aliases.keys()):
            alias_data = _alias_payload(alias, aliases.get(alias))
            queue_items = _queue_items(alias_data)
            active = dict(alias_data.get('active') or {})
            picked_key = None
            picked_task = None
            for key, candidate in queue_items:
                task = _task_payload(candidate, alias=alias)
                if task.get('status') != 'waiting':
                    continue
                q_root = str(task.get('q_root') or '')
                if not q_root:
                    continue
                if str(active.get(q_root) or '').strip():
                    continue
                picked_key = key
                picked_task = task
                break
            if picked_key is None or picked_task is None:
                continue
            queue = dict(alias_data.get('queue') or {})
            picked_task['status'] = 'running'
            queue[picked_key] = picked_task
            alias_data['queue'] = _queue_payload(queue, alias=alias)
            active[str(picked_task.get('q_root') or '')] = str(picked_task.get('task_id') or '')
            alias_data['active'] = _active_payload(active)
            aliases[alias] = alias_data
            data['aliases'] = aliases
            qcue_state_set(parser.state, data)
            return dict(picked_task)
    return None


def qcue_complete(parser, alias: str, q_root: str, task_id: str, status: str, *, error: str = '') -> dict[str, Any] | None:
    clean_alias = str(alias or '').strip() or 'default'
    clean_q_root = str(q_root or '').strip()
    clean_task_id = str(task_id or '').strip()
    clean_status = _normalize_status(status, 'done')
    with qcue_lock(parser):
        data = qcue_state_get(parser.state)
        aliases = dict(data.get('aliases') or {})
        alias_data = _alias_payload(clean_alias, aliases.get(clean_alias))
        queue = dict(alias_data.get('queue') or {})
        history = dict(alias_data.get('history') or {})
        active = dict(alias_data.get('active') or {})

        finished = None
        remove_key = None
        for key, item in _queue_items(alias_data):
            payload = _task_payload(item, alias=clean_alias)
            if str(payload.get('task_id') or '') == clean_task_id:
                finished = payload
                remove_key = key
                break
        if finished is None:
            payload = history.get(clean_task_id)
            if isinstance(payload, dict):
                finished = _task_payload(payload, alias=clean_alias)
        if finished is None:
            return None

        finished['status'] = clean_status
        if clean_q_root:
            finished['q_root'] = clean_q_root
        if error:
            finished['error'] = str(error)
        elif 'error' in finished and clean_status != 'error':
            finished.pop('error', None)

        if remove_key is not None:
            queue.pop(remove_key, None)
        queue = _queue_payload(queue, alias=clean_alias)
        history[clean_task_id] = finished
        if clean_q_root and str(active.get(clean_q_root) or '') == clean_task_id:
            active.pop(clean_q_root, None)
        else:
            for root, active_task_id in list(active.items()):
                if str(active_task_id or '') == clean_task_id:
                    active.pop(root, None)

        alias_data['queue'] = queue
        alias_data['history'] = _history_payload(history, alias=clean_alias)
        alias_data['active'] = _active_payload(active)
        aliases[clean_alias] = alias_data
        data['aliases'] = aliases
        qcue_state_set(parser.state, data)
        return dict(finished)


def qcue_lookup_root(state, q_root: str) -> dict[str, Any] | None:
    clean_q_root = str(q_root or '').strip()
    if not clean_q_root:
        return None
    data = qcue_state_get(state)
    aliases = dict(data.get('aliases') or {})
    best_waiting = None
    for alias in sorted(aliases.keys()):
        alias_data = _alias_payload(alias, aliases.get(alias))
        active = dict(alias_data.get('active') or {})
        queue_items = _queue_items(alias_data)
        for pos, (_key, item) in enumerate(queue_items, start=1):
            payload = _task_payload(item, alias=alias)
            if str(payload.get('q_root') or '') != clean_q_root:
                continue
            task_id = str(payload.get('task_id') or '')
            is_active = str(active.get(clean_q_root) or '') == task_id
            info = {
                'alias': alias,
                'task_id': task_id,
                'q_root': clean_q_root,
                'status': 'running' if is_active else str(payload.get('status') or 'waiting'),
                'position': pos,
                'prompt': str(payload.get('prompt') or ''),
                'active': is_active,
            }
            if is_active or info['status'] == 'running':
                return info
            if best_waiting is None:
                best_waiting = info
        history = dict(alias_data.get('history') or {})
        for task_id, item in history.items():
            payload = _task_payload(item, alias=alias)
            if str(payload.get('q_root') or '') != clean_q_root:
                continue
            hist = {
                'alias': alias,
                'task_id': str(payload.get('task_id') or task_id or ''),
                'q_root': clean_q_root,
                'status': str(payload.get('status') or ''),
                'position': None,
                'prompt': str(payload.get('prompt') or ''),
                'active': False,
            }
            if best_waiting is None:
                best_waiting = hist
    return best_waiting


__all__ = [
    'QCUE_ROOT',
    'qcue_runtime',
    'qcue_lock',
    'qcue_wake',
    'qcue_wake_event',
    'qcue_started',
    'qcue_set_started',
    'qcue_thread_get',
    'qcue_thread_set',
    'qcue_state_get',
    'qcue_state_set',
    'qcue_alias_get',
    'qcue_alias_set',
    'qcue_queue_push',
    'qcue_queue_pop',
    'qcue_active_get',
    'qcue_active_set',
    'qcue_seq_next',
    'qcue_enqueue',
    'qcue_claim_next_runnable',
    'qcue_complete',
    'qcue_lookup_root',
]
