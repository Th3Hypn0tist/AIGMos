from __future__ import annotations

import threading
import time

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_layout_caller_handle
from system.lib.q.errors import QCallError
from system.lib.q.qcue import (
    qcue_claim_next_runnable,
    qcue_complete,
    qcue_lock,
    qcue_runtime,
    qcue_set_started,
    qcue_started,
    qcue_thread_get,
    qcue_thread_set,
    qcue_wake,
    qcue_wake_event,
    qcue_enqueue,
)
from system.lib.q.session import q_chat, qc_raw
from system.lib.q.state import write_text_symbol
from system.layout.lib.targets import resolve_querytarget
from system.layout.lib.editor import mark_dirty
from system.layout.instances import list_instances, get_instance
from system.state.api import write_value

command = 'q'
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful chat/query dispatch

rules:
- target is explicit
- dispatches query asynchronously
- does not return successful assistant output to command buffer
- queue truth lives in #SYSTEM:Qcue
- q-root live fields are active-render cache only
- queued items do not overwrite active q-root live state
- one global active slot per q runtime root; queued FIFO per profile alias

examples:
  q |:q hello
  q |HELP:q explain #HELP:README.md
  q.coder |:q refactor this
"""


def _parse_q_target_prompt(line: str) -> tuple[str, str, str]:
    raw = str(line or '').strip()
    parts = raw.split(maxsplit=2)
    if len(parts) < 3:
        raise ValueError('usage: q[.profile] <target> <prompt...>')
    command_token, target, prompt = parts[0], parts[1], parts[2]
    if not prompt or not prompt.strip():
        raise ValueError('q requires prompt')
    return command_token, target, prompt


def _alias_from_command_token(command_token: str) -> str:
    return str(command_token.split('.', 1)[1] if '.' in command_token else 'default').strip() or 'default'


def _ctx(parser) -> dict:
    runtime = getattr(parser, 'runtime', None)
    if isinstance(runtime, dict):
        ctx = runtime.get('ctx')
        if isinstance(ctx, dict):
            return ctx
    return {}


def _q_root_module_handles(parser, q_root: str) -> list[str]:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return []
    ctx = _ctx(parser)
    if not ctx:
        return []
    handles: list[str] = []
    try:
        for handle in list_instances(ctx):
            try:
                inst = get_instance(ctx, handle)
            except Exception:
                continue
            module_name = str(getattr(inst, 'MODULE', '') or '').strip().lower()
            primary = str(getattr(inst, 'primary_target', '') or '').strip()
            if primary != clean_root:
                continue
            if module_name in {'q', 'qmon'}:
                handles.append(str(getattr(inst, 'handle', handle) or handle))
    except Exception:
        return []
    return handles


def _mark_q_root_dirty(parser, q_root: str, *, throttle_seconds: float = 0.05, force: bool = False) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    ctx = _ctx(parser)
    if not ctx:
        if force:
            force_render(parser)
        return
    runtime = qcue_runtime(parser)
    render_state = runtime.setdefault('render', {})
    last_by_root = render_state.setdefault('last_by_root', {})
    now = time.monotonic()
    if not force:
        last = float(last_by_root.get(clean_root, 0.0) or 0.0)
        if last > 0.0 and (now - last) < max(0.0, float(throttle_seconds or 0.0)):
            return
    handles = _q_root_module_handles(parser, clean_root)
    if handles:
        for handle in handles:
            try:
                mark_dirty(ctx, handle)
            except Exception:
                pass
        last_by_root[clean_root] = now
        return
    if force:
        force_render(parser)


def _set_active_live_state(parser, q_root: str, prompt: str, alias: str, *, clear_error: bool = True) -> None:
    clean_root = str(q_root or '').strip()
    clean_alias = str(alias or '').strip()
    if not clean_root:
        return
    # q-root fields are active-render cache only. Queue truth stays in #SYSTEM:Qcue.
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_active_set')
    write_text_symbol(parser.state, f'{clean_root}:status', 'running', 'status_running')
    write_text_symbol(parser.state, f'{clean_root}:response', '', 'response_reset')
    write_text_symbol(parser.state, f'{clean_root}:thinking_text', '', 'thinking_reset')
    write_text_symbol(parser.state, f'{clean_root}:queue_alias', clean_alias, 'queue_alias_active_set')
    if clear_error:
        write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_reset')


def _qc_writer_name(profile_name: str) -> str:
    clean = str(profile_name or 'default').strip() or 'default'
    return f'q:{clean}'


def _write_qc_output(parser, output_symbol: str, payload, profile_name: str) -> None:
    out = write_value(
        parser.state,
        output_symbol,
        payload,
        writer=_qc_writer_name(profile_name),
        op='qc',
    )
    if out.get('error'):
        raise QCallError(str(out['error']))


def enqueue_qc_command(parser, command_token: str, output_symbol: str, prompt: str) -> None:
    alias = _alias_from_command_token(command_token)
    qcue_enqueue(
        parser,
        alias,
        command_token,
        '',
        prompt,
        kind='qc',
        caller_handle=get_layout_caller_handle(parser),
        output_symbol=output_symbol,
    )
    _ensure_scheduler(parser)
    qcue_wake(parser)
    force_render(parser)


def _start_worker(parser, task: dict[str, str]) -> None:
    q_root = str(task.get('q_root') or '')
    task_id = str(task.get('task_id') or '')
    alias = str(task.get('alias') or '')
    prompt = str(task.get('prompt') or '')
    kind = str(task.get('kind') or 'q').strip().lower() or 'q'
    command_token = str(task.get('command_token') or ('qc' if kind == 'qc' else 'q'))
    caller_handle = str(task.get('caller_handle') or '')
    output_symbol = str(task.get('output_symbol') or '')

    try:
        if kind == 'q' and q_root:
            _set_active_live_state(parser, q_root, prompt, alias, clear_error=True)
            _mark_q_root_dirty(parser, q_root, force=True)

        def _run_q_task() -> None:
            def _on_chunk(_chunk: str, _full_text: str, _chat_symbol: str, _key: str) -> None:
                _mark_q_root_dirty(parser, q_root)

            def _on_done(_full_text: str, _chat_symbol: str, _key: str) -> None:
                _mark_q_root_dirty(parser, q_root, force=True)

            q_chat(
                parser,
                command_token,
                prompt,
                q_root_override=q_root,
                caller_handle_override=caller_handle or None,
                preinitialized=True,
                queue_meta={
                    'alias': alias,
                    'q_root': q_root,
                    'task_id': task_id,
                },
                on_chunk=_on_chunk,
                on_done=_on_done,
            )

        def _run_qc_task() -> None:
            if not output_symbol:
                raise QCallError('qc requires output symbol')
            try:
                result = qc_raw(
                    parser,
                    command_token,
                    prompt,
                    caller_handle_override=caller_handle or None,
                )
                _write_qc_output(
                    parser,
                    output_symbol,
                    result.get('decoded'),
                    str(result.get('profile') or _alias_from_command_token(command_token)),
                )
                qcue_complete(parser, alias, q_root, task_id, 'done')
            except Exception as exc:
                qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                raise

        def _worker() -> None:
            try:
                if kind == 'qc':
                    _run_qc_task()
                else:
                    _run_q_task()
            except Exception as exc:
                runtime = qcue_runtime(parser)
                runtime['last_error'] = f'worker fatal: {exc}'
                if q_root:
                    try:
                        write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_error')
                        write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_error_status')
                    except Exception:
                        pass
                try:
                    qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                except Exception as cleanup_exc:
                    runtime['last_error'] = f'worker cleanup fatal: {cleanup_exc}'
                    if q_root:
                        try:
                            write_text_symbol(parser.state, f'{q_root}:error', f'worker cleanup fatal: {cleanup_exc}', 'q_async_cleanup_error')
                            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_cleanup_error_status')
                        except Exception:
                            pass
                _mark_q_root_dirty(parser, q_root, force=True)
            finally:
                qcue_wake(parser)
                _mark_q_root_dirty(parser, q_root, force=True)

        thread = threading.Thread(target=_worker, name=f'q-worker-{task_id or "?"}', daemon=True)
        thread.start()
    except Exception as exc:
        if q_root:
            write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_start_error')
            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_start_error_status')
        bookkeeping_error = None
        if alias and task_id:
            try:
                qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                qcue_wake(parser)
            except Exception as bk_exc:
                bookkeeping_error = bk_exc
        if bookkeeping_error is not None:
            if q_root:
                try:
                    write_text_symbol(parser.state, f'{q_root}:error', f'worker-start bookkeeping error: {bookkeeping_error}', 'q_async_start_bookkeeping_error')
                    write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_start_bookkeeping_error_status')
                except Exception:
                    pass
            raise bookkeeping_error from exc
        raise


def _scheduler_loop(parser) -> None:
    runtime = qcue_runtime(parser)
    wake = qcue_wake_event(parser)
    try:
        while True:
            wake.wait()
            while True:
                wake.clear()
                task = qcue_claim_next_runnable(parser)
                if task is None:
                    break
                try:
                    _start_worker(parser, task)
                except Exception as exc:
                    runtime['last_error'] = str(exc or '')
                    q_root = str(task.get('q_root') or '')
                    alias = str(task.get('alias') or '')
                    task_id = str(task.get('task_id') or '')
                    if q_root:
                        try:
                            write_text_symbol(parser.state, f'{q_root}:error', f'scheduler start error: {exc}', 'q_scheduler_start_error')
                            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_scheduler_start_error_status')
                        except Exception:
                            pass
                    if alias and task_id:
                        qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                    qcue_wake(parser)
                    force_render(parser)
                    continue
    except Exception as exc:
        runtime['last_error'] = str(exc or '')
        raise
    finally:
        with qcue_lock(parser):
            qcue_thread_set(parser, None)
            qcue_set_started(parser, False)


def _ensure_scheduler(parser) -> None:
    runtime = qcue_runtime(parser)
    thread = threading.Thread(target=_scheduler_loop, args=(parser,), name='q-cue-scheduler', daemon=True)
    with qcue_lock(parser):
        existing = qcue_thread_get(parser)
        if qcue_started(parser) and existing is not None and existing.is_alive():
            return
        qcue_thread_set(parser, None)
        qcue_set_started(parser, False)

    try:
        thread.start()
    except Exception:
        with qcue_lock(parser):
            qcue_thread_set(parser, None)
            qcue_set_started(parser, False)
        raise

    with qcue_lock(parser):
        qcue_thread_set(parser, thread)
        qcue_set_started(parser, True)
        runtime['last_error'] = ''


def _enqueue_query(parser, command_token: str, q_root: str, prompt: str) -> None:
    alias = _alias_from_command_token(command_token)
    qcue_enqueue(
        parser,
        alias,
        command_token,
        q_root,
        prompt,
        kind='q',
        caller_handle=get_layout_caller_handle(parser),
    )
    _ensure_scheduler(parser)
    qcue_wake(parser)
    force_render(parser)


def handler(line: str, parser):
    try:
        command_token, raw_target, prompt = _parse_q_target_prompt(line)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    try:
        q_root = resolve_querytarget(raw_target, get_layout_caller_handle(parser))
        _enqueue_query(parser, command_token, q_root, prompt)
    except QCallError as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    return HandlerResponse(buffer_output='', force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
