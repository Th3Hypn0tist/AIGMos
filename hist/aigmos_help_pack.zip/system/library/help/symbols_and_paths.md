# Symbols and Paths

## Canonical roots

```text
$ = object field state
# = structured-address namespace
& = ordered indexed list
! = passive trigger object
@ = passive event object
% = runner handle
| = layout / layout-module runtime handle
```

## Path separator

```text
:
```

Rules:

- `.` is allowed inside a segment name.
- `:` is the structural separator.
- `|` is a real runtime namespace, not a pipe.
- use the root prefix explicitly.

Examples:

```text
$foo:bar
#OSC:9001:button:1
&jobs:0
!sensor.hot
@cooling.start
%loop.main
|Q
|Q:q
|HELP:q:role:stream
```

## Common mistake

Wrong:

```text
set HELP:q:role:stream true
```

Right:

```text
set |HELP:q:role:stream true
```

or:

```text
|HELP:q:role:stream = true
```

## Layout source-of-truth rule

`|...` is the source of truth for layout instances and layout-module runtime data.

Examples:

```text
|HELP:meta:title
|HELP:buffer
|HELP:command_history
|HELP:q:role:think
|HELP:q:ch
```
