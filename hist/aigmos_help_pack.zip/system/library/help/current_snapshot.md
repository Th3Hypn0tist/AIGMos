# Current Snapshot

This help pack is aligned to the current uploaded system snapshot and the locked Q logic.

Current high-level behavior:

- `|` is the layout/runtime instance namespace.
- `|` is its own symbol space and does not map into `$` roots.
- layout instance state is source-of-truth in `|...`.
- lowercase `q` and `qc` are the canonical commands.
- layout creation uses `new |<instance> /<module-or-layout>`.
- built-in layout templates live under `system/library/layout`.
- the help layout is `help.tmpl` and uses `role="system/help"`.

Current built-in layout templates:

```text
/cs
/help
/q
/qcs
/qmon
/xx
```

Current built-in commands:

```text
/  add  bind  binds  cat  cp  cycle  echo  emit
export.code  export.file  export.json
get  hget  hpost
import.code  import.file  import.json  import.list
loop  ls  map.files  map.structure  mk  mv  new  on
q  qc  reload  rm  run  set  trig  unbind
```

Current help role defaults:

```text
think = false
stream = true
view_thinking = true
```
