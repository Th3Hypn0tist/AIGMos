# Examples

## Create help layout

```text
new |HELP /help
```

## Create chat layout

```text
new |Q /q
```

## Switch q runtime flags

```text
|Q:q:role:stream = true
|Q:q:role:think = false
|Q:q:role:view_thinking = false
```

## Inspect q debug payload

```text
cat |Q:q:debug:transport:request_payload
```

## Remove one role field and keep it removed until reload

```text
rm |Q:q:role:stream
```

Rule:

- normal use/query/render must not regenerate removed role fields
- reload is the only operation that regenerates role-derived fields

## Import / export examples

```text
import.file ./notes.txt $docs:notes
export.file $docs:notes ./notes-out.txt
import.json $json_blob #data
export.json #data ./data.json
```

## Map examples

```text
map.structure #tree
map.files #code
```
