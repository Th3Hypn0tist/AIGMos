# Layouts and Instances

## Create

```text
new |<instance> /<module-or-layout>
```

Examples:

```text
new |HELP /help
new |Q /q
new |CS /cs
```

Creation behavior:

- `/name` first tries a layout template under `system/library/layout` or extensions.
- if no template exists, it can fall back to direct module creation.

## Runtime identity

```text
|instance = runtime identity
<layout title="..."> = default display title
```

Examples:

```text
|HELP
|Q
|Q.dev
```

## Built-in templates

### /help

```text
label -> q(id=q, role=system/help) -> cs
```

### /q

```text
label -> q(id=q) -> cs -> monitor
```

### /cs

```text
monitor -> label -> cs
```

### /qcs

```text
qmon(target=|Q:q) -> label -> cs(target=|Q)
```

### /qmon

```text
qmon(target=|Q:q)
qmon(target=|HELP:q)
```

## Inspect and remove

```text
ls |
ls |HELP
cat |HELP
cat |HELP:q
rm |HELP
rm |HELP:q:role
```

Rule:

- `rm |HANDLE` removes the whole layout instance.
- nested `rm |HANDLE:...` removes only that runtime subtree/value.

## Focus and binds

```text
bind alt-1 |Q
bind alt-2 |HELP
binds
unbind alt-1
```
