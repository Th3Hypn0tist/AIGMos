# Troubleshooting

## 1. "invalid symbol root"

Cause:

- missing root prefix such as `|`, `$`, `#`, or `&`

Wrong:

```text
set HELP:q:role:stream true
```

Right:

```text
set |HELP:q:role:stream true
```

## 2. Role field keeps coming back

Expected rule:

- normal query/render must not regenerate `|...:role:*`
- only reload regenerates role-derived fields

If a field returns immediately after a query, bindings/runtime regeneration logic is still wrong.

## 3. Payload not visible

Use:

```text
cat |HELP:q:debug:transport:request_payload
```

If empty, check that debug write is still enabled in the transport path.

## 4. raw_events empty

Most common cause:

- the call went through non-stream mode, not stream mode

Check:

```text
cat |HELP:q:role:stream
cat |HELP:q:debug:transport:request_payload
```

## 5. thinking appears inside response

Cause:

- provider returned reasoning in a content field instead of a dedicated thinking field
- or the provider-specific path is not yet mapped

First inspect:

```text
cat |HELP:q:debug:transport:raw_events
cat |HELP:q:debug:last_event
```

## 6. help bot ignores updated docs

Use reload:

```text
reload help
reload role system/help
reload roles
```

## 7. layout instance seems stale after code change

Use:

```text
reload layout
```

If the issue is role/runtime derived data, also use:

```text
reload role system/help
```
