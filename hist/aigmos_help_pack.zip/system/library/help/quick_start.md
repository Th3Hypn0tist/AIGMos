# Quick Start

## 1. Start the help bot

```text
new |HELP /help
```

Then ask through the active command surface:

```text
test
/help
/help q
```

## 2. Start a normal Q layout

```text
new |Q /q
```

Useful runtime edits:

```text
|Q:q:role:stream = true
|Q:q:role:think = false
|Q:q:role:view_thinking = false
```

## 3. Start a command-surface layout

```text
new |CS /cs
```

## 4. Inspect current state

```text
ls |
cat |Q
cat |Q:q
cat |HELP:q:role
```

## 5. Reload libraries when source files changed

```text
reload help
reload roles
reload role system/help
reload layout
reload config
reload all
```

## 6. Q debug paths kept visible for now

```text
cat |HELP:q:debug:transport:request_payload
cat |HELP:q:debug:transport:raw_events
cat |HELP:q:debug:last_event
```
