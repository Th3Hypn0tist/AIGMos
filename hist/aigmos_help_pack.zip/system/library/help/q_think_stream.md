# Q Think / Stream Logic

This is the locked model.

```text
stream = gate
think = payload-intent
view_thinking = UI-only
```

## Always show a response placeholder during execution

During an active answer, show at least:

```text
[Thinking...]
```

## 1. stream

```text
stream = true
-> payload["stream"] = true

stream = false
-> do not add stream payload field
-> think is ignored when stream = false
```

## 2. think

```text
think = true
-> merge think_payload into payload

think = false
-> merge nothink_payload into payload
```

## 3. view_thinking

```text
view_thinking = true
-> show the actual thinking process

view_thinking = false and think = true
-> show only [Thinking...]
```

Rules:

- `view_thinking` must not affect payload.
- `view_thinking` must not affect parser behavior.
- `view_thinking` must not affect stream gating.

## 4. Consequences

```text
stream = gate
think = payload-intent
view_thinking = UI-only
```

Practical reading:

- if `stream = false`, thinking is effectively off as a visible channel.
- if `stream = true`, think payload may influence model behavior.
- view control is always a UI concern only.
