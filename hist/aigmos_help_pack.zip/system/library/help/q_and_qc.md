# q and qc

## q = stateful chat

```text
q[.profile] <prompt...>
```

Behavior:

- writes chat history to the active q runtime root `:ch`
- reads optional role/runtime params from `|<instance>:<qid>:role:*`
- can stream live output into the layout q view

Examples:

```text
q hello
q.default summarize this
```

Useful inspection:

```text
cat |Q:q
cat |Q:q:ch
cat |Q:q:role
```

## qc = stateless structured call

```text
qc[.profile] <output> <prompt...>
```

Behavior:

- no chat history is written
- explicit output target
- returns decoded output into the target

Examples:

```text
qc #out hello
qc.default #out explain this briefly
```

## q runtime fields you will actually use

```text
|Q:q:role:think
|Q:q:role:stream
|Q:q:role:view_thinking
|Q:q:role:system_prompt
|Q:q:ch
|Q:q:debug:transport:request_payload
```
