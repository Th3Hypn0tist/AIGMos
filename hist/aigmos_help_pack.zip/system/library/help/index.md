# AIGMos Help Pack

This folder is the comprehensive runtime help bundle for the current locked model.

Core rules:

```text
stream = gate
think = payload-intent
view_thinking = UI-only
```

Quick start:

```text
new |HELP /help
new |Q /q
new |CS /cs
```

Most used next steps:

```text
/help
/help q
/help layouts
/help symbols
/help qlogic
```

Recommended reading order:

1. `quick_start.md`
2. `symbols_and_paths.md`
3. `layouts_and_instances.md`
4. `q_and_qc.md`
5. `q_think_stream.md`
6. `commands/`
7. `troubleshooting.md`

Bundle contents:

- `current_snapshot.md`
- `quick_start.md`
- `symbols_and_paths.md`
- `layouts_and_instances.md`
- `q_and_qc.md`
- `q_think_stream.md`
- `examples.md`
- `troubleshooting.md`
- `commands/state.md`
- `commands/layouts.md`
- `commands/q.md`
- `commands/runtime.md`
- `commands/io.md`
- `commands/slash.md`
