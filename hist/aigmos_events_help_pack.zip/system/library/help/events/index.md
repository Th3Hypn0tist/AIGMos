# Events (`@`) in AIGMos

## What `@` is

`@` denotes an **event**.

An event is a named dispatch object whose job is to send **one command line** into the command surface for execution.

The simplest mental model is:

- `@` = **what to run**
- `!` = **when to run it**
- `%` = **who keeps running logic over time**
- parser = **what actually executes the command**

## Core definition

An event is **not** a workflow engine, script language, scheduler, or trigger.
It is a thin command-dispatch layer.

One event maps to one command string.

When an event fires, AIGMos ultimately executes the event's command as if that command had been sent through the parser normally.

## Key rules

- One event = one command string
- Events are dispatched through the parser
- Events can be fired manually or by other subsystems
- Events are lightweight and should stay lightweight
- Complex logic belongs elsewhere

## Relationship to other runtime spaces

### `!` Trigger
A trigger watches a condition, comparison, edge, or schedule.
When its firing condition is met, it emits a pulse / dispatch action.
A trigger should not contain the real business logic itself.

### `@` Event
An event is the named command target that gets dispatched.
It is the action-binding layer between a trigger/runner/manual call and the parser.

### `%` Runner
A runner is a longer-lived execution context that can repeatedly or conditionally dispatch commands and events.
A runner may fire events, but it is not the same thing as an event.

## What `@` is not

`@` is not:

- a trigger
- a scheduler
- a cron system
- a state container
- a script language
- a persistent process
- a replacement for commands

## Command flow model

Typical flow:

1. A condition or system action decides something should happen
2. A trigger, runner, or manual input selects an event
3. The event resolves to its command string
4. The parser executes that command
5. Normal command output / side effects occur

## Design guidance

Use an event when you want a stable, reusable named action target.

Do not use an event to hide large control logic that should instead live in:

- a real command
- a trigger definition
- a runner loop
- explicit state logic

## Related docs

- [Model](./model.md)
- [Examples](./examples.md)
- [Errors](./errors.md)
