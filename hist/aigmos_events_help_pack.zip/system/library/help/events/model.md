# Event Model (`@`)

## Canonical model

An event is a named object that points to **one parser-executable command line**.

The authoritative mental model is:

```text
condition / manual action / runner
        -> event
        -> parser.parse("<command>")
        -> normal command execution
```

## Shape

Conceptually, an event contains:

- a name
- one command string to execute

That command string is the real payload.

## Dispatch semantics

Events should be treated as **dispatch definitions**, not as mini-programs.

When an event is fired:

- its command string is retrieved
- that command is dispatched through the parser
- the parser handles it exactly like other command input

This keeps the runtime deterministic and keeps command handling centralized.

## Separation of concerns

### Event responsibility

Event responsibility should stay narrow:

- name a reusable action target
- hold the command line that should be executed
- be easy to dispatch from other runtime systems

### Responsibilities that belong elsewhere

#### Trigger responsibility

Triggers decide **when** something should fire.

Examples:

- threshold crossed
- schedule matched
- state changed
- condition became true

#### Runner responsibility

Runners decide **how ongoing execution loops behave over time**.

Examples:

- cycle every N ms
- loop until stopped
- execute in a background flow

#### Command responsibility

Commands decide **what the actual implementation does**.

Examples:

- writing state
- performing IO
- importing/exporting data
- calling Q / QC
- managing layouts

## Queue model

The intended queue model is FIFO.

That means:

- events are dispatched in arrival order
- one event does not magically replace another unless explicit logic does so
- repeated identical firings are still separate firings unless dedupe is explicitly implemented elsewhere

## Event versus state

An event is not a data store.

Its purpose is dispatch, not storage.
If persistent state is needed, the event's command should write to a real state symbol such as `$`, `#`, or `&`.

## Event versus workflow

Do not treat one event as a whole workflow engine.

A large workflow should be built from:

- commands
- runners
- triggers
- explicit state
- optionally multiple events

An event should remain thin.

## Why this model is good

This design keeps AIGMos coherent because:

- parser remains the choke point
- execution is inspectable
- event meaning stays small and clear
- the same event can be reused from multiple sources
- control logic stays composable instead of turning into hidden spaghetti
