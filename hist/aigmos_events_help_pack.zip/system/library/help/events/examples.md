# Event Examples (`@`)

## 1) Manual dispatch target

Define an event that wraps a normal command:

```text
@ping = echo test
```

Conceptually this means:

```text
fire @ping
-> parser executes: echo test
```

## 2) Trigger to event

A trigger should decide **when** to act.
The event should define **what** gets run.

```text
@alarm = echo sensor high
!sensor_high -> @alarm
```

Mental model:

```text
sensor condition true
-> trigger fires
-> @alarm dispatched
-> parser executes: echo sensor high
```

## 3) Runner to event

A runner can repeatedly dispatch an event.

```text
@tick = echo tick
%loop dispatches @tick repeatedly
```

This keeps the runner focused on repetition / timing and the event focused on the named action.

## 4) Event that writes state

```text
@mark_done = $job:status = done
```

When fired, the parser executes the state assignment.

## 5) Event that calls Q

```text
@ask_help = q explain current state
```

The event is still just a dispatch definition.
The actual Q command logic remains in the command layer.

## 6) Event for IO command

```text
@fetch_status = HTTP.GET http://device.local/status $device:status_json
```

The event does not become “an HTTP subsystem.”
It just dispatches the IO command.

## 7) Good style

Good event style:

- short name
- one clear action
- reusable from multiple places
- no hidden workflow assumptions

Example:

```text
@save_snapshot = export.json #SYSTEM /tmp/system.json
```

## 8) Bad style

Bad event style is where too much meaning is crammed into the event itself.

Examples of smell:

- giant command chains
- unclear side effects
- event names that hide unrelated behavior
- using one event as a substitute for real workflow structure

Better approach:

- split complex logic into proper commands, triggers, runners, and state
- keep the event as the named dispatch target
