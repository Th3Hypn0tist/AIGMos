# Event Errors and Misconceptions (`@`)

## Common misconception: `@` is a trigger

Wrong.

`@` does not decide when to fire.
That is trigger logic (`!`) or some other dispatching logic.

## Common misconception: `@` is a scheduler

Wrong.

Scheduling belongs to trigger rules, cron-like behavior, or runners.

## Common misconception: `@` is a mini script language

Wrong.

An event is a thin dispatch definition, not a full workflow or language runtime.

## Common misconception: `@` is a data container

Wrong.

Persistent data belongs in the state spaces such as `$`, `#`, or `&`.

## Error class: invalid command target

If an event resolves to an invalid command line, the parser should fail exactly as it would fail for normal invalid user input.

That is not “an event-only problem.”
It is a normal command execution error.

## Error class: repeated firing

If the same event is fired repeatedly, each firing is a separate dispatch unless some dedupe layer exists elsewhere.

Do not assume automatic dedupe.

## Error class: hidden workflow coupling

A common design mistake is building hidden workflow state into event naming conventions.

Example smell:

- one event silently implies multiple side effects
- event name suggests something tiny but actually performs broad mutation

Fix:

- move the logic into real commands / explicit state
- let the event remain a named dispatch entry point

## Error class: overloading one event

If an event becomes too broad, it stops being predictable.

Symptoms:

- hard to test
- hard to inspect
- hard to reuse safely
- surprising output or state mutation

Fix:

- split the behavior
- name smaller events
- keep command responsibilities explicit

## Operational guidance

When debugging event behavior, inspect these layers separately:

1. Was the dispatch source correct?
   - manual input
   - trigger
   - runner

2. Did the event resolve to the expected command string?

3. Did the parser execute that command correctly?

4. Did the command mutate state / output as expected?

This prevents blaming `@` for failures that actually live in the command itself.
