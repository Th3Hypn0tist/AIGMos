from __future__ import annotations

import threading
from collections import deque
from typing import Any

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_layout_caller_handle, runtime_map
from system.lib.q.errors import QCallError
from system.lib.q.profile import resolve_profile_name
from system.lib.q.session import q_chat
from system.lib.q.state import write_text_symbol
from system.layout.lib.targets import resolve_querytarget

command = 'q'
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful chat/query dispatch

rules:
- target is explicit
- dispatches query asynchronously
- does not return successful assistant output to command buffer
- queued FIFO per profile alias
- one active task per alias at a time

examples:
  q |:q hello
  q |HELP:q explain #HELP:README.md
  q.coder |:q refactor this
"""

_RUNTIME_SNAPSHOT_KEYS = (
    'layout_caller_handle',
    'q_state_root',
    'q_profile',
    'q_chat_symbol',
    'q_response_symbol',
    'q_thinking_symbol',
    'q_role_symbol',
    'q_system_prompt_symbol',
)


def _parse_q_target_prompt(line: str) -> tuple[str, str, str]:
    raw = str(line or '').strip()
    parts = raw.split(maxsplit=2)
    if len(parts) < 3:
        raise ValueError('usage: q[.profile] <target> <prompt...>')
    command_token, target, prompt = parts[0], parts[1], parts[2]
    if not prompt or not prompt.strip():
        raise ValueError('q requires prompt')
    return command_token, target, prompt


def _q_cue(parser) -> dict[str, Any]:
    rt = runtime_map(parser)
    cue = rt.get('q_cue')
    if isinstance(cue, dict):
        return cue
    cue = {
        'lock': threading.RLock(),
        'wake': threading.Event(),
        'queues': {},
        'active': {},  # q_root -> {task_id, alias}
        'started': False,
        'thread': None,
        'seq': 0,
    }
    rt['q_cue'] = cue
    return cue


def _task_id(cue: dict[str, Any]) -> str:
    cue['seq'] = int(cue.get('seq') or 0) + 1
    return str(cue['seq'])


def _active_meta(value: Any) -> dict[str, str]:
    if isinstance(value, dict):
        task_id = str(value.get('task_id') or '').strip()
        alias = str(value.get('alias') or '').strip()
        out: dict[str, str] = {}
        if task_id:
            out['task_id'] = task_id
        if alias:
            out['alias'] = alias
        return out
    task_id = str(value or '').strip()
    return {'task_id': task_id} if task_id else {}


def _set_waiting_state(parser, q_root: str, prompt: str, cue_text: str = '') -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_waiting_set')
    write_text_symbol(parser.state, f'{clean_root}:status', 'waiting', 'status_waiting')
    write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_waiting_reset')
    if cue_text:
        write_text_symbol(parser.state, f'{clean_root}:cue', str(cue_text), 'cue_waiting_set')


def _set_running_state(parser, q_root: str, prompt: str) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_running_set')
    write_text_symbol(parser.state, f'{clean_root}:status', 'running', 'status_running')
    write_text_symbol(parser.state, f'{clean_root}:cue', '', 'cue_running_clear')
    write_text_symbol(parser.state, f'{clean_root}:response', '', 'response_running_reset')
    write_text_symbol(parser.state, f'{clean_root}:thinking_text', '', 'thinking_running_reset')
    write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_running_reset')


def _refresh_alias_cues(parser, alias: str) -> None:
    cue = _q_cue(parser)
    with cue['lock']:
        queue = list((cue.get('queues') or {}).get(alias) or [])
    total = len(queue)
    for idx, item in enumerate(queue, start=1):
        q_root = str(item.get('q_root') or '').strip()
        if not q_root:
            continue
        write_text_symbol(parser.state, f'{q_root}:cue', f'[CUE {idx}/{total}]', 'cue_position_set')
        write_text_symbol(parser.state, f'{q_root}:status', 'waiting', 'status_waiting_refresh')


def _clear_finished_waiting_cue(parser, q_root: str) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    write_text_symbol(parser.state, f'{clean_root}:cue', '', 'cue_clear')


def _runtime_snapshot(parser) -> dict[str, Any]:
    rt = runtime_map(parser)
    return {key: rt.get(key) for key in _RUNTIME_SNAPSHOT_KEYS}


def _runtime_restore(parser, snapshot: dict[str, Any]) -> None:
    rt = runtime_map(parser)
    for key in _RUNTIME_SNAPSHOT_KEYS:
        if key in snapshot:
            rt[key] = snapshot.get(key)
        else:
            rt.pop(key, None)


def _worker_context_lock(parser):
    lock = getattr(parser, '_parse_lock', None)
    return lock if lock is not None else threading.RLock()


def _start_worker(parser, task: dict[str, Any]) -> None:
    cue = _q_cue(parser)

    def _worker() -> None:
        q_root = str(task.get('q_root') or '').strip()
        task_id = str(task.get('task_id') or '').strip()
        alias = str(task.get('alias') or '').strip() or 'default'
        prompt = str(task.get('prompt') or '')
        command_token = str(task.get('command_token') or 'q')
        profile_name = str(task.get('profile_name') or '').strip() or None
        caller_handle = str(task.get('caller_handle') or '').strip() or None
        snapshot = _runtime_snapshot(parser)
        lock = _worker_context_lock(parser)
        try:
            _set_running_state(parser, q_root, prompt)
            with lock:
                q_chat(
                    parser,
                    command_token,
                    prompt,
                    q_root_override=q_root,
                    caller_handle_override=caller_handle,
                    profile_name_override=profile_name,
                    on_chunk=lambda _chunk, _full_text, _chat_symbol, _key: force_render(parser),
                    on_done=lambda _full_text, _chat_symbol, _key: force_render(parser),
                )
        except Exception as exc:
            if q_root:
                try:
                    write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_error')
                    write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_error_status')
                    write_text_symbol(parser.state, f'{q_root}:cue', '', 'q_async_error_cue_clear')
                except Exception:
                    pass
            force_render(parser)
        finally:
            _runtime_restore(parser, snapshot)
            with cue['lock']:
                active = cue.get('active') or {}
                meta = _active_meta(active.get(q_root))
                if meta.get('task_id') == task_id:
                    active.pop(q_root, None)
            _refresh_alias_cues(parser, alias)
            cue['wake'].set()
            force_render(parser)

    thread = threading.Thread(target=_worker, name=f'q-worker-{task.get("task_id")}', daemon=True)
    thread.start()


def _has_active_alias(cue: dict[str, Any], alias: str) -> bool:
    clean_alias = str(alias or '').strip() or 'default'
    active = cue.get('active') or {}
    for value in active.values():
        meta = _active_meta(value)
        if meta.get('alias') == clean_alias and meta.get('task_id'):
            return True
    return False


def _scheduler_loop(parser) -> None:
    cue = _q_cue(parser)
    try:
        while True:
            cue['wake'].wait()
            while True:
                task = None
                with cue['lock']:
                    cue['wake'].clear()
                    queues = cue.get('queues') or {}
                    active = cue.get('active') or {}
                    for alias in sorted(list(queues.keys())):
                        queue = queues.get(alias)
                        if not queue:
                            continue
                        if _has_active_alias(cue, alias):
                            continue
                        picked_index = None
                        for idx, candidate in enumerate(list(queue)):
                            q_root = str(candidate.get('q_root') or '')
                            meta = _active_meta(active.get(q_root))
                            if not q_root or not meta.get('task_id'):
                                picked_index = idx
                                break
                        if picked_index is None:
                            continue
                        task = queue[picked_index]
                        del queue[picked_index]
                        q_root = str(task.get('q_root') or '')
                        if q_root:
                            active[q_root] = {'task_id': str(task.get('task_id') or ''), 'alias': str(task.get('alias') or alias or 'default')}
                        break
                if task is None:
                    break
                _refresh_alias_cues(parser, str(task.get('alias') or 'default'))
                _start_worker(parser, task)
    finally:
        with cue['lock']:
            cue['started'] = False
            cue['thread'] = None


def _ensure_scheduler(parser) -> None:
    cue = _q_cue(parser)
    with cue['lock']:
        thread = cue.get('thread')
        if bool(cue.get('started')) and isinstance(thread, threading.Thread) and thread.is_alive():
            return
        cue['started'] = False
        cue['thread'] = None
    thread = threading.Thread(target=_scheduler_loop, args=(parser,), name='q-cue-scheduler', daemon=True)
    with cue['lock']:
        cue['thread'] = thread
        cue['started'] = True
    thread.start()


def _enqueue_query(parser, command_token: str, q_root: str, prompt: str) -> None:
    alias = str(command_token.split('.', 1)[1] if '.' in command_token else 'default').strip() or 'default'
    profile_name = resolve_profile_name(parser, command_token, 'q')
    cue = _q_cue(parser)
    task = {
        'task_id': '',
        'alias': alias,
        'profile_name': profile_name,
        'q_root': str(q_root or '').strip(),
        'caller_handle': get_layout_caller_handle(parser),
        'command_token': command_token,
        'prompt': str(prompt or ''),
    }
    with cue['lock']:
        task['task_id'] = _task_id(cue)
        queue = cue['queues'].setdefault(alias, deque())
        queue.append(task)
    _refresh_alias_cues(parser, alias)
    if q_root:
        _set_waiting_state(parser, q_root, prompt)
    _ensure_scheduler(parser)
    cue['wake'].set()
    force_render(parser)


def handler(line: str, parser):
    try:
        command_token, raw_target, prompt = _parse_q_target_prompt(line)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    try:
        q_root = resolve_querytarget(raw_target, get_layout_caller_handle(parser))
        _enqueue_query(parser, command_token, q_root, prompt)
    except QCallError as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)

    return HandlerResponse(buffer_output='', force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
