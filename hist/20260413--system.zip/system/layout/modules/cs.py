from __future__ import annotations

import curses
from typing import Any

MODULE = "cs"
STORAGE_PREFIX = "CS"
DEFAULT_PROMPT = "cs> "
FOCUSABLE = True


def get_targets(handle: str, config: dict[str, Any] | None = None) -> tuple[str, str]:
    cfg = dict(config or {})
    target_handle = str(cfg.get("alias_target") or handle or "").strip() or str(handle or "").strip()
    return f"{target_handle}:buffer", f"{target_handle}:buffer"


def _requested_lines(spec: dict[str, Any]) -> int:
    attrs = dict(spec.get("attrs") or {})
    try:
        return max(1, int(attrs.get("lines", 1) or 1))
    except Exception:
        return 1


def measure(ctx, binding_handle: str, spec: dict[str, Any], width: int, instance) -> dict[str, Any]:
    return {"min_h": _requested_lines(spec), "scalable_y": False}


def build_payload(ctx, binding_handle: str, spec: dict[str, Any], rect: dict[str, int], instance):
    from system.layout import input as layout_input
    from system.layout.module_api import content_rect, finalize_payload, insert_cursor_marker, wrapped_window_with_cursor

    attrs = dict(spec.get("attrs") or {})
    inner_rect = content_rect(attrs, rect)
    width = max(1, int(inner_rect.get("w", 1) or 1))
    height = max(1, int(inner_rect.get("h", _requested_lines(spec)) or _requested_lines(spec)))
    editor = layout_input.get_editor(ctx, instance.handle)
    text = str(editor.get("buffer", "") or "")
    cursor = max(0, min(int(editor.get("cursor", 0) or 0), len(text)))
    visible_lines, local_cursor = wrapped_window_with_cursor(text, cursor, width, height)
    line_index = max(0, min(len(visible_lines) - 1, int(local_cursor.get("y", 0) or 0))) if visible_lines else 0
    lines = list(visible_lines or [""])
    lines[line_index] = insert_cursor_marker(lines[line_index], int(local_cursor.get("x", 0) or 0))
    out = finalize_payload(ctx, instance.handle, lines, attrs, MODULE, rect)
    border = str(attrs.get("border") or "").strip().lower() in {"1", "true", "yes", "on"}
    out["cursor_local"] = {
        "x": int(local_cursor.get("x", 0) or 0) + (1 if border else 0),
        "y": int(local_cursor.get("y", 0) or 0) + (1 if border else 0),
    }
    out["force_full_rect"] = True
    out.pop("row_updates", None)
    return out


def handle_key(ctx, module_handle: str, key: int | str) -> bool:
    from system.layout import input as layout_input

    editor = layout_input.get_editor(ctx, module_handle)
    buf = str(editor.get("buffer", "") or "")
    cursor = int(editor.get("cursor", 0) or 0)
    if key in layout_input._ENTER_KEYS:
        line = str(editor.get("buffer", "") or "")
        editor["buffer"] = ""
        editor["cursor"] = 0
        if layout_input.registry.is_ui_instance_switch_line(line):
            editor["history_index"] = None
        else:
            layout_input._history_commit(editor, line)
        if not line.strip():
            layout_input._mark_dirty(ctx, full=True)
            return True
        inst = layout_input.registry.get_instance(ctx, module_handle)
        source_handle = layout_input.registry.get_parent_layout_for_instance(ctx, module_handle) or module_handle
        target_handle = str(getattr(inst, "config", {}).get("alias_target") or "").strip() or source_handle
        layout_input.registry.dispatch_line(ctx, line, source_handle=source_handle, target_handle=target_handle)
        layout_input._mark_dirty(ctx, full=True)
        return True
    if key in layout_input._BACKSPACE_KEYS:
        if cursor > 0:
            editor["buffer"] = buf[: cursor - 1] + buf[cursor:]
            editor["cursor"] = cursor - 1
            editor["history_index"] = None
            layout_input._mark_dirty(ctx, module_handle)
        return True
    if key in layout_input._DELETE_KEYS:
        if cursor < len(buf):
            editor["buffer"] = buf[:cursor] + buf[cursor + 1 :]
            editor["history_index"] = None
            layout_input._mark_dirty(ctx, module_handle)
        return True
    if key == curses.KEY_LEFT:
        editor["cursor"] = max(0, cursor - 1)
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if key == curses.KEY_RIGHT:
        editor["cursor"] = min(len(buf), cursor + 1)
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if key == curses.KEY_HOME:
        editor["cursor"] = 0
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if key == curses.KEY_END:
        editor["cursor"] = len(buf)
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if key == curses.KEY_UP:
        layout_input._history_up(editor)
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if key == curses.KEY_DOWN:
        layout_input._history_down(editor)
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if isinstance(key, str) and key and key not in {"\t", "\n", "\r", "\x1b"}:
        layout_input._insert_text(editor, key)
        editor["history_index"] = None
        layout_input._mark_dirty(ctx, module_handle)
        return True
    if isinstance(key, int) and 32 <= key <= 126:
        layout_input._insert_text(editor, chr(key))
        editor["history_index"] = None
        layout_input._mark_dirty(ctx, module_handle)
        return True
    return False


def clear(ctx, module_handle: str, instance):
    from system.layout import input as layout_input

    editor = layout_input.get_editor(ctx, module_handle)
    editor["buffer"] = ""
    editor["cursor"] = 0
    editor["history_index"] = None
    return True
