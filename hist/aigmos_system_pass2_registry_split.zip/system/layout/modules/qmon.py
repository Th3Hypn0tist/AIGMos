from __future__ import annotations

from typing import Any

from system.layout.lib.handles import state_root_for_target
from system.layout.lib.scroll import handle_scroll_key

MODULE = "qmon"
STORAGE_PREFIX = "QMON"
DEFAULT_PROMPT = "cs> "
FOCUSABLE = True

def get_targets(handle: str, config: dict[str, Any] | None = None) -> tuple[str, str]:
    cfg = dict(config or {})
    source_handle = str(cfg.get("source_handle") or cfg.get("alias_target") or "").strip()
    base = state_root_for_target(source_handle)
    if not base:
        base = "$Q"
    return base, f"{base}:ch"


def measure(ctx, binding_handle: str, spec: dict[str, Any], width: int, instance) -> dict[str, Any]:
    return {"min_h": 1, "scalable_y": True}


def _render_qmon_lines(ctx, instance, width: int, height: int, flow: str = "top") -> list[str]:
    from system.layout import state as layout_state
    from system.layout.module_api import get_module_ui, wrap_text

    def _extend_wrapped(dst: list[str], raw: str) -> None:
        dst.extend(wrap_text(raw, width) or [""])

    def _append_chat_entry(dst: list[str], prompt: str, response: str, error: str = "") -> None:
        if prompt:
            _extend_wrapped(dst, f"Q> {prompt}")
        if response:
            _extend_wrapped(dst, f"A> {response}")
            dst.append("")
        if error:
            _extend_wrapped(dst, f"[ERROR] {error}")
            dst.append("")

    def _viewport_tail(lines: list[str], box_h: int, scroll: int) -> list[str]:
        box_h = max(1, int(box_h or 1))
        scroll = max(0, int(scroll or 0))
        end = max(0, len(lines) - scroll)
        start = max(0, end - box_h)
        return lines[start:end] or [""]

    def _viewport_head(lines: list[str], box_h: int, scroll: int) -> list[str]:
        box_h = max(1, int(box_h or 1))
        scroll = max(0, int(scroll or 0))
        start = min(scroll, max(0, len(lines) - 1)) if lines else 0
        end = min(len(lines), start + box_h)
        return lines[start:end] or [""]

    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    flow = str(flow or "top").strip().lower()
    ui = get_module_ui(ctx, getattr(instance, "handle", ""))
    follow = bool(ui.get("follow", True))
    scroll = max(0, int(ui.get("scroll", 0) or 0))

    target_root = str(getattr(instance, "primary_target", "") or "").strip()
    chat_symbol = str(getattr(instance, "view_target", "") or "").strip()
    chat = layout_state.get_value(ctx, chat_symbol, {})
    prompt = str(layout_state.get_value(ctx, f"{target_root}:prompt", "") or "")
    response = str(layout_state.get_value(ctx, f"{target_root}:response", "") or "")
    thinking = str(layout_state.get_value(ctx, f"{target_root}:thinking_text", "") or "")
    error = str(layout_state.get_value(ctx, f"{target_root}:error", "") or "")

    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    live_packet: dict[str, Any] = {}
    if parser is not None:
        try:
            from system.lib.q.live import get_live_chat, get_live_packet
            chat = get_live_chat(parser, chat_symbol)
            live_packet = get_live_packet(parser)
        except Exception:
            pass

    live_chat_symbol = str(live_packet.get("chat_symbol") or "")
    live_key = str(live_packet.get("key") or "")
    live_prompt = str(live_packet.get("prompt") or "")
    live_response = str(live_packet.get("response") or "")
    live_thinking = str(live_packet.get("thinking") or "")
    live_done = 1 if int(live_packet.get("done") or 0) == 1 else 0

    is_live_for_target = (
        live_done == 0
        and live_chat_symbol == chat_symbol
        and bool(live_key)
    )

    all_lines: list[str] = []
    if is_live_for_target:
        if live_thinking and not live_response:
            _extend_wrapped(all_lines, f"[THINKING] {live_thinking}")
        elif live_response:
            if live_prompt:
                _extend_wrapped(all_lines, f"Q> {live_prompt}")
            _extend_wrapped(all_lines, f"[RESPONSE] {live_response}")
    elif isinstance(chat, dict) and chat:
        try:
            from system.layout.module_api import sorted_chat_keys
            keys = sorted_chat_keys(chat)
        except Exception:
            keys = sorted(chat.keys(), key=lambda x: str(x))
        iterable = keys if flow == "top" else list(reversed(keys))
        for key in iterable:
            item = chat.get(key) or {}
            if not isinstance(item, dict):
                continue
            _append_chat_entry(
                all_lines,
                str(item.get("prompt") or ""),
                str(item.get("response") or ""),
                str(item.get("error") or ""),
            )
    elif thinking and not response:
        if prompt:
            _extend_wrapped(all_lines, f"Q> {prompt}")
        _extend_wrapped(all_lines, f"[THINKING] {thinking}")
    elif response:
        if prompt:
            _extend_wrapped(all_lines, f"Q> {prompt}")
        _extend_wrapped(all_lines, f"[RESPONSE] {response}")
    elif error:
        _extend_wrapped(all_lines, f"[ERROR] {error}")

    if not all_lines:
        all_lines = [""]
    if flow != "top":
        all_lines = list(reversed(all_lines))
    if follow:
        ui["scroll"] = 0
        return _viewport_tail(all_lines, height, 0)
    if flow == "top":
        return _viewport_tail(all_lines, height, scroll)
    return _viewport_head(all_lines, height, scroll)


def build_payload(ctx, binding_handle: str, spec: dict[str, Any], rect: dict[str, int], instance):
    from system.layout.module_api import content_rect, finalize_payload
    attrs = dict(spec.get("attrs") or {})
    flow = str(attrs.get("flow") or "top").strip().lower() or "top"
    inner_rect = content_rect(attrs, rect)
    lines = _render_qmon_lines(ctx, instance, int(inner_rect.get("w", 1) or 1), int(inner_rect.get("h", 1) or 1), flow)
    return finalize_payload(ctx, instance.handle, lines or [""], attrs, "q", rect)


def handle_key(ctx, module_handle: str, key: int) -> bool:
    import curses
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    if handle_scroll_key(ui, key, kind='q'):
        layout_input._mark_dirty(ctx)
        return True
    return False


def clear(ctx, module_handle: str, instance):
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    ui["follow"] = True
    ui["scroll"] = 0
    return True
