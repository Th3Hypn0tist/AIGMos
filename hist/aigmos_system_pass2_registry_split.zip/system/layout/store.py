from __future__ import annotations

from typing import Any

from system.state.api import delete_value, list_symbols, read_value, write_value

STORE_SYMBOL = "#SYSTEM:runtime:layouts"
STORE_VERSION = 1


def _state_get(state, symbol: str, default: Any = None) -> Any:
    return read_value(state, symbol, default)


def _state_set(state, symbol: str, value: Any, *, writer: str = "layout:store") -> None:
    out = write_value(state, symbol, value, writer=writer, op="layout_persist")
    if out.get("error"):
        raise ValueError(str(out["error"]))


def _state_delete(state, symbol: str, *, writer: str = "layout:store") -> None:
    out = delete_value(state, symbol, writer=writer, op="layout_delete")
    if out.get("error"):
        raise ValueError(str(out["error"]))


def _as_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return {str(k): v for k, v in value.items()}
    return {}


def _normalize_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    clean = dict(payload)
    return {
        "version": int(clean.get("version") or STORE_VERSION),
        "active_handle": str(clean.get("active_handle") or ""),
        "bindings": _as_dict(clean.get("bindings")),
        "instances": _as_dict(clean.get("instances")),
    }


def load_layout_store(state) -> dict[str, Any]:
    payload = _normalize_payload(_state_get(state, STORE_SYMBOL, None))
    if payload:
        return payload

    bindings = _as_dict(_state_get(state, f"{STORE_SYMBOL}:bindings", {}))
    instances = _as_dict(_state_get(state, f"{STORE_SYMBOL}:instances", {}))
    active_handle = str(_state_get(state, f"{STORE_SYMBOL}:active_handle", "") or "")
    if not bindings and not instances and not active_handle:
        return {}
    return {
        "version": STORE_VERSION,
        "active_handle": active_handle,
        "bindings": bindings,
        "instances": instances,
    }


def save_layout_store(state, payload: dict[str, Any], *, writer: str = "layout:store") -> None:
    clean = _normalize_payload(payload)
    clean["version"] = STORE_VERSION
    _state_set(state, STORE_SYMBOL, clean, writer=writer)


def delete_layout_symbols(state, prefixes: list[str], *, writer: str = "layout:store") -> None:
    if not prefixes:
        return
    targets = [str(prefix or "").strip() for prefix in prefixes if str(prefix or "").strip()]
    if not targets:
        return
    symbols = list_symbols(state)
    doomed: set[str] = set()
    for symbol in symbols:
        for prefix in targets:
            if symbol == prefix or symbol.startswith(prefix + ":"):
                doomed.add(symbol)
                break
    for symbol in sorted(doomed, reverse=True):
        _state_delete(state, symbol, writer=writer)
