from __future__ import annotations

import threading

from system.cs.runtime_ctx import force_render, get_runtime, set_runtime
from system.cs.symbols import is_symbol_line
from system.state.api import append_numeric_value

from .focus import bootstrap, get_active_handle, switch_active
from .instances import ensure_instance, get_instance
from .lib.handles import normalize_handle
from .lib.targets import get_layout_buffer_target


def is_ui_instance_switch_line(line: str) -> bool:
    clean = str(line or "").strip()
    if not clean or not clean.startswith("|"):
        return False
    if any(ch.isspace() for ch in clean):
        return False
    if "=" in clean:
        return False
    try:
        normalize_handle(clean)
    except Exception:
        return False
    return True


def _append_command_to_buffer(ctx, line: str, *, source_handle: str | None = None) -> None:
    clean = str(line or '').rstrip("\r\n")
    if not clean.strip():
        return
    state = ctx.get('state') if isinstance(ctx, dict) else None
    if state is None:
        return
    handle = normalize_handle(source_handle or get_active_handle(ctx))
    target = get_layout_buffer_target(ctx, handle)
    append_numeric_value(
        state,
        target,
        f"> {clean}",
        writer="layout:input",
        op="layout_command_echo",
    )


def _parser_parse_with_layout(ctx, line: str, *, caller_handle: str | None = None, buffer_suppress: bool = False, layout_self_route: bool = False):
    parser = ctx.get("parser")
    if parser is None:
        raise ValueError("parser missing")

    lock = getattr(parser, "_parse_lock", None)
    if lock is None:
        previous = get_runtime(parser, "layout_caller_handle", "")
        previous_suppress = get_runtime(parser, "buffer_suppress", False)
        previous_self_route = get_runtime(parser, "layout_self_route", False)
        set_runtime(parser, "layout_caller_handle", normalize_handle(caller_handle or get_active_handle(ctx)))
        set_runtime(parser, "buffer_suppress", bool(buffer_suppress))
        set_runtime(parser, "layout_self_route", bool(layout_self_route))
        try:
            return parser.parse(line)
        finally:
            set_runtime(parser, "layout_caller_handle", previous)
            set_runtime(parser, "buffer_suppress", previous_suppress)
            set_runtime(parser, "layout_self_route", previous_self_route)

    with lock:
        previous = get_runtime(parser, "layout_caller_handle", "")
        previous_suppress = get_runtime(parser, "buffer_suppress", False)
        previous_self_route = get_runtime(parser, "layout_self_route", False)
        set_runtime(parser, "layout_caller_handle", normalize_handle(caller_handle or get_active_handle(ctx)))
        set_runtime(parser, "buffer_suppress", bool(buffer_suppress))
        set_runtime(parser, "layout_self_route", bool(layout_self_route))
        try:
            return parser.parse(line)
        finally:
            set_runtime(parser, "layout_caller_handle", previous)
            set_runtime(parser, "buffer_suppress", previous_suppress)
            set_runtime(parser, "layout_self_route", previous_self_route)


def _line_routes_to_parser(ctx, line: str) -> bool:
    from .persistence import _active_handle_for_store
    from .instances import _default_startup_layout_handle

    clean = str(line or "").strip()
    if not clean:
        return False
    if clean.startswith("/") or clean.startswith("|"):
        return True
    if is_symbol_line(clean):
        active = str(_active_handle_for_store(ctx) or _default_startup_layout_handle())
        try:
            inst = get_instance(ctx, active)
        except Exception:
            inst = None
        if inst is not None and getattr(inst, "MODULE", "") == "q" and "=" not in clean:
            return False
        return True
    parser = ctx.get("parser")
    if parser is None:
        return False
    token = clean.split()[0]
    if token == "/":
        return True
    return token in getattr(parser, "registry", {})


def _dispatch_q_self_route_async(ctx, line: str, *, caller_handle: str | None = None) -> None:
    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    if parser is None:
        return

    def _run() -> None:
        try:
            _parser_parse_with_layout(ctx, line, caller_handle=caller_handle, buffer_suppress=True, layout_self_route=True)
        finally:
            force_render(parser)

    thread = threading.Thread(target=_run, name="layout-q-self-route", daemon=True)
    thread.start()


def dispatch_line(ctx, line: str, *, source_handle: str | None = None, target_handle: str | None = None) -> dict[str, str]:
    bootstrap(ctx)
    clean = str(line or "").rstrip("\r\n")
    if not clean.strip():
        return {"mode": "none"}

    if is_ui_instance_switch_line(clean):
        target = ensure_instance(ctx, clean)
        handle = str(getattr(target, "handle", target) or clean).strip() or clean
        switch_active(ctx, handle)
        return {"mode": "switch"}

    caller_handle = normalize_handle(source_handle or get_active_handle(ctx))
    effective_handle = normalize_handle(target_handle or caller_handle)

    if _line_routes_to_parser(ctx, clean):
        _append_command_to_buffer(ctx, clean, source_handle=caller_handle)
        _parser_parse_with_layout(ctx, clean, caller_handle=effective_handle)
        return {"mode": "parser"}

    inst = get_instance(ctx, effective_handle)
    if inst.MODULE == "q":
        profile = str(inst.config.get("profile") or "default").strip() or "default"
        cmd = "q" if profile == "default" else f"q.{profile}"
        _dispatch_q_self_route_async(ctx, f"{cmd} {clean}", caller_handle=effective_handle)
        return {"mode": "self"}

    return {"mode": "none"}
