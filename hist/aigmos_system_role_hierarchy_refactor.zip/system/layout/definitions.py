from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from . import loader as module_loader
from .parser import parse_template

_LAYOUT_DIRS = (
    Path(__file__).resolve().parents[1] / "library" / "layout",
    Path(__file__).resolve().parents[2] / "extensions" / "layout",
)

_CONTAINER_TAGS = {"layout", "row", "cell"}
_ATTR_RE = re.compile(
    r"""([A-Za-z_][A-Za-z0-9_:\-.]*)\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))"""
)
_LEAF_RE = re.compile(
    r"^\s*<\s*([A-Za-z_][A-Za-z0-9_-]*)(?P<attrs>.*?)\s*>\s*$",
    re.DOTALL,
)
_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")


def _leaf_tag(raw: str) -> str:
    m = re.match(r"\s*<\s*([A-Za-z_][A-Za-z0-9_-]*)", str(raw or ""))
    if not m:
        return ""
    return m.group(1).strip().lower()



def _leaf_elem(raw: str) -> ET.Element:
    text = str(raw or "").strip()
    if text.endswith("/>"):
        raise ET.ParseError("self-closing leaf tags are not allowed")
    match = _LEAF_RE.match(text)
    if not match:
        raise ET.ParseError("not well-formed leaf tag")

    tag = str(match.group(1) or "").strip()
    attrs_text = str(match.group("attrs") or "")
    attrs: dict[str, str] = {}
    consumed: list[tuple[int, int]] = []

    for item in _ATTR_RE.finditer(attrs_text):
        key = str(item.group(1) or "").strip()
        value = item.group(2)
        if value is None:
            value = item.group(3)
        if value is None:
            value = item.group(4)
        attrs[key] = "" if value is None else str(value)
        consumed.append(item.span())

    leftovers: list[str] = []
    cursor = 0
    for start, end in consumed:
        leftovers.append(attrs_text[cursor:start])
        cursor = end
    leftovers.append(attrs_text[cursor:])
    remainder = "".join(leftovers).strip()
    if remainder:
        raise ET.ParseError("not well-formed leaf attributes")

    return ET.Element(tag, attrs)



def _storage_prefix(tag: str) -> str:
    try:
        return str(module_loader.module_meta(tag)["storage_prefix"])
    except Exception:
        return str(tag or "").strip().upper()



def _module_requires_id(tag: str) -> bool:
    clean = str(tag or "").strip().lower()
    if clean == "cs":
        return False
    if clean == "q":
        return True
    try:
        module = module_loader.load_module(clean)
        return bool(getattr(module, "REQUIRES_ID", False))
    except Exception:
        return False



def _validate_module_ids(path: str, specs: list[dict[str, Any]]) -> None:
    seen: dict[str, str] = {}
    for spec in specs:
        tag = str(spec.get("tag") or "").strip().lower()
        attrs = dict(spec.get("attrs") or {})
        module_id = str(attrs.get("id") or "").strip()
        if _module_requires_id(tag) and not module_id:
            raise ValueError(f"template {path}: <{tag}> requires id")
        if module_id:
            if not _ID_RE.match(module_id):
                raise ValueError(f"template {path}: invalid id for <{tag}>: {module_id}")
            previous = seen.get(module_id)
            if previous is not None:
                raise ValueError(f"template {path}: duplicate module id: {module_id}")
            seen[module_id] = tag



def _resolve_layout_path(name: str) -> Path:
    token = str(name or "").strip()
    if token.startswith("/"):
        token = token[1:]
    if not token:
        raise FileNotFoundError("layout not found")

    direct = Path(token)
    if direct.exists() and direct.is_file():
        return direct

    candidates = [token]
    if not token.endswith(".tmpl"):
        candidates.append(f"{token}.tmpl")

    for base in _LAYOUT_DIRS:
        for candidate in candidates:
            path = base / candidate
            if path.exists() and path.is_file():
                return path

    raise FileNotFoundError(f"layout not found: {name}")



def parse_layout_definition(name: str) -> dict[str, Any]:
    path = _resolve_layout_path(name)
    text = path.read_text(encoding="utf-8")
    parsed = parse_template(text)
    out = {
        "name": path.stem,
        "path": str(path),
        "tree": parsed["tree"],
        "modules": parsed["modules"],
    }
    specs = flatten_module_specs(out)
    _validate_module_ids(path.name, specs)
    return out



def flatten_module_specs(tree: dict[str, Any]) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []
    counts: dict[str, int] = {}

    for item in tree.get("modules") or []:
        raw = str(item.get("raw") or "")
        tag = _leaf_tag(raw)
        if not tag or tag in _CONTAINER_TAGS:
            continue
        elem = _leaf_elem(raw)
        counts[tag] = counts.get(tag, 0) + 1
        attrs = dict(elem.attrib)
        specs.append(
            {
                "tag": tag,
                "raw": raw,
                "attrs": attrs,
                "render_index": int(item.get("render_index", len(specs))),
                "ordinal": counts[tag],
                "storage_prefix": _storage_prefix(tag),
                "id": str(attrs.get("id") or "").strip(),
            }
        )

    _validate_module_ids(tree.get("path") or tree.get("name") or "<layout>", specs)
    return specs
