from __future__ import annotations

import curses
from typing import Any

from . import keymap as layout_keymap
from . import registry
from .loader import load_module
from system.state.api import read_value

_BACKSPACE_KEYS = {curses.KEY_BACKSPACE, 127, 8}
_DELETE_KEYS = {curses.KEY_DC}
_ENTER_KEYS = {10, 13, "\n", "\r", curses.KEY_ENTER}


def _ui(ctx) -> dict[str, Any]:
    ui = ctx.setdefault("layout_ui", {}) if isinstance(ctx, dict) else {}
    ui.setdefault("editors", {})
    ui.setdefault("modules", {})
    return ui


def _editor_defaults() -> dict[str, Any]:
    return {
        "buffer": "",
        "cursor": 0,
        "history": [],
        "history_index": None,
    }



def get_editor(ctx, handle: str | None = None) -> dict[str, Any]:
    registry.bootstrap(ctx)
    active = handle or registry.get_focused_module_handle(ctx) or registry.get_active_handle(ctx)
    editors = _ui(ctx).setdefault("editors", {})
    return editors.setdefault(active, _editor_defaults())



def get_module_ui(ctx, handle: str) -> dict[str, Any]:
    registry.bootstrap(ctx)
    modules = _ui(ctx).setdefault("modules", {})
    return modules.setdefault(str(handle or ""), {})



def _mark_dirty(ctx, module_handle: str | None = None, *, full: bool = False) -> None:
    flags = ctx.setdefault("flags", {}) if isinstance(ctx, dict) else {}
    flags["force_render"] = True
    if full:
        flags["layout_hard_redraw"] = True
        return
    target = str(module_handle or "").strip()
    if not target:
        try:
            target = registry.get_focused_module_handle(ctx) or registry.get_active_handle(ctx)
        except Exception:
            target = ""
    if target:
        dirty = flags.setdefault("layout_dirty_modules", set())
        dirty.add(target)



def _insert_text(editor: dict[str, Any], text: str) -> None:
    cursor = int(editor.get("cursor", 0) or 0)
    buf = str(editor.get("buffer", "") or "")
    editor["buffer"] = buf[:cursor] + text + buf[cursor:]
    editor["cursor"] = cursor + len(text)



def _history_commit(editor: dict[str, Any], line: str) -> None:
    text = str(line or "")
    if not text.strip():
        editor["history_index"] = None
        return
    history = editor.setdefault("history", [])
    if not history or history[-1] != text:
        history.append(text)
    editor["history_index"] = None



def _history_up(editor: dict[str, Any]) -> None:
    history = editor.setdefault("history", [])
    if not history:
        return
    index = editor.get("history_index")
    if index is None:
        index = len(history) - 1
    else:
        index = max(0, int(index) - 1)
    editor["history_index"] = index
    editor["buffer"] = str(history[index])
    editor["cursor"] = len(editor["buffer"])



def _history_down(editor: dict[str, Any]) -> None:
    history = editor.setdefault("history", [])
    index = editor.get("history_index")
    if not history or index is None:
        return
    index = int(index)
    if index >= len(history) - 1:
        editor["history_index"] = None
        editor["buffer"] = ""
    else:
        index += 1
        editor["history_index"] = index
        editor["buffer"] = str(history[index])
    editor["cursor"] = len(str(editor.get("buffer", "") or ""))



def _submit_line(ctx, editor: dict[str, Any]) -> None:
    line = str(editor.get("buffer", "") or "")
    editor["buffer"] = ""
    editor["cursor"] = 0
    if registry.is_ui_instance_switch_line(line):
        editor["history_index"] = None
    else:
        _history_commit(editor, line)
    if not line.strip():
        _mark_dirty(ctx, full=True)
        return
    registry.dispatch_line(ctx, line)
    _mark_dirty(ctx, full=True)



def _handle_cs_key(ctx, module_handle: str, key: int | str) -> None:
    editor = get_editor(ctx, module_handle)
    buf = str(editor.get("buffer", "") or "")
    cursor = int(editor.get("cursor", 0) or 0)

    if key in _ENTER_KEYS:
        _submit_line(ctx, editor)
        return
    if key in _BACKSPACE_KEYS:
        if cursor > 0:
            editor["buffer"] = buf[: cursor - 1] + buf[cursor:]
            editor["cursor"] = cursor - 1
            editor["history_index"] = None
            _mark_dirty(ctx, module_handle)
        return
    if key in _DELETE_KEYS:
        if cursor < len(buf):
            editor["buffer"] = buf[:cursor] + buf[cursor + 1 :]
            editor["history_index"] = None
            _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_LEFT:
        editor["cursor"] = max(0, cursor - 1)
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_RIGHT:
        editor["cursor"] = min(len(buf), cursor + 1)
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_HOME:
        editor["cursor"] = 0
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_END:
        editor["cursor"] = len(buf)
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_UP:
        _history_up(editor)
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_DOWN:
        _history_down(editor)
        _mark_dirty(ctx, module_handle)
        return
    if isinstance(key, str) and key and key not in {"\t", "\n", "\r", "\x1b"}:
        _insert_text(editor, key)
        editor["history_index"] = None
        _mark_dirty(ctx, module_handle)
        return
    if isinstance(key, int) and 32 <= key <= 126:
        _insert_text(editor, chr(key))
        editor["history_index"] = None
        _mark_dirty(ctx, module_handle)



def _handle_monitor_key(ctx, module_handle: str, key: int) -> None:
    ui = get_module_ui(ctx, module_handle)
    if key == curses.KEY_UP:
        ui["follow"] = False
        ui["scroll"] = max(0, int(ui.get("scroll", 0) or 0) - 1)
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_DOWN:
        ui["scroll"] = int(ui.get("scroll", 0) or 0) + 1
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_HOME:
        ui["follow"] = False
        ui["scroll"] = 0
        _mark_dirty(ctx, module_handle)
        return
    if key == curses.KEY_END:
        ui["follow"] = True
        _mark_dirty(ctx, module_handle)
        return



def _handle_list_key(ctx, module_handle: str, key: int) -> None:
    ui = get_module_ui(ctx, module_handle)
    inst = registry.get_instance(ctx, module_handle)
    value = read_value(ctx.get("state"), inst.primary_target, None) if ctx.get("state") is not None else None
    if isinstance(value, dict):
        size = len(value)
    elif isinstance(value, list):
        size = len(value)
    else:
        size = 0
    if size <= 0:
        return
    selected = int(ui.get("selected", 0) or 0)
    if key == curses.KEY_UP:
        ui["selected"] = max(0, selected - 1)
        _mark_dirty(ctx, module_handle)
    elif key == curses.KEY_DOWN:
        ui["selected"] = min(size - 1, selected + 1)
        _mark_dirty(ctx)



def handle_key(ctx, key: int | str) -> None:
    if key == curses.KEY_RESIZE:
        _mark_dirty(ctx, full=True)
        return
    if key in {9, "\t"}:
        registry.cycle_focus(ctx, 1)
        _mark_dirty(ctx, full=True)
        return

    focused = registry.get_focused_module_handle(ctx)
    if not focused:
        return

    inst = registry.get_instance(ctx, focused)
    module = load_module(str(getattr(inst, "MODULE", "") or ""))
    handler = getattr(module, "handle_key", None)
    if callable(handler) and bool(handler(ctx, focused, key)):
        return


def handle_alt_key(ctx, key: int | str) -> None:
    if isinstance(key, str) and len(key) == 1 and key.isdigit():
        slot = 10 if key == "0" else int(key)
    elif isinstance(key, int) and 48 <= key <= 57:
        slot = 10 if key == ord("0") else int(chr(key))
    else:
        return
    bindings = layout_keymap.list_bindings(ctx.get("state"))
    command = str(bindings.get(slot) or "").strip()
    if command:
        registry.dispatch_line(ctx, command)
        _mark_dirty(ctx, full=True)
    return

