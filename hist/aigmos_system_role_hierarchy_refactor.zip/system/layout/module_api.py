from __future__ import annotations

import textwrap
from typing import Any

from wcwidth import wcwidth




def char_cells(ch: str) -> int:
    try:
        width = int(wcwidth(str(ch or "")[:1]))
    except Exception:
        width = 1
    return width if width > 0 else 1


def text_cells(text: Any) -> int:
    return sum(char_cells(ch) for ch in str(text or ""))


def clip_cells(text: Any, width: int) -> str:
    limit = max(0, int(width or 0))
    if limit <= 0:
        return ""
    out: list[str] = []
    used = 0
    for ch in str(text or ""):
        cw = char_cells(ch)
        if used + cw > limit:
            break
        out.append(ch)
        used += cw
    return "".join(out)


def ljust_cells(text: Any, width: int) -> str:
    clipped = clip_cells(text, width)
    pad = max(0, int(width or 0) - text_cells(clipped))
    return clipped + (" " * pad)


def visible_window_with_cursor(text: Any, cursor: int, width: int) -> tuple[str, int]:
    chars = list(str(text or ""))
    cursor = max(0, min(int(cursor or 0), len(chars)))
    width = max(1, int(width or 1))
    if not chars:
        return "", 0
    start = 0
    while start < cursor:
        window = "".join(chars[start:cursor])
        if text_cells(window) < width:
            break
        start += 1
    visible = clip_cells("".join(chars[start:]), width)
    local = text_cells("".join(chars[start:cursor]))
    return visible, max(0, min(width - 1, local))


def _cursor_insert_index_for_cells(text: str, cell_pos: int) -> int:
    target = max(0, int(cell_pos or 0))
    used = 0
    idx = 0
    raw = str(text or "")
    while idx < len(raw) and used < target:
        used += char_cells(raw[idx])
        idx += 1
    return idx



def insert_cursor_marker(text: Any, cell_pos: int) -> str:
    raw = str(text or "")
    idx = _cursor_insert_index_for_cells(raw, cell_pos)
    return raw[:idx] + "|" + raw[idx:]



def wrapped_window_with_cursor(text: Any, cursor: int, width: int, height: int) -> tuple[list[str], dict[str, int]]:
    raw = str(text or "")
    chars = list(raw)
    cursor = max(0, min(int(cursor or 0), len(chars)))
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))

    lines: list[str] = []
    current: list[str] = []
    current_cells = 0
    cursor_line = 0
    cursor_col = 0

    for pos in range(len(chars) + 1):
        if pos == cursor:
            cursor_line = len(lines)
            cursor_col = max(0, min(width - 1, current_cells))
        if pos >= len(chars):
            break
        ch = chars[pos]
        if ch == "\n":
            lines.append("".join(current))
            current = []
            current_cells = 0
            continue
        cw = char_cells(ch)
        if current and current_cells + cw > width:
            lines.append("".join(current))
            current = [ch]
            current_cells = min(width, cw)
            continue
        current.append(ch)
        current_cells = min(width, current_cells + cw)

    lines.append("".join(current))
    if not lines:
        lines = [""]

    max_start = max(0, len(lines) - height)
    start = max(0, min(cursor_line - height + 1, max_start))
    if cursor_line < start:
        start = cursor_line
    end = min(len(lines), start + height)
    visible = lines[start:end] or [""]
    local_y = max(0, min(height - 1, cursor_line - start))
    local_x = max(0, min(width - 1, cursor_col))
    return visible, {"x": local_x, "y": local_y}

def border_enabled(attrs: dict[str, Any] | None) -> bool:
    value = str((attrs or {}).get("border") or "").strip().lower()
    return value in {"1", "true", "yes", "on"}


def content_rect(attrs: dict[str, Any] | None, rect: dict[str, int] | None) -> dict[str, int]:
    base = dict(rect or {})
    if not border_enabled(attrs):
        return base
    return {
        "x": int(base.get("x", 0) or 0) + 1,
        "y": int(base.get("y", 0) or 0) + 1,
        "w": max(1, int(base.get("w", 1) or 1) - 2),
        "h": max(1, int(base.get("h", 1) or 1) - 2),
    }


def _draw_border_frame(width: int, height: int) -> list[str]:
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    frame = [[" " for _ in range(width)] for _ in range(height)]
    if width == 1 and height == 1:
        return ["+"]
    for x in range(width):
        frame[0][x] = "-"
        frame[height - 1][x] = "-"
    for y in range(height):
        frame[y][0] = "|"
        frame[y][width - 1] = "|"
    frame[0][0] = "+"
    frame[0][width - 1] = "+"
    frame[height - 1][0] = "+"
    frame[height - 1][width - 1] = "+"
    return ["".join(row) for row in frame]


def _apply_border(rows: list[str], width: int, height: int) -> list[str]:
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    frame = [list(row) for row in _draw_border_frame(width, height)]
    if width >= 3 and height >= 3:
        inner_w = width - 2
        inner_h = height - 2
        visible = [ljust_cells(row, inner_w) for row in (rows or [""])[:inner_h]]
        if len(visible) < inner_h:
            visible.extend([" " * inner_w] * (inner_h - len(visible)))
        for iy in range(inner_h):
            row = visible[iy]
            for ix, ch in enumerate(row[:inner_w]):
                frame[iy + 1][ix + 1] = ch
    return ["".join(row) for row in frame]


def wrap_text(text: Any, width: int) -> list[str]:
    width = max(1, int(width or 1))
    raw_lines = str(text or "").splitlines()
    if not raw_lines:
        return [""]
    out: list[str] = []
    for raw in raw_lines:
        if raw == "":
            out.append("")
            continue
        wrapped = textwrap.wrap(
            raw,
            width=width,
            replace_whitespace=False,
            drop_whitespace=False,
            break_long_words=True,
            break_on_hyphens=False,
        )
        out.extend(wrapped or [""])
    return out or [""]


def visible_wrap_lines(lines: list[str], width: int, height: int, flow: str = "bottom") -> list[str]:
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    flow = str(flow or "bottom").strip().lower()
    if not lines:
        return [""]
    if flow == "top":
        out: list[str] = []
        for raw in lines:
            wrapped = wrap_text(raw, width)
            remaining = height - len(out)
            if remaining <= 0:
                break
            out.extend(wrapped[:remaining])
            if len(out) >= height:
                break
        return out or [""]
    collected: list[str] = []
    for raw in reversed(lines):
        wrapped = wrap_text(raw, width)
        for item in reversed(wrapped):
            if len(collected) >= height:
                break
            collected.append(item)
        if len(collected) >= height:
            break
    if not collected:
        return [""]
    collected.reverse()
    return collected


def module_align(attrs: dict[str, Any]) -> str:
    align = str((attrs or {}).get("align") or "").strip().lower()
    return align if align in {"left", "center", "right"} else "left"


def module_flow(tag: str, attrs: dict[str, Any]) -> str:
    flow = str((attrs or {}).get("flow") or "").strip().lower()
    if flow in {"top", "middle", "bottom"}:
        return flow
    if str(tag or "").strip().lower() == "q":
        return "top"
    return "bottom"


def _align_row(raw: str, width: int, align: str) -> str:
    width = max(1, int(width or 1))
    clipped = clip_cells(raw, width)
    clipped_w = text_cells(clipped)
    if align == "center":
        dx = max(0, (width - clipped_w) // 2)
    elif align == "right":
        dx = max(0, width - clipped_w)
    else:
        dx = 0
    return (" " * dx) + ljust_cells(clipped, width - dx)


def project_rows(lines: list[str], width: int, height: int, align: str = "left", va: str = "bottom") -> list[str]:
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    visible = [str(item or "") for item in (lines or [""])]
    if len(visible) > height:
        if va == "top":
            visible = visible[:height]
        elif va == "middle":
            start = max(0, (len(visible) - height) // 2)
            visible = visible[start : start + height]
        else:
            visible = visible[-height:]
    out = [" " * width for _ in range(height)]
    if va == "top":
        start_y = 0
    elif va == "middle":
        start_y = max(0, (height - len(visible)) // 2)
    else:
        start_y = max(0, height - len(visible))
    for i, raw in enumerate(visible):
        target = start_y + i
        if 0 <= target < height:
            out[target] = _align_row(raw, width, align)
    return out


def payload(lines: list[str], attrs: dict[str, Any], tag: str, rect: dict[str, int] | None = None) -> dict[str, Any]:
    out = {
        "lines": list(lines),
        "align": module_align(attrs),
        "va": module_flow(tag, attrs),
        "border": border_enabled(attrs),
    }
    if isinstance(rect, dict):
        if out["border"]:
            inner = content_rect(attrs, rect)
            inner_rows = project_rows(
                out["lines"],
                max(1, int(inner.get("w", 1) or 1)),
                max(1, int(inner.get("h", 1) or 1)),
                out["align"],
                out["va"],
            )
            out["screen_rows"] = _apply_border(
                inner_rows,
                max(1, int(rect.get("w", 1) or 1)),
                max(1, int(rect.get("h", 1) or 1)),
            )
        else:
            out["screen_rows"] = project_rows(
                out["lines"],
                max(1, int(rect.get("w", 1) or 1)),
                max(1, int(rect.get("h", 1) or 1)),
                out["align"],
                out["va"],
            )
    return out


def finalize_payload(ctx, module_handle: str, lines: list[str], attrs: dict[str, Any], tag: str, rect: dict[str, int]) -> dict[str, Any]:
    out = payload(lines, attrs, tag, rect=rect)
    ui = get_module_ui(ctx, module_handle)
    current_rows = list(out.get("screen_rows") or [])
    width = max(1, int(rect.get("w", 1) or 1))
    previous_rows = ui.get("_last_screen_rows")
    updates: list[dict[str, Any]] = []
    if isinstance(previous_rows, list):
        max_len = max(len(previous_rows), len(current_rows))
        for i in range(max_len):
            prev = str(previous_rows[i]) if i < len(previous_rows) else (" " * width)
            curr = str(current_rows[i]) if i < len(current_rows) else (" " * width)
            if prev != curr:
                updates.append({"y": i, "text": curr})
    else:
        updates = [{"y": i, "text": row} for i, row in enumerate(current_rows)]
    out["row_updates"] = updates
    ui["_last_screen_rows"] = list(current_rows)
    return out


def resolve_label_input(ctx, binding_handle: str, spec: dict[str, Any]) -> str:
    from . import registry
    from . import state as layout_state

    attrs = dict(spec.get("attrs") or {})
    token = str(attrs.get("input") or "").strip()
    if not token:
        return str(binding_handle or registry.get_active_handle(ctx))
    if token == "|:handle":
        return str(binding_handle or registry.get_active_handle(ctx))
    if token.startswith("|:"):
        return str(layout_state.get_meta(ctx, binding_handle, token[2:], "") or "")
    if token.startswith("|") and ":" in token[1:]:
        owner, key = token.split(":", 1)
        owner_handle = registry.normalize_handle(owner)
        if key == "handle":
            return owner_handle
        meta = layout_state.get_meta(ctx, owner_handle, key, None)
        if meta is not None:
            return str(meta)
        return str(layout_state.get_value(ctx, token, "") or "")
    return str(layout_state.get_value(ctx, token, token) or "")


def _strip_think_tags(text: str) -> str:
    current = str(text or "")
    current = current.replace("<think>", "").replace("</think>", "")
    return current


def sorted_chat_keys(chat: dict[str, Any]) -> list[Any]:
    def sort_key(item: Any):
        text = str(item)
        return (0, int(text)) if text.isdigit() else (1, text)
    return sorted(chat.keys(), key=sort_key)


def _viewport_tail(lines: list[str], height: int, scroll: int = 0) -> list[str]:
    if not lines:
        return [""]
    height = max(1, int(height or 1))
    max_scroll = max(0, len(lines) - height)
    scroll = max(0, min(int(scroll or 0), max_scroll))
    end = max(0, len(lines) - scroll)
    start = max(0, end - height)
    visible = lines[start:end]
    return visible or [""]



def _viewport_head(lines: list[str], height: int, scroll: int = 0) -> list[str]:
    if not lines:
        return [""]
    height = max(1, int(height or 1))
    max_scroll = max(0, len(lines) - height)
    scroll = max(0, min(int(scroll or 0), max_scroll))
    start = min(scroll, max_scroll)
    end = start + height
    visible = lines[start:end]
    return visible or [""]



def render_q_visible_lines(ctx, inst, width: int, height: int, flow: str = "top") -> list[str]:
    from . import state as layout_state

    def _extend_wrapped(dst: list[str], raw: str) -> None:
        dst.extend(wrap_text(raw, width) or [""])

    def _append_chat_entry(dst: list[str], prompt: str, response: str, error: str = "") -> None:
        if prompt:
            _extend_wrapped(dst, f"Q> {prompt}")
        if response:
            _extend_wrapped(dst, f"A> {response}")
            dst.append("")
        if error:
            _extend_wrapped(dst, f"[ERROR] {error}")
            dst.append("")

    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    live_packet: dict[str, Any] = {}
    if parser is not None:
        try:
            from system.lib.q.live import get_live_chat, get_live_packet
            chat = get_live_chat(parser, inst.view_target)
            live_packet = get_live_packet(parser)
        except Exception:
            chat = layout_state.get_value(ctx, inst.view_target, {})
    else:
        chat = layout_state.get_value(ctx, inst.view_target, {})

    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    flow = str(flow or "top").strip().lower()
    ui = get_module_ui(ctx, getattr(inst, "handle", ""))
    follow = bool(ui.get("follow", True))
    scroll = max(0, int(ui.get("scroll", 0) or 0))

    live_chat_symbol = str(live_packet.get("chat_symbol") or "")
    live_key = str(live_packet.get("key") or "")
    live_prompt = _strip_think_tags(str(live_packet.get("prompt") or ""))
    live_response = _strip_think_tags(str(live_packet.get("response") or ""))
    live_thinking = _strip_think_tags(str(live_packet.get("thinking") or ""))
    live_done = 1 if int(live_packet.get("done") or 0) == 1 else 0
    cue_value = str(layout_state.get_value(ctx, f"{getattr(inst, 'primary_target', '')}:cue", "") or "").strip()
    owner_handle = str(getattr(inst, 'parent_layout', '') or getattr(inst, 'handle', '') or '').strip()
    show_thinking_value = str(layout_state.get_value(ctx, f"{owner_handle}:show_thinking", "on") or "on").strip().lower()
    show_thinking = show_thinking_value in {"1", "true", "yes", "on"}

    is_live_for_inst = (
        live_done == 0
        and live_chat_symbol == str(inst.view_target or "")
        and bool(live_key)
    )

    all_lines: list[str] = []

    if is_live_for_inst:
        if show_thinking and live_thinking and not live_response:
            _extend_wrapped(all_lines, f"[THINKING] {live_thinking}")
        elif live_response:
            if live_prompt:
                _extend_wrapped(all_lines, f"Q> {live_prompt}")
            _extend_wrapped(all_lines, f"[RESPONSE] {live_response}")
    else:
        if cue_value:
            cue_line = cue_value if cue_value.startswith("[CUE") else f"[CUE: {cue_value}]"
            _extend_wrapped(all_lines, cue_line)
        if isinstance(chat, dict) and chat:
            keys = sorted_chat_keys(chat)
            iterable = keys if flow == "top" else list(reversed(keys))
            for key in iterable:
                item = chat.get(key) or {}
                if not isinstance(item, dict):
                    continue
                prompt = _strip_think_tags(str(item.get("prompt") or ""))
                response = _strip_think_tags(str(item.get("response") or ""))
                error = _strip_think_tags(str(item.get("error") or ""))
                _append_chat_entry(all_lines, prompt, response, error)

    if not all_lines:
        all_lines = [""]

    if flow != "top":
        all_lines = list(reversed(all_lines))

    if follow:
        ui["scroll"] = 0
        return _viewport_tail(all_lines, height, 0)

    if flow == "top":
        return _viewport_tail(all_lines, height, scroll)
    return _viewport_head(all_lines, height, scroll)


def get_module_ui(ctx, module_handle: str) -> dict[str, Any]:
    ui = ctx.setdefault("layout_ui", {}) if isinstance(ctx, dict) else {}
    modules = ui.setdefault("modules", {})
    return modules.setdefault(module_handle, {})


def render_monitor_lines(ctx, inst, spec: dict[str, Any], rect: dict[str, int]) -> list[str]:
    from . import state as layout_state

    ui = get_module_ui(ctx, inst.handle)
    target = str(inst.view_target or inst.primary_target or "")
    value = layout_state.get_value(ctx, target, "")
    lines = str(value or "").splitlines() or [""]
    width = max(1, int(rect.get("w", 1) or 1))
    height = max(1, int(rect.get("h", 1) or 1))
    flow = module_flow(getattr(inst, "MODULE", ""), spec.get("attrs") or {})
    follow = bool(ui.get("follow", True))
    if follow:
        if flow == "top":
            return visible_wrap_lines(lines, width, height, "top")
        ui["scroll"] = 0
        return visible_wrap_lines(lines, width, height, "bottom")
    scroll = max(0, int(ui.get("scroll", 0) or 0))
    if flow == "top":
        visible = visible_wrap_lines(lines, width, max(1, scroll + height), "top")
        return visible[scroll : scroll + height] or [""]
    visible = visible_wrap_lines(lines, width, height + scroll, "bottom")
    if scroll > 0:
        visible = visible[:-scroll] if scroll < len(visible) else [""]
    return visible[-height:] or [""]


def render_list_lines(ctx, inst) -> list[str]:
    from . import state as layout_state

    value = layout_state.get_value(ctx, inst.primary_target, None)
    if isinstance(value, dict):
        keys = sorted_chat_keys(value)
        selected = int(get_module_ui(ctx, inst.handle).get("selected", 0) or 0)
        out: list[str] = []
        for i, key in enumerate(keys):
            prefix = "> " if i == selected else "  "
            out.append(f"{prefix}{key}: {value.get(key)}")
        return out or [""]
    if isinstance(value, list):
        selected = int(get_module_ui(ctx, inst.handle).get("selected", 0) or 0)
        out: list[str] = []
        for i, item in enumerate(value):
            prefix = "> " if i == selected else "  "
            out.append(f"{prefix}{item}")
        return out or [""]
    return str(value or "").splitlines() or [""]


def render_editor_lines(ctx, inst) -> list[str]:
    from . import state as layout_state
    value = layout_state.get_value(ctx, inst.primary_target, "")
    return str(value or "").splitlines() or [""]
