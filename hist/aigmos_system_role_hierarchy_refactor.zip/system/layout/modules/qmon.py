from __future__ import annotations

from typing import Any

MODULE = "qmon"
STORAGE_PREFIX = "QMON"
DEFAULT_PROMPT = "cs> "
FOCUSABLE = True


def _runtime_root_from_target(raw_target: str) -> str:
    clean = str(raw_target or "").strip()
    if not clean:
        return ""
    if clean.startswith("|"):
        if ":" in clean[1:]:
            return clean
        return f"{clean}:q"
    if clean.startswith("$"):
        return clean
    return clean


def get_targets(handle: str, config: dict[str, Any] | None = None) -> tuple[str, str]:
    cfg = dict(config or {})
    source_root = str(cfg.get("source_root") or cfg.get("target") or cfg.get("alias_target") or "").strip()
    base = _runtime_root_from_target(source_root)
    if not base:
        base = "|Q:q"
    return base, f"{base}:ch"


def measure(ctx, binding_handle: str, spec: dict[str, Any], width: int, instance) -> dict[str, Any]:
    return {"min_h": 1, "scalable_y": True}


def build_payload(ctx, binding_handle: str, spec: dict[str, Any], rect: dict[str, int], instance):
    from system.layout.module_api import content_rect, finalize_payload
    attrs = dict(spec.get("attrs") or {})
    flow = str(attrs.get("flow") or "top").strip().lower() or "top"
    inner_rect = content_rect(attrs, rect)
    from system.layout.module_api import render_q_visible_lines
    lines = render_q_visible_lines(ctx, instance, int(inner_rect.get("w", 1) or 1), int(inner_rect.get("h", 1) or 1), flow)
    return finalize_payload(ctx, instance.handle, lines or [""], attrs, "q", rect)


def handle_key(ctx, module_handle: str, key: int) -> bool:
    import curses
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    if key == curses.KEY_UP:
        ui["follow"] = False
        ui["scroll"] = int(ui.get("scroll", 0) or 0) + 1
        layout_input._mark_dirty(ctx)
        return True
    if key == curses.KEY_DOWN:
        current = max(0, int(ui.get("scroll", 0) or 0) - 1)
        ui["scroll"] = current
        if current == 0:
            ui["follow"] = True
        layout_input._mark_dirty(ctx)
        return True
    if key == curses.KEY_HOME:
        ui["follow"] = False
        ui["scroll"] = 10 ** 9
        layout_input._mark_dirty(ctx)
        return True
    if key == curses.KEY_END:
        ui["follow"] = True
        ui["scroll"] = 0
        layout_input._mark_dirty(ctx)
        return True
    return False


def clear(ctx, module_handle: str, instance):
    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    ui["follow"] = True
    ui["scroll"] = 0
    return True
