from __future__ import annotations

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_ctx
from system.lib.reload_ops import (
    apply_role_runtime,
    import_help_tree,
    import_prompt_tree,
    import_roles_tree,
    import_routine_tree,
    normalize_role_name,
    reload_one_role,
)

command = "reload"
help_short = "reload <help|roles|role <role>|prompts|routines|layout|config|commands|adapters|inputs|all>"
help_full = """reload selected subsystems and content trees

examples:
  reload help
  reload roles
  reload role system/help
  reload prompts
  reload routines
  reload layout
"""


def _reload_layout(parser) -> list[str]:
    from system.layout import registry as layout_registry

    ctx = get_ctx(parser)
    names = layout_registry.reload_layout(ctx)
    apply_role_runtime(ctx)
    return names


def _reload_config(parser):
    from system.cs.commands.slash import _reload_config as slash_reload_config

    return slash_reload_config(parser)


def _reload_commands(parser):
    from system.cs.commands.slash import _reload_commands_only

    return _reload_commands_only(parser)


def _reload_adapters(parser):
    from system.cs.commands.slash import _reload_adapters_only

    return _reload_adapters_only(parser)


def _reload_inputs(parser):
    from system.cs.commands.slash import _reload_inputs_only

    return _reload_inputs_only(parser)


def handler(line: str, parser):
    parts = [part for part in str(line or "").split() if part]
    if len(parts) < 2:
        return HandlerResponse(error="usage: reload <help|roles|role <role>|prompts|routines|layout|config|commands|adapters|inputs|all>")

    target = parts[1].strip().lower()
    ctx = get_ctx(parser)
    state = ctx.get("state") if isinstance(ctx, dict) else getattr(parser, "state", None)

    try:
        if target == "help":
            written = import_help_tree(state)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload help ({len(written)})", force_render=True)

        if target == "prompts":
            written = import_prompt_tree(state)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload prompts ({len(written)})", force_render=True)

        if target == "routines":
            written = import_routine_tree(state)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload routines ({len(written)})", force_render=True)

        if target == "roles":
            written = import_roles_tree(state)
            touched = apply_role_runtime(ctx)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload roles ({len(written)} files, {len(touched)} q modules)", force_render=True)

        if target == "role":
            if len(parts) < 3:
                return HandlerResponse(error="usage: reload role <role>")
            role_name = normalize_role_name(parts[2])
            written = reload_one_role(state, role_name)
            touched = apply_role_runtime(ctx, role_name=role_name)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload role {role_name} ({len(written)} files, {len(touched)} q modules)", force_render=True)

        if target == "layout":
            names = _reload_layout(parser)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload layout ({len(names)})", force_render=True)

        if target == "config":
            _reload_config(parser)
            force_render(parser)
            return HandlerResponse(buffer_output="[ok] reload config", force_render=True)

        if target == "commands":
            names = _reload_commands(parser)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload commands ({len(names)})", force_render=True)

        if target == "adapters":
            names = _reload_adapters(parser)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload adapters ({len(names)})", force_render=True)

        if target == "inputs":
            names = _reload_inputs(parser)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload inputs ({len(names)})", force_render=True)

        if target == "all":
            _reload_config(parser)
            _reload_commands(parser)
            import_help_tree(state)
            import_prompt_tree(state)
            import_routine_tree(state)
            import_roles_tree(state)
            names = _reload_layout(parser)
            _reload_adapters(parser)
            _reload_inputs(parser)
            force_render(parser)
            return HandlerResponse(buffer_output=f"[ok] reload all ({len(names)} layouts)", force_render=True)

        return HandlerResponse(error=f"unknown reload target: {target}")
    except Exception as exc:
        return HandlerResponse(error=str(exc), force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
