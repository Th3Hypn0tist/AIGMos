from __future__ import annotations

from system.cs.runtime_ctx import get_ctx, get_layout_caller_handle, get_runtime


def q_sampler_prefix_for_profile(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    if clean == "default":
        return "$Q"
    return f"$Q.{clean}"


def q_state_prefix_for_profile(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    if clean == "default":
        return "$Q"
    return f"$Q.{clean}"


def q_state_prefix_for_handle(handle: str) -> str:
    clean = str(handle or "").strip()
    if not clean.startswith("|"):
        return ""
    return clean


def q_state_prefix_for_runtime(parser, profile_name: str = "default") -> str:
    handle = str(get_layout_caller_handle(parser) or "").strip()
    if handle:
        ctx = get_ctx(parser)
        if isinstance(ctx, dict) and ctx:
            try:
                from system.layout import registry as layout_registry

                inst = layout_registry.get_instance(ctx, handle)
                module_name = str(getattr(inst, "MODULE", "") or "").strip().lower()
                if module_name == "q":
                    root = str(getattr(inst, "primary_target", "") or "").strip()
                    if root:
                        return root
                    direct = q_state_prefix_for_handle(getattr(inst, "handle", ""))
                    if direct:
                        return direct
                return q_state_prefix_for_profile(profile_name)
            except Exception:
                pass
    return q_state_prefix_for_profile(profile_name)


def role_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:role"


def system_prompt_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:system_prompt"


def chat_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:ch"


def chat_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:ch"


def get_active_chat_symbol(parser) -> str:
    value = get_runtime(parser, "q_chat_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return chat_symbol_for_profile("default")


def response_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:response"


def response_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:response"


def get_active_response_symbol(parser) -> str:
    value = get_runtime(parser, "q_response_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return response_symbol_for_profile("default")


def thinking_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:thinking_text"


def thinking_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:thinking_text"


def get_active_thinking_symbol(parser) -> str:
    value = get_runtime(parser, "q_thinking_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return thinking_symbol_for_profile("default")


def role_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:role"


def system_prompt_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:system_prompt"


__all__ = [
    "q_sampler_prefix_for_profile",
    "q_state_prefix_for_profile",
    "q_state_prefix_for_handle",
    "q_state_prefix_for_runtime",
    "role_symbol_for_profile",
    "system_prompt_symbol_for_profile",
    "chat_symbol_for_profile",
    "chat_symbol_for_runtime",
    "get_active_chat_symbol",
    "response_symbol_for_profile",
    "response_symbol_for_runtime",
    "get_active_response_symbol",
    "thinking_symbol_for_profile",
    "thinking_symbol_for_runtime",
    "get_active_thinking_symbol",
    "role_symbol_for_runtime",
    "system_prompt_symbol_for_runtime",
]
