from __future__ import annotations

import re
from typing import Any

from system.cs.runtime_ctx import get_ctx, get_layout_caller_handle
from system.lib.symbols import SymbolError, _SYMBOL_RE, is_symbol_ref, resolve_raw_exact, stringify_resolved

_LAYOUT_REL_RE = re.compile(r"(\|:(?:[A-Za-z0-9._-]+(?::[A-Za-z0-9._-]+)*))")
_LAYOUT_ABS_RE = re.compile(r"(\|[A-Za-z0-9._-]+:(?:[A-Za-z0-9._-]+(?::[A-Za-z0-9._-]+)*))")


def _is_structured_value(value: Any) -> bool:
    return isinstance(value, (dict, list))


def _freeze_value(frozen: dict[str, str], counter: list[int], value: Any) -> str:
    idx = int(counter[0])
    counter[0] = idx + 1
    token = f"\x00AIGMOS_FROZEN_{idx}\x00"
    frozen[token] = stringify_resolved(value)
    return token


def _restore_frozen(text: str, frozen: dict[str, str]) -> str:
    current = str(text or "")
    for token, value in frozen.items():
        current = current.replace(token, value)
    return current


def _resolve_layout_prompt_value(parser, token: str) -> tuple[bool, Any]:
    raw = str(token or "").strip()
    if not raw.startswith("|") or ":" not in raw:
        return False, raw

    ctx = get_ctx(parser)
    if not isinstance(ctx, dict) or not ctx:
        return False, raw

    from system.layout import state as layout_state
    from system.layout import registry as layout_registry

    if raw == "|:handle":
        handle = str(get_layout_caller_handle(parser) or "").strip()
        return (bool(handle), handle or raw)

    if raw.startswith("|:"):
        handle = str(get_layout_caller_handle(parser) or "").strip()
        if not handle:
            return False, raw
        key = raw[2:]
        if not key:
            return False, raw
        if key == "handle":
            return True, handle
        meta = layout_state.get_meta(ctx, handle, key, None)
        if meta is not None:
            return True, meta
        value = layout_state.get_value(ctx, f"{handle}:{key}", None)
        return (value is not None, value if value is not None else raw)

    owner, key = raw.split(":", 1)
    if not key:
        return False, raw
    try:
        owner_handle = layout_registry.normalize_handle(owner)
    except Exception:
        return False, raw
    if key == "handle":
        return True, owner_handle
    meta = layout_state.get_meta(ctx, owner_handle, key, None)
    if meta is not None:
        return True, meta
    value = layout_state.get_value(ctx, f"{owner_handle}:{key}", None)
    return (value is not None, value if value is not None else raw)


def _expand_layout_prompt_symbols_once(parser, text: str, frozen: dict[str, str], counter: list[int]) -> str:
    current = str(text or "")

    def _replace_abs(match: re.Match[str]) -> str:
        token = str(match.group(1) or "")
        found, value = _resolve_layout_prompt_value(parser, token)
        if not found:
            return token
        if _is_structured_value(value):
            return _freeze_value(frozen, counter, value)
        return stringify_resolved(value)

    current = _LAYOUT_ABS_RE.sub(_replace_abs, current)

    def _replace_rel(match: re.Match[str]) -> str:
        token = str(match.group(1) or "")
        found, value = _resolve_layout_prompt_value(parser, token)
        if not found:
            return token
        if _is_structured_value(value):
            return _freeze_value(frozen, counter, value)
        return stringify_resolved(value)

    current = _LAYOUT_REL_RE.sub(_replace_rel, current)
    return current


def _expand_state_prompt_symbols_once(parser, text: str, frozen: dict[str, str], counter: list[int]) -> str:
    current = str(text or "")

    def _replace(match: re.Match[str]) -> str:
        token = str(match.group(1) or "")
        value = resolve_raw_exact(parser.state, token)
        if value is None:
            raise SymbolError(f"symbol not found: {token}")
        if _is_structured_value(value):
            return _freeze_value(frozen, counter, value)
        return stringify_resolved(value)

    return _SYMBOL_RE.sub(_replace, current)


def expand_prompt_symbols(parser, text: str, max_passes: int = 128) -> str:
    current = str(text or "")
    frozen: dict[str, str] = {}
    counter = [0]

    passes = max(1, int(max_passes or 1))
    for _ in range(passes):
        updated = _expand_layout_prompt_symbols_once(parser, current, frozen, counter)
        updated = _expand_state_prompt_symbols_once(parser, updated, frozen, counter)
        if updated == current:
            return _restore_frozen(updated, frozen)
        current = updated

    return _restore_frozen(current, frozen)


def expand_prompt_tokens(parser, tokens: list[str]) -> str:
    return expand_prompt_symbols(parser, " ".join(str(token) for token in tokens).strip())


__all__ = [
    "expand_prompt_symbols",
    "expand_prompt_tokens",
    "is_symbol_ref",
    "resolve_raw_exact",
]
