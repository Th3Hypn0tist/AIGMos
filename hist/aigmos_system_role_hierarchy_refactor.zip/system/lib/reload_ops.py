
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from system.state.api import delete_value, list_symbols, read_value, write_value

ROLE_PARAM_KEYS = (
    "temperature",
    "top_p",
    "top_k",
    "repeat_penalty",
    "thinking",
)


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _state_get(state, symbol: str, default: Any = None) -> Any:
    return read_value(state, symbol, default)


def _state_set(state, symbol: str, value: Any, *, writer: str = "reload") -> None:
    out = write_value(state, symbol, value, writer=writer, op="reload_set")
    if out.get("error"):
        raise ValueError(str(out["error"]))


def _state_delete(state, symbol: str, *, writer: str = "reload") -> None:
    out = delete_value(state, symbol, writer=writer, op="reload_delete")
    if out.get("error"):
        raise ValueError(str(out["error"]))


def _clear_prefixes(state, prefixes: list[str]) -> None:
    all_symbols = list_symbols(state)
    doomed: set[str] = set()
    for prefix in prefixes:
        clean = str(prefix or "").strip()
        if not clean:
            continue
        for symbol in all_symbols:
            if symbol == clean or symbol.startswith(clean + ":"):
                doomed.add(symbol)
    for symbol in sorted(doomed, key=lambda x: (-len(x), x)):
        _state_delete(state, symbol)


def _iter_text_files(base: Path):
    if not base.is_dir():
        return
    for path in sorted(base.rglob('*')):
        if not path.is_file():
            continue
        if path.name.startswith('.'):
            continue
        yield path


def _symbol_from_rel(prefix: str, rel: Path) -> str:
    parts = [part for part in rel.parts if part]
    if not parts:
        raise ValueError("empty relative path")
    return prefix + ":" + ":".join(parts)


def import_help_tree(state) -> list[str]:
    base = project_root() / 'system' / 'library' / 'help'
    _clear_prefixes(state, ['#HELP'])
    written: list[str] = []
    if not base.is_dir():
        return written
    for path in _iter_text_files(base):
        rel = path.relative_to(base)
        symbol = _symbol_from_rel('#HELP', rel)
        _state_set(state, symbol, path.read_text(encoding='utf-8'))
        written.append(symbol)
    return written


def import_prompt_tree(state) -> list[str]:
    written: list[str] = []
    _clear_prefixes(state, ['#P'])
    roots = [
        (project_root() / 'extensions' / 'prompts', '#P'),
        (project_root() / 'system' / 'library' / 'prompts', '#P:system'),
    ]
    for base, prefix in roots:
        if not base.is_dir():
            continue
        for path in _iter_text_files(base):
            rel = path.relative_to(base)
            symbol = _symbol_from_rel(prefix, rel)
            _state_set(state, symbol, path.read_text(encoding='utf-8'))
            written.append(symbol)
    return written


def import_routine_tree(state) -> list[str]:
    written: list[str] = []
    _clear_prefixes(state, ['#R'])
    roots = [
        (project_root() / 'extensions' / 'routines', '#R'),
        (project_root() / 'system' / 'library' / 'routines', '#R:system'),
    ]
    for base, prefix in roots:
        if not base.is_dir():
            continue
        for path in _iter_text_files(base):
            rel = path.relative_to(base)
            symbol = _symbol_from_rel(prefix, rel)
            _state_set(state, symbol, path.read_text(encoding='utf-8'))
            written.append(symbol)
    return written


def normalize_role_name(value: Any) -> str:
    raw = str(value or '').strip()
    if not raw:
        return ''
    if raw.startswith('#ROLES:'):
        body = raw[len('#ROLES:'):].strip()
        if body.endswith('.role'):
            body = body[:-5]
        elif body.endswith('.system'):
            body = body[:-7]
        return body.replace(':', '/').strip('/')
    body = raw.strip('/').replace(':', '/')
    if body.endswith('.role'):
        body = body[:-5]
    if body.endswith('.system'):
        body = body[:-7]
    return body.strip('/')


def role_symbol_name(role_name: str) -> str:
    clean = normalize_role_name(role_name)
    if not clean:
        return ''
    return '#ROLES:' + clean.replace('/', ':') + '.role'


def role_system_symbol_name(role_name: str) -> str:
    clean = normalize_role_name(role_name)
    if not clean:
        return ''
    return '#ROLES:' + clean.replace('/', ':') + '.system'


def _import_role_files_from_root(state, base: Path, prefix: str) -> list[str]:
    written: list[str] = []
    if not base.is_dir():
        return written
    for path in sorted(base.rglob('*')):
        if not path.is_file():
            continue
        if path.suffix not in {'.role', '.system'}:
            continue
        rel = path.relative_to(base)
        symbol = _symbol_from_rel(prefix, rel)
        if path.suffix == '.role':
            payload = json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(payload, dict):
                raise ValueError(f'role file must contain JSON object: {path}')
            _state_set(state, symbol, payload)
        else:
            _state_set(state, symbol, path.read_text(encoding='utf-8'))
        written.append(symbol)
    return written


def import_roles_tree(state) -> list[str]:
    _clear_prefixes(state, ['#ROLES'])
    written: list[str] = []
    written.extend(_import_role_files_from_root(state, project_root() / 'extensions' / 'roles', '#ROLES'))
    written.extend(_import_role_files_from_root(state, project_root() / 'system' / 'library' / 'roles', '#ROLES:system'))
    return written


def reload_one_role(state, role_name: str) -> list[str]:
    clean = normalize_role_name(role_name)
    if not clean:
        raise ValueError('reload role requires role path')

    prefix = '#ROLES:' + clean.replace('/', ':')
    _clear_prefixes(state, [prefix + '.role', prefix + '.system'])

    candidates: list[tuple[Path, str]] = []
    parts = clean.split('/')
    ext_base = project_root() / 'extensions' / 'roles'
    sys_base = project_root() / 'system' / 'library' / 'roles'

    if parts and parts[0] == 'system':
        rel_parts = parts[1:]
        candidates.append((sys_base / Path(*rel_parts), '#ROLES:system:' + ':'.join(rel_parts) if rel_parts else '#ROLES:system'))
    else:
        candidates.append((ext_base / Path(*parts), '#ROLES:' + ':'.join(parts)))
        candidates.append((sys_base / Path(*parts), '#ROLES:system:' + ':'.join(parts)))

    written: list[str] = []
    found = False
    for stem_path, symbol_prefix in candidates:
        role_path = stem_path.with_suffix('.role')
        system_path = stem_path.with_suffix('.system')
        if role_path.is_file():
            found = True
            payload = json.loads(role_path.read_text(encoding='utf-8'))
            if not isinstance(payload, dict):
                raise ValueError(f'role file must contain JSON object: {role_path}')
            _state_set(state, symbol_prefix + '.role', payload)
            written.append(symbol_prefix + '.role')
        if system_path.is_file():
            found = True
            _state_set(state, symbol_prefix + '.system', system_path.read_text(encoding='utf-8'))
            written.append(symbol_prefix + '.system')
        if found:
            break

    if not found:
        raise ValueError(f'role not found: {clean}')
    return written


def read_role_package(state, role_name: str) -> dict[str, Any]:
    clean = normalize_role_name(role_name)
    if not clean:
        return {'role': '', 'payload': {}, 'system_prompt': ''}
    payload = _state_get(state, role_symbol_name(clean), {})
    if not isinstance(payload, dict):
        payload = {}
    system_prompt = str(_state_get(state, role_system_symbol_name(clean), '') or '')
    return {
        'role': clean,
        'payload': dict(payload),
        'system_prompt': system_prompt,
    }


def apply_role_to_q_instance(ctx, instance, role_name: str) -> None:
    if instance is None:
        return
    state = ctx.get('state') if isinstance(ctx, dict) else None
    if state is None:
        return
    runtime_root = str(getattr(instance, 'primary_target', '') or '').strip()
    if not runtime_root:
        return
    package = read_role_package(state, role_name)
    clean_role = str(package.get('role') or '')
    payload = dict(package.get('payload') or {})
    system_prompt = str(package.get('system_prompt') or '')

    _state_set(state, f'{runtime_root}:role', clean_role)
    _state_set(state, f'{runtime_root}:system_prompt', system_prompt)
    for key in ROLE_PARAM_KEYS:
        _state_set(state, f'{runtime_root}:{key}', payload.get(key, ''))


def apply_role_runtime(ctx, *, role_name: str | None = None) -> list[str]:
    from system.layout import registry as layout_registry

    runtime = ctx.setdefault('layout_runtime', {}) if isinstance(ctx, dict) else {}
    instances = dict(runtime.get('instances') or {})
    updated: list[str] = []
    only_role = normalize_role_name(role_name) if role_name else ''
    for handle, instance in instances.items():
        if str(getattr(instance, 'MODULE', '') or '').strip().lower() != 'q':
            continue
        config = dict(getattr(instance, 'config', {}) or {})
        role = normalize_role_name(config.get('role') or _state_get(ctx.get('state'), f"{getattr(instance, 'primary_target', '')}:role", ''))
        if not role:
            continue
        if only_role and role != only_role:
            continue
        apply_role_to_q_instance(ctx, instance, role)
        updated.append(str(getattr(instance, 'handle', handle) or handle))
    return updated
