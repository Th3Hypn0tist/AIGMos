from __future__ import annotations

from system.cs.runtime_ctx import get_ctx, get_layout_caller_handle, get_runtime


def q_sampler_prefix_for_profile(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    if clean == "default":
        return "$q"
    return f"$q.{clean}"


def q_state_prefix_for_profile(profile_name: str) -> str:
    clean = str(profile_name or "default").strip() or "default"
    if clean == "default":
        return "|Q:q"
    return f"|Q:{clean}"


def q_state_prefix_for_handle(parser, handle: str) -> str:
    clean = str(handle or "").strip()
    if not clean.startswith("|"):
        return ""
    ctx = get_ctx(parser)
    if not isinstance(ctx, dict) or not ctx:
        return ""
    try:
        from system.layout import registry as layout_registry
        if layout_registry.has_instance(ctx, clean):
            inst = layout_registry.get_instance(ctx, clean)
            if str(getattr(inst, "MODULE", "") or "").strip().lower() == "q":
                return str(getattr(inst, "primary_target", "") or "").strip()
            parent = str(getattr(inst, "parent_layout", "") or "").strip()
            if parent:
                clean = parent
        if layout_registry.has_layout_binding(ctx, clean):
            for module_handle in layout_registry.get_bound_layout_modules(ctx, clean):
                inst = layout_registry.get_instance(ctx, module_handle)
                if str(getattr(inst, "MODULE", "") or "").strip().lower() == "q":
                    return str(getattr(inst, "primary_target", "") or "").strip()
    except Exception:
        return ""
    return ""


def q_state_prefix_for_runtime(parser, profile_name: str = "default") -> str:
    handle = get_layout_caller_handle(parser)
    from_handle = q_state_prefix_for_handle(parser, handle)
    if from_handle:
        return from_handle
    active_chat = str(get_runtime(parser, "q_chat_symbol", "") or "").strip()
    if active_chat.startswith("|") and ":" in active_chat:
        return active_chat.rsplit(":", 1)[0]
    return q_state_prefix_for_profile(profile_name)


def role_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:role"


def system_prompt_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:system_prompt"


def chat_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:ch"


def chat_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:ch"


def get_active_chat_symbol(parser) -> str:
    value = get_runtime(parser, "q_chat_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return chat_symbol_for_runtime(parser, "default")


def response_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:response"


def response_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:response"


def get_active_response_symbol(parser) -> str:
    value = get_runtime(parser, "q_response_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return response_symbol_for_runtime(parser, "default")


def thinking_symbol_for_profile(profile_name: str) -> str:
    return f"{q_state_prefix_for_profile(profile_name)}:thinking_text"


def thinking_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:thinking_text"


def get_active_thinking_symbol(parser) -> str:
    value = get_runtime(parser, "q_thinking_symbol", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return thinking_symbol_for_runtime(parser, "default")


def role_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:role"


def system_prompt_symbol_for_runtime(parser, profile_name: str = "default") -> str:
    return f"{q_state_prefix_for_runtime(parser, profile_name)}:system_prompt"


__all__ = [
    "q_sampler_prefix_for_profile",
    "q_state_prefix_for_profile",
    "q_state_prefix_for_handle",
    "q_state_prefix_for_runtime",
    "role_symbol_for_profile",
    "system_prompt_symbol_for_profile",
    "chat_symbol_for_profile",
    "chat_symbol_for_runtime",
    "get_active_chat_symbol",
    "response_symbol_for_profile",
    "response_symbol_for_runtime",
    "get_active_response_symbol",
    "thinking_symbol_for_profile",
    "thinking_symbol_for_runtime",
    "get_active_thinking_symbol",
    "role_symbol_for_runtime",
    "system_prompt_symbol_for_runtime",
]
