from __future__ import annotations

from dataclasses import dataclass, field
import threading
from typing import Any

from system.cs.runtime_ctx import force_render, get_runtime, set_runtime
from system.cs.symbols import is_symbol_line
from system.state.api import append_numeric_value

from . import definitions
from . import loader as module_loader
from . import state as layout_state
from . import store as layout_store

_IGNORE_BOUND_TAGS = {"label"}


@dataclass
class LayoutInstance:
    handle: str
    MODULE: str
    parent_layout: str = ""
    config: dict[str, Any] = field(default_factory=dict)
    primary_target: str = ""
    view_target: str = ""
    title: str = ""
    prompt: str = "cs> "

    def get_title(self) -> str:
        return str(self.title or self.handle)

    def get_prompt(self) -> str:
        return str(self.prompt or "cs> ")



def _runtime(ctx) -> dict[str, Any]:
    runtime = ctx.setdefault("layout_runtime", {})
    runtime.setdefault("bootstrapped", False)
    runtime.setdefault("bindings", {})
    runtime.setdefault("instances", {})
    runtime.setdefault("active_handle", "")
    runtime.setdefault("saved_instances", {})
    runtime.setdefault("_restoring_store", False)
    runtime.setdefault("_persist_suspended", 0)
    return runtime



def _module_prefix(module_name: str) -> str:
    return str(module_loader.module_meta(module_name)["storage_prefix"])


def _module_prompt(module_name: str) -> str:
    return str(module_loader.module_meta(module_name)["default_prompt"])


def normalize_handle(raw: str) -> str:
    text = str(raw or "").strip()
    if not text:
        raise ValueError("layout handle cannot be empty")
    if not text.startswith("|"):
        raise ValueError("layout handle must start with |")
    body = text[1:].strip()
    if not body:
        raise ValueError("layout handle cannot be empty")
    if ":" in body:
        raise ValueError("layout handle cannot contain :")
    parts = [part for part in body.split(".") if part != ""]
    if not parts:
        raise ValueError("layout handle cannot be empty")
    head = parts[0].upper()
    tail = parts[1:]
    return "|" + ".".join([head, *tail])



def _route_name(route: str) -> str:
    token = str(route or "").strip()
    if token.startswith("/"):
        token = token[1:]
    return token.strip()



def _layout_handle_from_route(route: str) -> str:
    token = _route_name(route)
    if not token:
        raise ValueError("layout route cannot be empty")
    base, dot, suffix = token.partition(".")
    head = base.upper()
    return f"|{head}.{suffix}" if suffix else f"|{head}"



def _display_name(handle: str) -> str:
    return str(handle or "").strip().lstrip("|")



def _binding_name(binding_handle: str) -> str:
    return _display_name(binding_handle).split(".", 1)[0]



def _instance_suffix(binding_handle: str, tag: str, ordinal: int) -> str:
    return f"{tag}{int(ordinal)}"



def _instance_handle(binding_handle: str, tag: str, ordinal: int) -> str:
    prefix = _module_prefix(tag)
    owner = _display_name(binding_handle)
    return f"|{prefix}.{owner}.{_instance_suffix(binding_handle, tag, ordinal)}"



def _config_for_spec(binding_handle: str, route_name: str, spec: dict[str, Any]) -> dict[str, Any]:
    tag = str(spec.get("tag") or "").strip().lower()
    attrs = dict(spec.get("attrs") or {})
    alias_target = str(attrs.get("alias") or "").strip()
    input_target = str(attrs.get("input") or "").strip()
    config: dict[str, Any] = {
        "bound_module_name": tag,
        "layout_name": _route_name(route_name),
        "instance_suffix": _instance_suffix(binding_handle, tag, int(spec.get("ordinal") or 1)),
        "module_id": str(attrs.get("id") or _instance_suffix(binding_handle, tag, int(spec.get("ordinal") or 1))).strip(),
    }
    if alias_target == "|":
        alias_target = binding_handle
    if alias_target:
        config["alias_target"] = alias_target
    if input_target:
        config["input"] = input_target

    if tag == "monitor":
        config["target"] = f"{alias_target}:buffer" if alias_target else f"{binding_handle}:buffer"
    elif tag == "q":
        profile = alias_target or attrs.get("alias") or attrs.get("profile") or "default"
        config["profile"] = str(profile or "default")
    elif tag == "qmon":
        target = str(attrs.get("target") or alias_target or "").strip()
        if target == "|":
            target = binding_handle
        if target:
            config["target"] = target
    return config



def _primary_target_for(module_name: str, handle: str, config: dict[str, Any]) -> tuple[str, str]:
    module = load_module(ctx=None, module_name=module_name)
    primary_target, view_target = module.get_targets(handle, dict(config or {}))
    return str(primary_target), str(view_target)


def load_module(ctx, module_name: str):
    return module_loader.load_module(module_name)



def is_ui_instance_switch_line(line: str) -> bool:
    clean = str(line or "").strip()
    if not clean or not clean.startswith("|"):
        return False
    if any(ch.isspace() for ch in clean):
        return False
    if "=" in clean:
        return False
    try:
        normalize_handle(clean)
    except Exception:
        return False
    return True


def _active_handle_for_store(ctx) -> str:
    runtime = _runtime(ctx)
    active = str(runtime.get("active_handle") or "").strip()
    if active:
        return active
    persisted = layout_state.get_meta(ctx, "|LAYOUT", "active_handle", "")
    return str(persisted or "").strip()


def _layout_store_payload(ctx) -> dict[str, Any]:
    runtime = _runtime(ctx)
    bindings: dict[str, Any] = {}
    for handle, binding in dict(runtime.get("bindings") or {}).items():
        clean_handle = str(handle or "").strip()
        if not clean_handle:
            continue
        item = dict(binding or {})
        bindings[clean_handle] = {
            "route_name": _route_name(item.get("route_name") or _binding_name(clean_handle)),
            "tree": item.get("tree"),
            "specs": list(item.get("specs") or []),
        }

    instances: dict[str, Any] = {}
    for handle, instance in dict(runtime.get("instances") or {}).items():
        if instance is None:
            continue
        clean_handle = str(getattr(instance, "handle", handle) or "").strip()
        if not clean_handle:
            continue
        parent_layout = str(getattr(instance, "parent_layout", "") or "").strip()
        if parent_layout:
            continue
        instances[clean_handle] = {
            "module": str(getattr(instance, "MODULE", "") or "").strip().lower(),
            "config": dict(getattr(instance, "config", {}) or {}),
            "title": str(getattr(instance, "title", "") or ""),
            "prompt": str(getattr(instance, "prompt", "") or ""),
        }

    return {
        "version": layout_store.STORE_VERSION,
        "active_handle": _active_handle_for_store(ctx),
        "bindings": bindings,
        "instances": instances,
    }


def _persist_runtime(ctx) -> None:
    runtime = _runtime(ctx)
    if runtime.get("_restoring_store"):
        return
    if int(runtime.get("_persist_suspended") or 0) > 0:
        return
    state = ctx.get("state") if isinstance(ctx, dict) else None
    if state is None:
        return
    layout_store.save_layout_store(state, _layout_store_payload(ctx))


def _binding_specs_from_store(route_name: str, item: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    tree = item.get("tree")
    specs = item.get("specs")
    if isinstance(specs, list) and specs:
        return list(specs), tree if isinstance(tree, dict) else tree
    if isinstance(tree, dict):
        try:
            return list(definitions.flatten_module_specs(tree)), tree
        except Exception:
            pass
    parsed = definitions.parse_layout_definition(_route_name(route_name))
    return list(definitions.flatten_module_specs(parsed)), parsed


def _restore_runtime_from_store(ctx) -> None:
    runtime = _runtime(ctx)
    state = ctx.get("state") if isinstance(ctx, dict) else None
    if state is None:
        return
    payload = layout_store.load_layout_store(state)
    if not isinstance(payload, dict):
        payload = {}

    bindings = payload.get("bindings") if isinstance(payload.get("bindings"), dict) else {}
    instances = payload.get("instances") if isinstance(payload.get("instances"), dict) else {}

    runtime["_restoring_store"] = True
    runtime["_persist_suspended"] = int(runtime.get("_persist_suspended") or 0) + 1
    try:
        for handle in sorted(bindings.keys()):
            item = bindings.get(handle)
            if not isinstance(item, dict):
                continue
            clean_handle = normalize_handle(handle)
            route_name = _route_name(item.get("route_name") or _binding_name(clean_handle))
            specs, tree = _binding_specs_from_store(route_name, item)
            create_layout_binding(ctx, clean_handle, route_name, specs, tree=tree)

        for handle in sorted(instances.keys()):
            if handle in runtime.get("bindings", {}):
                continue
            item = instances.get(handle)
            if not isinstance(item, dict):
                continue
            module_name = str(item.get("module") or "").strip().lower()
            if not module_name:
                continue
            clean_handle = normalize_handle(handle)
            inst = create_instance(ctx, module_name, clean_handle, dict(item.get("config") or {}), start=True)
            title = str(item.get("title") or "").strip()
            prompt = str(item.get("prompt") or "").strip()
            if title:
                inst.title = title
            if prompt:
                inst.prompt = prompt
            _write_meta_for_instance(ctx, inst)
    finally:
        runtime["_persist_suspended"] = max(0, int(runtime.get("_persist_suspended") or 0) - 1)
        runtime["_restoring_store"] = False

    active = str(payload.get("active_handle") or layout_state.get_meta(ctx, "|LAYOUT", "active_handle", "") or "").strip()
    if active:
        try:
            runtime["active_handle"] = normalize_handle(active)
        except Exception:
            runtime["active_handle"] = ""


def _delete_instance_symbols(ctx, handle: str) -> None:
    state = ctx.get("state") if isinstance(ctx, dict) else None
    if state is None:
        return
    try:
        inst = get_instance(ctx, handle)
    except Exception:
        inst = None
    prefixes = [normalize_handle(handle)]
    if inst is not None:
        primary = str(getattr(inst, "primary_target", "") or "").strip()
        if primary:
            prefixes.append(primary)
    layout_store.delete_layout_symbols(state, prefixes)



def _write_meta_for_instance(ctx, instance: LayoutInstance) -> None:
    layout_state.set_meta(ctx, instance.handle, "module", instance.MODULE)
    layout_state.set_meta(ctx, instance.handle, "title", instance.get_title())
    layout_state.set_meta(ctx, instance.handle, "prompt", instance.get_prompt())
    layout_state.set_meta(ctx, instance.handle, "status", "ok")
    layout_state.set_meta(ctx, instance.handle, "view_target", instance.view_target)
    layout_state.set_meta(ctx, instance.handle, "bound_module_name", instance.config.get("bound_module_name", ""))



def create_instance(ctx, module_name: str, handle: str, config: dict[str, Any] | None = None, start: bool = True):
    runtime = _runtime(ctx)
    clean_handle = normalize_handle(handle)
    config = dict(config or {})
    primary_target, view_target = _primary_target_for(module_name, clean_handle, config)
    instance = LayoutInstance(
        handle=clean_handle,
        MODULE=str(module_name or "").strip().lower(),
        parent_layout=str(config.get("parent_layout") or "").strip(),
        config=config,
        primary_target=primary_target,
        view_target=view_target,
        title=clean_handle,
        prompt=_module_prompt(module_name),
    )
    runtime["instances"][clean_handle] = instance
    if instance.MODULE == "q":
        defaults = {
            f"{primary_target}:ch": {},
            f"{primary_target}:response": "",
            f"{primary_target}:thinking_text": "",
            f"{primary_target}:prompt": "",
            f"{primary_target}:error": "",
        }
        for symbol, default_value in defaults.items():
            if layout_state.get_value(ctx, symbol, None) is None:
                layout_state.set_value(ctx, symbol, default_value)
    else:
        if layout_state.get_value(ctx, primary_target, None) is None:
            layout_state.set_value(ctx, primary_target, "")
    _write_meta_for_instance(ctx, instance)
    _persist_runtime(ctx)
    return instance



def _binding_meta_write(ctx, handle: str, route_name: str, modules: list[str], active_module: str) -> None:
    layout_state.set_meta(ctx, handle, "layout_name", _route_name(route_name))
    layout_state.set_meta(ctx, handle, "title", handle)
    layout_state.set_meta(ctx, handle, "status", "ok")
    layout_state.set_meta(ctx, handle, "view_target", f"{handle}:buffer")
    layout_state.set_meta(ctx, handle, "active_module", active_module)
    layout_state.set_value(ctx, f"{handle}:buffer", layout_state.get_value(ctx, f"{handle}:buffer", "") or "")
    layout_state.set_meta(ctx, handle, "modules", list(modules))



def create_layout_binding(ctx, handle: str, route_name: str, specs: list[dict[str, Any]], tree: dict[str, Any] | None = None):
    runtime = _runtime(ctx)
    binding_handle = normalize_handle(handle)
    binding = runtime["bindings"].get(binding_handle)
    if binding is None:
        binding = {
            "handle": binding_handle,
            "route_name": _route_name(route_name),
            "tree": tree,
            "specs": list(specs),
            "modules": [],
            "active_module": "",
        }
        runtime["bindings"][binding_handle] = binding
    else:
        binding["route_name"] = _route_name(route_name)
        binding["tree"] = tree
        binding["specs"] = list(specs)
        binding["modules"] = []
        binding["active_module"] = ""

    modules: list[str] = []
    cs_candidate = ""
    q_candidate = ""
    runtime["_persist_suspended"] = int(runtime.get("_persist_suspended") or 0) + 1
    try:
        for spec in specs:
            tag = str(spec.get("tag") or "").strip().lower()
            if tag in _IGNORE_BOUND_TAGS:
                continue
            child_handle = _instance_handle(binding_handle, tag, int(spec.get("ordinal") or 1))
            config = _config_for_spec(binding_handle, route_name, spec)
            config["parent_layout"] = binding_handle
            instance = create_instance(ctx, tag, child_handle, config, start=True)
            modules.append(instance.handle)
            if tag == "cs" and not cs_candidate:
                cs_candidate = instance.handle
            if tag == "q" and not q_candidate:
                q_candidate = instance.handle
    finally:
        runtime["_persist_suspended"] = max(0, int(runtime.get("_persist_suspended") or 0) - 1)

    input_module = q_candidate or cs_candidate or (modules[0] if modules else "")
    render_module = next((h for h in modules if ".monitor" in h.lower()), "") or input_module
    binding["modules"] = modules
    binding["active_module"] = render_module
    binding["input_module"] = input_module
    _binding_meta_write(ctx, binding_handle, route_name, modules, render_module)
    _persist_runtime(ctx)
    return modules



def _ensure_layout_binding_runtime(ctx, handle: str):
    runtime = _runtime(ctx)
    binding_handle = normalize_handle(handle)
    binding = runtime["bindings"].get(binding_handle)
    if binding is None:
        raise ValueError(f"layout not found: {binding_handle}")

    modules = []
    for spec in binding.get("specs") or []:
        tag = str(spec.get("tag") or "").strip().lower()
        if tag in _IGNORE_BOUND_TAGS:
            continue
        child_handle = _instance_handle(binding_handle, tag, int(spec.get("ordinal") or 1))
        if child_handle not in runtime["instances"]:
            config = _config_for_spec(binding_handle, binding.get("route_name") or binding_handle, spec)
            config["parent_layout"] = binding_handle
            create_instance(ctx, tag, child_handle, config, start=True)
        modules.append(child_handle)

    binding["modules"] = modules
    if binding.get("input_module") not in modules:
        binding["input_module"] = next((h for h in modules if ".q" in h.lower()), "") or next((h for h in modules if ".cs" in h.lower()), modules[0] if modules else "")
    if binding.get("active_module") not in modules:
        binding["active_module"] = next((h for h in modules if ".monitor" in h.lower()), "") or binding.get("input_module") or (modules[0] if modules else "")
    _binding_meta_write(ctx, binding_handle, binding.get("route_name") or binding_handle, modules, binding.get("active_module") or "")
    return modules



def _default_startup_layout_handle() -> str:
    return "|CS"



def bootstrap(ctx) -> None:
    runtime = _runtime(ctx)
    if runtime.get("bootstrapped"):
        _ensure_startup_layout(ctx)
        return
    runtime["bootstrapped"] = True
    _restore_runtime_from_store(ctx)
    _ensure_startup_layout(ctx)
    active = str(runtime.get("active_handle") or "").strip() or _default_startup_layout_handle()
    try:
        switch_active(ctx, active)
    except Exception:
        switch_active(ctx, _default_startup_layout_handle())



def _ensure_startup_layout(ctx) -> None:
    runtime = _runtime(ctx)
    if "|CS" not in runtime["bindings"]:
        tree = definitions.parse_layout_definition("cs")
        specs = definitions.flatten_module_specs(tree)
        create_layout_binding(ctx, "|CS", "cs", specs, tree=tree)
    _ensure_layout_binding_runtime(ctx, "|CS")



def has_layout_binding(ctx, handle: str) -> bool:
    return normalize_handle(handle) in _runtime(ctx)["bindings"]



def has_instance(ctx, handle: str) -> bool:
    return normalize_handle(handle) in _runtime(ctx)["instances"]



def get_instance(ctx, handle: str):
    runtime = _runtime(ctx)
    clean = normalize_handle(handle)
    inst = runtime["instances"].get(clean)
    if inst is not None:
        return inst
    if clean in runtime["bindings"]:
        binding = runtime["bindings"][clean]
        target = str(binding.get("input_module") or binding.get("active_module") or "")
        if target and target in runtime["instances"]:
            return runtime["instances"][target]
    raise ValueError(f"layout not found: {handle}")



def _focus_runtime(ctx) -> dict[str, Any]:
    runtime = _runtime(ctx)
    return runtime.setdefault("focus", {})



def get_focusable_module_handles(ctx, handle: str | None = None) -> list[str]:
    bootstrap(ctx)
    clean = normalize_handle(handle or get_active_handle(ctx))
    runtime = _runtime(ctx)
    if clean in runtime["bindings"]:
        modules = get_bound_layout_modules(ctx, clean)
    elif clean in runtime["instances"]:
        modules = [clean]
    else:
        return []

    focusable: list[str] = []
    for item in modules:
        try:
            inst = get_instance(ctx, item)
        except Exception:
            continue
        module = load_module(ctx, getattr(inst, "MODULE", ""))
        if bool(getattr(module, "FOCUSABLE", False)):
            focusable.append(inst.handle)
    return focusable



def get_focused_module_handle(ctx, handle: str | None = None) -> str:
    bootstrap(ctx)
    owner = normalize_handle(handle or get_active_handle(ctx))
    focus = _focus_runtime(ctx)
    current = str(focus.get(owner) or "")
    focusable = get_focusable_module_handles(ctx, owner)
    if current in focusable:
        return current
    if focusable:
        preferred = next((item for item in focusable if get_instance(ctx, item).MODULE == "cs"), focusable[0])
        focus[owner] = preferred
        return preferred
    if owner in _runtime(ctx)["instances"]:
        inst = get_instance(ctx, owner)
        module = load_module(ctx, getattr(inst, "MODULE", ""))
        if bool(getattr(module, "FOCUSABLE", False)):
            focus[owner] = owner
            return owner
    return ""



def set_focused_module_handle(ctx, module_handle: str) -> str:
    clean_module = normalize_handle(module_handle)
    owner = get_parent_layout_for_instance(ctx, clean_module) or clean_module
    _focus_runtime(ctx)[normalize_handle(owner)] = clean_module
    return clean_module



def cycle_focus(ctx, step: int = 1, handle: str | None = None) -> str:
    owner = normalize_handle(handle or get_active_handle(ctx))
    focusable = get_focusable_module_handles(ctx, owner)
    if not focusable:
        return ""
    current = get_focused_module_handle(ctx, owner)
    if current not in focusable:
        return set_focused_module_handle(ctx, focusable[0])
    pos = focusable.index(current)
    target = focusable[(pos + int(step)) % len(focusable)]
    return set_focused_module_handle(ctx, target)


def get_active_handle(ctx) -> str:
    return layout_state.get_active_handle(ctx, _default_startup_layout_handle())



def set_active_handle(ctx, handle: str) -> str:
    return layout_state.set_active_handle(ctx, normalize_handle(handle))



def switch_active(ctx, handle: str) -> str:
    clean = normalize_handle(handle)
    runtime = _runtime(ctx)
    if clean not in runtime["bindings"] and clean not in runtime["instances"]:
        raise ValueError(f"layout not found: {handle}")
    set_active_handle(ctx, clean)
    get_focused_module_handle(ctx, clean)
    _persist_runtime(ctx)
    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    if parser is not None:
        force_render(parser)
    return clean



def get_active_instance(ctx):
    return get_instance(ctx, get_active_handle(ctx))



def get_bound_layout_modules(ctx, handle: str) -> list[str]:
    binding = _runtime(ctx)["bindings"].get(normalize_handle(handle))
    if binding is None:
        raise ValueError("layout not found")
    _ensure_layout_binding_runtime(ctx, handle)
    return list(binding.get("modules") or [])



def get_bound_layout_active_module(ctx, handle: str) -> str:
    binding = _runtime(ctx)["bindings"].get(normalize_handle(handle))
    if binding is None:
        return ""
    _ensure_layout_binding_runtime(ctx, handle)
    return str(binding.get("active_module") or "")



def get_parent_layout_for_instance(ctx, handle: str) -> str:
    inst = _runtime(ctx)["instances"].get(normalize_handle(handle))
    return str(inst.parent_layout or "") if inst is not None else ""



def list_instances(ctx) -> list[str]:
    runtime = _runtime(ctx)
    return sorted(runtime["instances"].keys(), key=lambda item: item[1:])



def get_layout_buffer_target(ctx, handle: str) -> str:
    clean = normalize_handle(handle)
    parent = get_parent_layout_for_instance(ctx, clean)
    if parent:
        return f"{parent}:buffer"
    if has_layout_binding(ctx, clean):
        return f"{clean}:buffer"
    return f"{clean}:buffer"



def get_primary_target(ctx, handle: str) -> str:
    clean = normalize_handle(handle)
    if has_layout_binding(ctx, clean):
        inst = get_instance(ctx, clean)
        if getattr(inst, "MODULE", "") == "q":
            return inst.primary_target
        return f"{clean}:buffer"
    return get_instance(ctx, clean).primary_target






def _append_command_to_buffer(ctx, line: str, *, source_handle: str | None = None) -> None:
    clean = str(line or '').rstrip("\r\n")
    if not clean.strip():
        return
    state = ctx.get('state') if isinstance(ctx, dict) else None
    if state is None:
        return
    handle = normalize_handle(source_handle or get_active_handle(ctx))
    target = get_layout_buffer_target(ctx, handle)
    append_numeric_value(
        state,
        target,
        f"> {clean}",
        writer="layout:input",
        op="layout_command_echo",
    )


def _parser_parse_with_layout(ctx, line: str, *, caller_handle: str | None = None, buffer_suppress: bool = False, layout_self_route: bool = False):
    parser = ctx.get("parser")
    if parser is None:
        raise ValueError("parser missing")

    lock = getattr(parser, "_parse_lock", None)
    if lock is None:
        previous = get_runtime(parser, "layout_caller_handle", "")
        previous_suppress = get_runtime(parser, "buffer_suppress", False)
        previous_self_route = get_runtime(parser, "layout_self_route", False)
        set_runtime(parser, "layout_caller_handle", normalize_handle(caller_handle or get_active_handle(ctx)))
        set_runtime(parser, "buffer_suppress", bool(buffer_suppress))
        set_runtime(parser, "layout_self_route", bool(layout_self_route))
        try:
            return parser.parse(line)
        finally:
            set_runtime(parser, "layout_caller_handle", previous)
            set_runtime(parser, "buffer_suppress", previous_suppress)
            set_runtime(parser, "layout_self_route", previous_self_route)

    with lock:
        previous = get_runtime(parser, "layout_caller_handle", "")
        previous_suppress = get_runtime(parser, "buffer_suppress", False)
        previous_self_route = get_runtime(parser, "layout_self_route", False)
        set_runtime(parser, "layout_caller_handle", normalize_handle(caller_handle or get_active_handle(ctx)))
        set_runtime(parser, "buffer_suppress", bool(buffer_suppress))
        set_runtime(parser, "layout_self_route", bool(layout_self_route))
        try:
            return parser.parse(line)
        finally:
            set_runtime(parser, "layout_caller_handle", previous)
            set_runtime(parser, "buffer_suppress", previous_suppress)
            set_runtime(parser, "layout_self_route", previous_self_route)



def _line_routes_to_parser(ctx, line: str) -> bool:
    clean = str(line or "").strip()
    if not clean:
        return False
    if clean.startswith("/") or clean.startswith("|"):
        return True
    if is_symbol_line(clean):
        active = str(_active_handle_for_store(ctx) or _default_startup_layout_handle())
        try:
            inst = get_instance(ctx, active)
        except Exception:
            inst = None
        if inst is not None and getattr(inst, "MODULE", "") == "q" and "=" not in clean:
            return False
        return True
    parser = ctx.get("parser")
    if parser is None:
        return False
    token = clean.split()[0]
    if token == "/":
        return True
    return token in getattr(parser, "registry", {})



def _dispatch_q_self_route_async(ctx, line: str, *, caller_handle: str | None = None) -> None:
    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    if parser is None:
        return

    def _run() -> None:
        try:
            _parser_parse_with_layout(ctx, line, caller_handle=caller_handle, buffer_suppress=True, layout_self_route=True)
        finally:
            force_render(parser)

    thread = threading.Thread(target=_run, name="layout-q-self-route", daemon=True)
    thread.start()



def dispatch_line(ctx, line: str, *, source_handle: str | None = None, target_handle: str | None = None) -> dict[str, str]:
    bootstrap(ctx)
    clean = str(line or "").rstrip("\r\n")
    if not clean.strip():
        return {"mode": "none"}

    if is_ui_instance_switch_line(clean):
        target = ensure_instance(ctx, clean)
        handle = str(getattr(target, "handle", target) or clean).strip() or clean
        switch_active(ctx, handle)
        return {"mode": "switch"}

    caller_handle = normalize_handle(source_handle or get_active_handle(ctx))
    effective_handle = normalize_handle(target_handle or caller_handle)

    if _line_routes_to_parser(ctx, clean):
        _append_command_to_buffer(ctx, clean, source_handle=caller_handle)
        _parser_parse_with_layout(ctx, clean, caller_handle=effective_handle)
        return {"mode": "parser"}

    inst = get_instance(ctx, effective_handle)
    if inst.MODULE == "q":
        profile = str(inst.config.get("profile") or "default").strip() or "default"
        cmd = "q" if profile == "default" else f"q.{profile}"
        _dispatch_q_self_route_async(ctx, f"{cmd} {clean}", caller_handle=effective_handle)
        return {"mode": "self"}

    return {"mode": "none"}



def ensure_instance(ctx, target: str):
    bootstrap(ctx)
    runtime = _runtime(ctx)
    text = str(target or "").strip()
    if not text:
        raise ValueError("layout target cannot be empty")

    if text.startswith("|"):
        clean = normalize_handle(text)
        if clean in runtime["bindings"]:
            _ensure_layout_binding_runtime(ctx, clean)
            return clean
        if clean in runtime["instances"]:
            return runtime["instances"][clean]
        raise ValueError(f"layout not found: {text}")

    if not text.startswith("/"):
        raise ValueError("layout route must start with /")

    route = _route_name(text)
    base = route.split(".", 1)[0].lower()

    try:
        tree = definitions.parse_layout_definition(base)
        handle = _layout_handle_from_route(text)
        if handle not in runtime["bindings"]:
            specs = definitions.flatten_module_specs(tree)
            create_layout_binding(ctx, handle, base, specs, tree=tree)
        _ensure_layout_binding_runtime(ctx, handle)
        return handle
    except Exception:
        pass

    module_name = base
    handle = _layout_handle_from_route(text)
    if handle not in runtime["instances"]:
        create_instance(ctx, module_name, handle, {}, start=True)
    return runtime["instances"][handle]



def save_instance(ctx, handle: str) -> None:
    runtime = _runtime(ctx)
    clean = normalize_handle(handle)
    runtime.setdefault("saved_instances", {})[clean] = True



def remove_instance(ctx, target: str) -> bool:
    runtime = _runtime(ctx)
    clean = normalize_handle(target)
    state = ctx.get("state") if isinstance(ctx, dict) else None
    if clean in runtime["bindings"]:
        binding = runtime["bindings"].pop(clean)
        child_instances = {}
        for child in list(binding.get("modules") or []):
            child_instances[child] = runtime["instances"].pop(child, None)
        if runtime.get("active_handle") == clean:
            runtime["active_handle"] = _default_startup_layout_handle()
        if state is not None:
            prefixes = [clean]
            for child, inst in child_instances.items():
                prefixes.append(child)
                primary = str(getattr(inst, "primary_target", "") or "").strip() if inst is not None else ""
                if primary:
                    prefixes.append(primary)
            layout_store.delete_layout_symbols(state, prefixes)
        _persist_runtime(ctx)
        return True
    if clean in runtime["instances"]:
        inst = runtime["instances"].pop(clean)
        parent = inst.parent_layout
        if parent and parent in runtime["bindings"]:
            binding = runtime["bindings"][parent]
            binding["modules"] = [item for item in binding.get("modules") or [] if item != clean]
            if binding.get("active_module") == clean:
                binding["active_module"] = binding["modules"][0] if binding["modules"] else ""
        if runtime.get("active_handle") == clean:
            runtime["active_handle"] = parent or _default_startup_layout_handle()
        if state is not None:
            prefixes = [clean]
            primary = str(getattr(inst, "primary_target", "") or "").strip()
            if primary:
                prefixes.append(primary)
            layout_store.delete_layout_symbols(state, prefixes)
        _persist_runtime(ctx)
        return True
    return False




def clear_layout_modules(ctx, handle: str | None = None) -> list[str]:
    bootstrap(ctx)
    owner = normalize_handle(handle or get_active_handle(ctx))
    runtime = _runtime(ctx)

    targets: list[str] = []
    if owner in runtime.get("bindings", {}):
        targets.extend(get_bound_layout_modules(ctx, owner))
    elif owner in runtime.get("instances", {}):
        targets.append(owner)
    else:
        raise ValueError(f"layout not found: {owner}")

    cleared: list[str] = []
    for module_handle in targets:
        try:
            inst = get_instance(ctx, module_handle)
        except Exception:
            continue
        try:
            module = load_module(ctx, getattr(inst, "MODULE", ""))
        except Exception:
            continue
        clear_fn = getattr(module, "clear", None)
        if callable(clear_fn):
            clear_fn(ctx, module_handle, inst)
            cleared.append(module_handle)

    parser = ctx.get("parser") if isinstance(ctx, dict) else None
    if parser is not None:
        force_render(parser)
    return cleared


def reload_layout(ctx) -> list[str]:
    runtime = _runtime(ctx)
    active = runtime.get("active_handle") or _default_startup_layout_handle()
    runtime["bindings"] = {}
    runtime["instances"] = {}
    runtime["bootstrapped"] = False
    bootstrap(ctx)
    if active:
        try:
            ensure_instance(ctx, active)
            switch_active(ctx, active)
        except Exception:
            switch_active(ctx, _default_startup_layout_handle())
    return sorted([binding["route_name"] for binding in runtime["bindings"].values()])
