from __future__ import annotations

from typing import Any

MODULE = "q"
DEFAULT_PROMPT = "cs> "
FOCUSABLE = True


def _runtime_root(handle: str, config: dict[str, Any] | None = None) -> str:
    cfg = dict(config or {})
    explicit = str(cfg.get("runtime_root") or "").strip()
    if explicit.startswith("|"):
        return explicit

    parent = str(cfg.get("parent_layout") or "").strip()
    module_id = str(cfg.get("module_id") or "q").strip() or "q"
    if parent.startswith("|"):
        return f"{parent}:{module_id}"

    clean = str(handle or "").strip()
    if clean.startswith("|"):
        return f"{clean}:{module_id}"
    return f"|Q:{module_id}"


def get_targets(handle: str, config: dict[str, Any] | None = None) -> tuple[str, str]:
    base = _runtime_root(handle, config)
    return base, f"{base}:ch"


def measure(ctx, binding_handle: str, spec: dict[str, Any], width: int, instance) -> dict[str, Any]:
    return {"min_h": 1, "scalable_y": True}


def build_payload(ctx, binding_handle: str, spec: dict[str, Any], rect: dict[str, int], instance):
    from system.layout.module_api import content_rect, finalize_payload, module_flow, render_q_visible_lines
    attrs = dict(spec.get("attrs") or {})
    flow = module_flow(MODULE, attrs)
    inner_rect = content_rect(attrs, rect)
    lines = render_q_visible_lines(ctx, instance, int(inner_rect.get("w", 1) or 1), int(inner_rect.get("h", 1) or 1), flow)
    return finalize_payload(ctx, instance.handle, lines or [""], attrs, MODULE, rect)


def handle_key(ctx, module_handle: str, key: int) -> bool:
    import curses

    from system.layout import input as layout_input

    ui = layout_input.get_module_ui(ctx, module_handle)
    if key == curses.KEY_UP:
        ui["follow"] = False
        ui["scroll"] = int(ui.get("scroll", 0) or 0) + 1
        layout_input._mark_dirty(ctx)
        return True
    if key == curses.KEY_DOWN:
        current = max(0, int(ui.get("scroll", 0) or 0) - 1)
        ui["scroll"] = current
        if current == 0:
            ui["follow"] = True
        layout_input._mark_dirty(ctx)
        return True
    if key == curses.KEY_HOME:
        ui["follow"] = False
        ui["scroll"] = 10 ** 9
        layout_input._mark_dirty(ctx)
        return True
    if key == curses.KEY_END:
        ui["follow"] = True
        ui["scroll"] = 0
        layout_input._mark_dirty(ctx)
        return True
    return False


def clear(ctx, module_handle: str, instance):
    from system.layout import input as layout_input
    from system.layout import state as layout_state

    base = str(getattr(instance, "primary_target", "") or "").strip()
    if not base:
        return False

    layout_state.set_value(ctx, f"{base}:ch", {})
    layout_state.set_value(ctx, f"{base}:cue", "")
    layout_state.set_value(ctx, f"{base}:response", "")
    layout_state.set_value(ctx, f"{base}:thinking_text", "")
    layout_state.set_value(ctx, f"{base}:prompt", "")
    layout_state.set_value(ctx, f"{base}:error", "")
    ui = layout_input.get_module_ui(ctx, module_handle)
    ui["follow"] = True
    ui["scroll"] = 0
    return True
