from __future__ import annotations

from typing import Any, Callable

from .errors import QCallError
from .live import chunk_q_live, done_q_live, fail_q_live, open_q_live
from .profile import get_profile, resolve_profile_name, resolve_think_value, set_active_profile
from .prompt import expand_prompt_symbols
from .providers import decode_qc_output, profile_has_stream, extract_chat, strip_inline_think_markup
from .sampler import ensure_q_sampler_state
from .state import (
    merge_thinking_stream,
    append_response_stream,
    write_text_symbol,
    load_chat,
    load_role,
    open_chat_entry,
    write_chat_entry,
)
from .symbols import q_state_prefix_for_runtime
from .transport import call_profile, stream_profile
from .common import read_state_value
from .qcue import qcue_complete, qcue_wake


def _coerce_toggle(value: Any, default: bool = True) -> bool:
    if value is None:
        return bool(default)
    clean = str(value).strip().lower()
    if not clean:
        return bool(default)
    if clean in {'0', 'false', 'no', 'off'}:
        return False
    if clean in {'1', 'true', 'yes', 'on'}:
        return True
    return bool(default)


def _resolve_show_thinking(state, q_root: str) -> bool:
    clean = str(q_root or '').strip()
    if not clean:
        return True
    raw = read_state_value(state, f'{clean}:role:view_thinking', True)
    return _coerce_toggle(raw, True)


def _resolve_stream_enabled(state, q_root: str, profile: dict) -> bool:
    clean = str(q_root or '').strip()
    if clean:
        raw = read_state_value(state, f'{clean}:role:stream', None)
        if raw not in (None, ''):
            return _coerce_toggle(raw, True)
    return bool(profile_has_stream(profile))


def _symbols_for_root(q_root: str) -> dict[str, str]:
    root = str(q_root or '').strip()
    if not root:
        return {
            'chat_symbol': '',
            'role_symbol': '',
            'system_prompt_symbol': '',
            'response_symbol': '',
            'thinking_symbol': '',
            'status_symbol': '',
        }
    role_inline = root.startswith('|') and ':' in root
    return {
        'chat_symbol': f'{root}:ch',
        'role_symbol': f'{root}:role:name' if role_inline else f'{root}:role',
        'system_prompt_symbol': f'{root}:role:system_prompt' if role_inline else f'{root}:system_prompt',
        'response_symbol': f'{root}:response',
        'thinking_symbol': f'{root}:thinking_text',
        'status_symbol': f'{root}:status',
    }


def prepare_q_session(parser, command_token: str, prompt: str, *, q_root_override: str | None = None) -> dict:
    profile_name = resolve_profile_name(parser, command_token, 'q')
    profile = get_profile(parser, profile_name)
    ensure_q_sampler_state(parser.state, profile_name)
    set_active_profile(parser, profile_name)

    q_state_root = str(q_root_override or q_state_prefix_for_runtime(parser, profile_name) or '').strip()
    symbols = _symbols_for_root(q_state_root)
    chat_symbol = symbols['chat_symbol']
    system_prompt_symbol = symbols['system_prompt_symbol']
    chat = load_chat(parser.state, chat_symbol) if chat_symbol else {}
    role_source = load_role(parser.state, system_prompt_symbol) if system_prompt_symbol else ''
    role = expand_prompt_symbols(parser, role_source, mode='system_recursive', strict=True) if role_source else ''
    expanded_prompt = expand_prompt_symbols(parser, prompt, mode='normal_inline', strict=False)
    think_value = resolve_think_value(profile, parser.state, profile_name)
    show_thinking = _resolve_show_thinking(parser.state, q_state_root)
    stream_enabled = _resolve_stream_enabled(parser.state, q_state_root, profile)

    return {
        'profile_name': profile_name,
        'profile': profile,
        'state': parser.state,
        'q_state_root': q_state_root,
        'chat_symbol': chat_symbol,
        'role_symbol': symbols['role_symbol'],
        'system_prompt_symbol': system_prompt_symbol,
        'response_symbol': symbols['response_symbol'],
        'thinking_symbol': symbols['thinking_symbol'],
        'status_symbol': symbols['status_symbol'],
        'prompt': prompt,
        'expanded_prompt': expanded_prompt,
        'role': role,
        'chat': chat,
        'stream_enabled': 1 if stream_enabled else 0,
        'think_value': think_value,
        'show_thinking': show_thinking,
    }


def run_nonstream_session(session: dict) -> str:
    payload = call_profile(
        session['profile'],
        session['expanded_prompt'],
        role=session['role'],
        chat=session['chat'],
        state=session.get('state'),
        profile_name=session.get('profile_name', 'default'),
        think_value=session.get('think_value'),
        q_state_root=session.get('q_state_root'),
    )
    return strip_inline_think_markup(extract_chat(payload, session['profile'].get('chat_message_tag')))


def _complete_queue_bookkeeping(parser, alias: str, q_root: str, task_id: str, status: str, *, error: str = '') -> dict[str, Any] | None:
    clean_alias = str(alias or '').strip()
    clean_task_id = str(task_id or '').strip()
    if not clean_alias or not clean_task_id:
        return None
    try:
        finished = qcue_complete(parser, clean_alias, str(q_root or ''), clean_task_id, status, error=error)
    except Exception as exc:
        clean_root = str(q_root or '').strip()
        message = f'qcue bookkeeping error: {exc}'
        if clean_root:
            try:
                write_text_symbol(parser.state, f'{clean_root}:error', message, 'qcue_bookkeeping_error')
                write_text_symbol(parser.state, f'{clean_root}:status', 'error', 'qcue_bookkeeping_error_status')
            except Exception:
                pass
        raise
    qcue_wake(parser)
    return finished


def q_chat(
    parser,
    command_token: str,
    prompt: str,
    *,
    q_root_override: str | None = None,
    queue_meta: dict[str, Any] | None = None,
    on_chunk: Callable[[str, str, str, str], None] | None = None,
    on_done: Callable[[str, str, str], None] | None = None,
) -> dict:
    session = prepare_q_session(parser, command_token, prompt, q_root_override=q_root_override)
    profile_name = session['profile_name']
    chat_symbol = session['chat_symbol']
    response_symbol = session['response_symbol']
    thinking_symbol = session['thinking_symbol']
    status_symbol = session['status_symbol']
    q_state_root = session['q_state_root']
    show_thinking = bool(session.get('show_thinking', True))
    queue_meta = dict(queue_meta or {})
    queue_alias = str(queue_meta.get('alias') or '').strip()
    queue_task_id = str(queue_meta.get('task_id') or '').strip()

    # Queue truth lives in #SYSTEM:Qcue. Root-local fields are active-render cache only.
    if not queue_task_id:
        if q_state_root:
            write_text_symbol(parser.state, f'{q_state_root}:prompt', prompt, 'prompt_accept')
            write_text_symbol(parser.state, f'{q_state_root}:error', '', 'error_reset')
        write_text_symbol(parser.state, response_symbol, '', 'response_reset')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_reset')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'running', 'status_running')

    key = open_chat_entry(parser.state, chat_symbol, prompt)
    open_q_live(
        parser,
        profile=profile_name,
        chat_symbol=chat_symbol,
        response_symbol=response_symbol,
        thinking_symbol=thinking_symbol,
        key=key,
        prompt=prompt,
        response='',
        thinking='',
    )
    try:
        from system.cs.runtime_ctx import force_render
        force_render(parser)
    except Exception:
        pass

    if not session['stream_enabled']:
        try:
            final_text = run_nonstream_session(session)
        except Exception as exc:
            if status_symbol:
                write_text_symbol(parser.state, status_symbol, 'error', 'status_error')
            if q_state_root:
                write_text_symbol(parser.state, f'{q_state_root}:error', str(exc or ''), 'q_error')
            bookkeeping_error = None
            if queue_alias and queue_task_id:
                try:
                    _complete_queue_bookkeeping(parser, queue_alias, q_state_root, queue_task_id, 'error', error=str(exc or ''))
                except Exception as bk_exc:
                    bookkeeping_error = bk_exc
            fail_q_live(
                parser,
                str(exc or ''),
                profile=profile_name,
                chat_symbol=chat_symbol,
                response_symbol=response_symbol,
                thinking_symbol=thinking_symbol,
                key=key,
                prompt=prompt,
                response='',
                thinking='',
            )
            if bookkeeping_error is not None:
                raise bookkeeping_error from exc
            raise
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'done', 'status_done')
        done_q_live(
            parser,
            profile=profile_name,
            chat_symbol=chat_symbol,
            response_symbol=response_symbol,
            thinking_symbol=thinking_symbol,
            key=key,
            prompt=prompt,
            response=final_text,
            thinking='',
        )
        if queue_alias and queue_task_id:
            _complete_queue_bookkeeping(parser, queue_alias, q_state_root, queue_task_id, 'done')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {
            'profile': profile_name,
            'chat_symbol': chat_symbol,
            'response_symbol': response_symbol,
            'thinking_symbol': thinking_symbol,
            'chat_key': key,
            'message': final_text,
        }

    final_text = ''
    final_thinking = ''
    last_written_response = ''
    try:
        for event in stream_profile(
            session['profile'],
            session['expanded_prompt'],
            role=session['role'],
            chat=session['chat'],
            state=session.get('state'),
            profile_name=profile_name,
            think_value=session.get('think_value'),
            q_state_root=q_state_root,
        ):
            raw_thinking_chunk = strip_inline_think_markup(event.get('thinking') or '')
            content_chunk = strip_inline_think_markup(event.get('content') or '')
            event_done = 1 if int(event.get('done') or 0) == 1 else 0

            if raw_thinking_chunk:
                final_thinking = merge_thinking_stream(final_thinking, raw_thinking_chunk)
            if content_chunk:
                final_text = append_response_stream(final_text, content_chunk)

            visible_response = strip_inline_think_markup(final_text)
            visible_thinking = final_thinking if show_thinking else ''

            write_text_symbol(parser.state, response_symbol, visible_response, 'response_partial')
            write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
            if visible_response != last_written_response:
                write_chat_entry(parser.state, chat_symbol, key, prompt, visible_response, done=0)
                last_written_response = visible_response
            chunk_q_live(
                parser,
                profile=profile_name,
                chat_symbol=chat_symbol,
                response_symbol=response_symbol,
                thinking_symbol=thinking_symbol,
                key=key,
                prompt=prompt,
                response=visible_response,
                thinking=visible_thinking,
            )
            if callable(on_chunk) and (raw_thinking_chunk or content_chunk):
                on_chunk(content_chunk or raw_thinking_chunk, visible_response, chat_symbol, key)
            if event_done:
                break

        final_text = strip_inline_think_markup(final_text)
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'done', 'status_done')
        done_q_live(
            parser,
            profile=profile_name,
            chat_symbol=chat_symbol,
            response_symbol=response_symbol,
            thinking_symbol=thinking_symbol,
            key=key,
            prompt=prompt,
            response=final_text,
            thinking='',
        )
        if queue_alias and queue_task_id:
            _complete_queue_bookkeeping(parser, queue_alias, q_state_root, queue_task_id, 'done')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
    except Exception as exc:
        if q_state_root:
            write_text_symbol(parser.state, f'{q_state_root}:error', str(exc or ''), 'q_error')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'error', 'status_error')
        bookkeeping_error = None
        if queue_alias and queue_task_id:
            try:
                _complete_queue_bookkeeping(parser, queue_alias, q_state_root, queue_task_id, 'error', error=str(exc or ''))
            except Exception as bk_exc:
                bookkeeping_error = bk_exc
        fail_q_live(
            parser,
            str(exc or ''),
            profile=profile_name,
            chat_symbol=chat_symbol,
            response_symbol=response_symbol,
            thinking_symbol=thinking_symbol,
            key=key,
            prompt=prompt,
            response=final_text,
            thinking=final_thinking if show_thinking else '',
        )
        if bookkeeping_error is not None:
            raise bookkeeping_error from exc
        raise

    return {
        'profile': profile_name,
        'chat_symbol': chat_symbol,
        'response_symbol': response_symbol,
        'thinking_symbol': thinking_symbol,
        'chat_key': key,
        'message': final_text,
    }


def qc_raw(parser, command_token: str, *args: Any, q_root_override: str | None = None) -> dict:
    flat_args: list[Any] = []
    for item in args:
        if isinstance(item, (list, tuple)):
            flat_args.extend(item)
        else:
            flat_args.append(item)
    prompt = ' '.join(str(x) for x in flat_args).strip()
    if not prompt:
        raise QCallError('qc requires prompt')

    profile_name = resolve_profile_name(parser, command_token, 'qc')
    profile = get_profile(parser, profile_name)
    ensure_q_sampler_state(parser.state, profile_name)
    set_active_profile(parser, profile_name)

    expanded_prompt = expand_prompt_symbols(parser, prompt, mode='normal_inline', strict=False)
    payload = call_profile(
        profile,
        expanded_prompt,
        role='',
        chat={},
        state=parser.state,
        profile_name=profile_name,
        think_value=resolve_think_value(profile, parser.state, profile_name),
        q_state_root=q_root_override or q_state_prefix_for_runtime(parser, profile_name),
    )
    message = strip_inline_think_markup(extract_chat(payload, profile.get('chat_message_tag')))
    decoded = decode_qc_output(payload, profile.get('chat_message_tag'))
    return {'profile': profile_name, 'message': message, 'decoded': decoded}


# compatibility alias for older callers
qc_call = qc_raw

__all__ = ['prepare_q_session', 'run_nonstream_session', 'q_chat', 'qc_raw', 'qc_call']
