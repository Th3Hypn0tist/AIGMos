from __future__ import annotations

from typing import Any, Callable

from .errors import QCallError
from .live import chunk_q_live, done_q_live, fail_q_live, open_q_live
from .profile import get_profile, resolve_profile_name, resolve_think_value, set_active_profile
from .prompt import expand_prompt_symbols
from .providers import decode_qc_output, profile_has_stream, extract_chat, strip_inline_think_markup
from .sampler import ensure_q_sampler_state
from .state import merge_thinking_stream, append_response_stream, write_text_symbol, load_chat, load_role, open_chat_entry, save_chat, write_chat_entry
from .symbols import q_state_prefix_for_runtime
from .transport import call_profile, stream_profile
from .common import think_is_enabled


def _coerce_toggle(value: Any, default: bool = True) -> bool:
    clean = str(value or '').strip().lower()
    if not clean:
        return bool(default)
    if clean in {'0', 'false', 'no', 'off'}:
        return False
    if clean in {'1', 'true', 'yes', 'on'}:
        return True
    return bool(default)


def _resolve_show_thinking(state, q_root: str) -> bool:
    from .common import read_state_value

    clean = str(q_root or '').strip()
    if not clean:
        return True
    raw = read_state_value(state, f'{clean}:role:view_thinking', True)
    return _coerce_toggle(raw, True)


def _symbols_for_root(q_root: str) -> dict[str, str]:
    root = str(q_root or '').strip()
    if not root:
        return {
            'chat_symbol': '',
            'role_symbol': '',
            'system_prompt_symbol': '',
            'response_symbol': '',
            'thinking_symbol': '',
            'status_symbol': '',
        }
    role_inline = root.startswith('|') and ':' in root
    return {
        'chat_symbol': f'{root}:ch',
        'role_symbol': f'{root}:role:name' if role_inline else f'{root}:role',
        'system_prompt_symbol': f'{root}:role:system_prompt' if role_inline else f'{root}:system_prompt',
        'response_symbol': f'{root}:response',
        'thinking_symbol': f'{root}:thinking_text',
        'status_symbol': f'{root}:status',
    }


def prepare_q_session(parser, command_token: str, prompt: str, *, q_root_override: str | None = None) -> dict:
    profile_name = resolve_profile_name(parser, command_token, 'q')
    profile = get_profile(parser, profile_name)
    ensure_q_sampler_state(parser.state, profile_name)
    set_active_profile(parser, profile_name)

    q_state_root = str(q_root_override or q_state_prefix_for_runtime(parser, profile_name) or '').strip()
    symbols = _symbols_for_root(q_state_root)
    chat_symbol = symbols['chat_symbol']
    role_symbol = symbols['role_symbol']
    system_prompt_symbol = symbols['system_prompt_symbol']
    chat = load_chat(parser.state, chat_symbol) if chat_symbol else {}
    role_source = load_role(parser.state, system_prompt_symbol) if system_prompt_symbol else ''
    role = expand_prompt_symbols(parser, role_source) if role_source else ''
    expanded_prompt = expand_prompt_symbols(parser, prompt)
    think_value = resolve_think_value(profile, parser.state, profile_name)
    show_thinking = _resolve_show_thinking(parser.state, q_state_root)

    return {
        'profile_name': profile_name,
        'profile': profile,
        'state': parser.state,
        'q_state_root': q_state_root,
        'chat_symbol': chat_symbol,
        'role_symbol': role_symbol,
        'system_prompt_symbol': system_prompt_symbol,
        'response_symbol': symbols['response_symbol'],
        'thinking_symbol': symbols['thinking_symbol'],
        'status_symbol': symbols['status_symbol'],
        'prompt': prompt,
        'expanded_prompt': expanded_prompt,
        'role': role,
        'chat': chat,
        'stream_enabled': 1 if profile_has_stream(profile) else 0,
        'think_value': think_value,
        'show_thinking': show_thinking,
    }


def run_nonstream_session(session: dict) -> str:
    payload = call_profile(
        session['profile'],
        session['expanded_prompt'],
        role=session['role'],
        chat=session['chat'],
        state=session.get('state'),
        profile_name=session.get('profile_name', 'default'),
        think_value=session.get('think_value'),
    )
    return strip_inline_think_markup(extract_chat(payload, session['profile'].get('chat_message_tag')))


def q_chat(parser, command_token: str, prompt: str, *, q_root_override: str | None = None, on_chunk: Callable[[str, str, str, str], None] | None = None, on_done: Callable[[str, str, str], None] | None = None) -> dict:
    session = prepare_q_session(parser, command_token, prompt, q_root_override=q_root_override)
    profile_name = session['profile_name']
    chat_symbol = session['chat_symbol']
    response_symbol = session['response_symbol']
    thinking_symbol = session['thinking_symbol']
    status_symbol = session['status_symbol']
    think_value = session.get('think_value')
    show_thinking = bool(session.get('show_thinking', True))

    write_text_symbol(parser.state, response_symbol, '', 'response_reset')
    write_text_symbol(parser.state, thinking_symbol, '', 'thinking_reset')
    if status_symbol:
        write_text_symbol(parser.state, status_symbol, 'waiting', 'status_waiting')
    write_text_symbol(parser.state, f"{session['q_state_root']}:prompt", prompt, 'prompt_accept')

    if not session['stream_enabled']:
        key = open_chat_entry(parser.state, chat_symbol, prompt)
        open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response='', thinking='')
        try:
            final_text = run_nonstream_session(session)
        except Exception as exc:
            if status_symbol:
                write_text_symbol(parser.state, status_symbol, 'error', 'status_error')
            write_text_symbol(parser.state, f"{session['q_state_root']}:error", str(str(exc) or ''), 'q_error')
            fail_q_live(parser, str(str(exc) or ''), profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response='', thinking='')
            raise
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'done', 'status_done')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}

    key = open_chat_entry(parser.state, chat_symbol, prompt)
    final_text = ''
    final_thinking = ''
    last_written_response = ''

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response='', thinking='')

    try:
        for event in stream_profile(session['profile'], session['expanded_prompt'], role=session['role'], chat=session['chat'], state=session.get('state'), profile_name=session.get('profile_name', 'default'), think_value=session.get('think_value')):
            raw_thinking_chunk = strip_inline_think_markup(event.get('thinking') or '')
            content_chunk = strip_inline_think_markup(event.get('content') or '')
            event_done = 1 if int(event.get('done') or 0) == 1 else 0

            if raw_thinking_chunk:
                final_thinking = merge_thinking_stream(final_thinking, raw_thinking_chunk)
            if content_chunk:
                final_text = append_response_stream(final_text, content_chunk)

            visible_response = strip_inline_think_markup(final_text)
            visible_thinking = final_thinking if show_thinking and not visible_response and final_thinking else ''

            write_text_symbol(parser.state, response_symbol, visible_response, 'response_partial')
            write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
            if visible_response != last_written_response:
                write_chat_entry(parser.state, chat_symbol, key, prompt, visible_response, done=0)
                last_written_response = visible_response
            chunk_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=visible_response, thinking=visible_thinking)

            if callable(on_chunk):
                on_chunk(str(content_chunk or ''), visible_response, chat_symbol, key)
            if event_done:
                break

        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'done', 'status_done')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}

    except Exception as exc:
        write_text_symbol(parser.state, f"{session['q_state_root']}:error", str(str(exc) or ''), 'q_error')
        if status_symbol:
            write_text_symbol(parser.state, status_symbol, 'error', 'status_error')
        fail_q_live(parser, str(str(exc) or ''), profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')
        raise


def qc_call(parser, command_token: str, prompt: str, output_target: str) -> dict:
    session = prepare_q_session(parser, command_token, prompt)
    profile_name = session['profile_name']
    chat_symbol = session['chat_symbol']
    message = run_nonstream_session(session)
    decoded = decode_qc_output(message)
    return {'profile': profile_name, 'chat_symbol': chat_symbol, 'output_target': output_target, 'message': message, 'decoded': decoded}
