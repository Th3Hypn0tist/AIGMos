from __future__ import annotations

import threading
from collections import deque
from typing import Any

from system.cs.command_args import parse_command_tail_raw
from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_runtime, runtime_map, set_runtime
from system.lib.q.errors import QCallError
from system.lib.q.session import q_chat
from system.lib.q.state import write_text_symbol
from system.lib.q.symbols import q_state_prefix_for_runtime

command = "q"
help_short = 'q[.profile] <prompt...>'
help_full = """stateful chat command

rules:
- dispatches chat to q runtime asynchronously
- does not return successful assistant output to command buffer
- writes prompt/status into q runtime immediately
- one active slot per q runtime root; queued FIFO per profile alias

examples:
  q hello
  q $prompt
  q.coder explain #code:main
"""


def _q_cue(parser) -> dict[str, Any]:
    rt = runtime_map(parser)
    cue = rt.get('q_cue')
    if isinstance(cue, dict):
        return cue
    cue = {
        'lock': threading.RLock(),
        'wake': threading.Event(),
        'queues': {},      # alias -> deque[task]
        'active': {},      # q_root -> task_id
        'seq': 0,
        'started': False,
    }
    rt['q_cue'] = cue
    return cue


def _task_id(cue: dict[str, Any]) -> str:
    cue['seq'] = int(cue.get('seq') or 0) + 1
    return str(cue['seq'])


def _set_prompt_status(parser, q_root: str, prompt: str, status: str, *, clear_error: bool = True) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_set')
    write_text_symbol(parser.state, f'{clean_root}:status', str(status or ''), 'status_set')
    write_text_symbol(parser.state, f'{clean_root}:response', '', 'response_reset')
    write_text_symbol(parser.state, f'{clean_root}:thinking_text', '', 'thinking_reset')
    if clear_error:
        write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_reset')


def _start_worker(parser, task: dict[str, Any]) -> None:
    cue = _q_cue(parser)

    def _worker() -> None:
        q_root = str(task.get('q_root') or '')
        task_id = str(task.get('task_id') or '')
        try:
            def _on_chunk(_chunk: str, _full_text: str, _chat_symbol: str, _key: str) -> None:
                force_render(parser)

            def _on_done(_full_text: str, _chat_symbol: str, _key: str) -> None:
                force_render(parser)

            q_chat(
                parser,
                str(task.get('command_token') or 'q'),
                str(task.get('prompt') or ''),
                q_root_override=q_root,
                on_chunk=_on_chunk,
                on_done=_on_done,
            )
        except Exception as exc:
            if q_root:
                try:
                    write_text_symbol(parser.state, f'{q_root}:error', str(str(exc) or ''), 'q_async_error')
                    write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_error_status')
                except Exception:
                    pass
            force_render(parser)
        finally:
            with cue['lock']:
                active = cue.get('active') or {}
                if active.get(q_root) == task_id:
                    active.pop(q_root, None)
            cue['wake'].set()
            force_render(parser)

    threading.Thread(target=_worker, name=f"q-worker-{task['task_id']}", daemon=True).start()


def _scheduler_loop(parser) -> None:
    cue = _q_cue(parser)
    while True:
        cue['wake'].wait()
        while True:
            task = None
            with cue['lock']:
                cue['wake'].clear()
                queues = cue.get('queues') or {}
                active = cue.get('active') or {}
                for alias in sorted(list(queues.keys())):
                    queue = queues.get(alias)
                    if not queue:
                        continue
                    picked_index = None
                    for idx, candidate in enumerate(list(queue)):
                        q_root = str(candidate.get('q_root') or '')
                        if not q_root:
                            picked_index = idx
                            break
                        if q_root not in active:
                            picked_index = idx
                            break
                    if picked_index is None:
                        continue
                    task = queue[picked_index]
                    del queue[picked_index]
                    q_root = str(task.get('q_root') or '')
                    if q_root:
                        active[q_root] = str(task.get('task_id') or '')
                    break
            if task is None:
                break
            _start_worker(parser, task)


def _ensure_scheduler(parser) -> None:
    cue = _q_cue(parser)
    with cue['lock']:
        if bool(cue.get('started')):
            return
        cue['started'] = True
    thread = threading.Thread(target=_scheduler_loop, args=(parser,), name='q-cue-scheduler', daemon=True)
    thread.start()


def _enqueue_query(parser, command_token: str, prompt: str) -> None:
    alias = str(command_token.split('.', 1)[1] if '.' in command_token else 'default').strip() or 'default'
    q_root = str(q_state_prefix_for_runtime(parser, alias) or '').strip()
    cue = _q_cue(parser)
    task = {
        'task_id': '',
        'alias': alias,
        'q_root': q_root,
        'command_token': command_token,
        'prompt': str(prompt or ''),
    }
    with cue['lock']:
        task['task_id'] = _task_id(cue)
        queue = cue['queues'].setdefault(alias, deque())
        queue.append(task)
        if q_root:
            _set_prompt_status(parser, q_root, prompt, 'waiting', clear_error=True)
    _ensure_scheduler(parser)
    cue['wake'].set()
    force_render(parser)


def handler(line: str, parser):
    try:
        command_token, prompt = parse_command_tail_raw(
            line,
            usage='usage: q[.profile] <prompt...>',
            label='q',
        )
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ''))

    try:
        _enqueue_query(parser, command_token, prompt)
    except QCallError as exc:
        return HandlerResponse(error=str(str(exc) or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ''), force_render=True)

    return HandlerResponse(buffer_output='', force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
