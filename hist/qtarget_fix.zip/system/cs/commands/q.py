# system/cs/commands/q.py

from __future__ import annotations

from system.cs.command_args import parse_command_tail_raw
from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_ctx, get_layout_caller_handle, get_runtime, set_runtime
from system.lib.q.errors import QCallError
from system.layout.lib.targets import resolve_querytarget
from system.layout import registry as layout_registry
from system.lib.q.session import q_chat


command = "q"
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful chat command

rules:
- streams assistant output into active q state
- writes chat history to the current q runtime root (:ch)
- reads optional role from the current q runtime root (:role:name / :role:system_prompt)
- reads optional runtime params from the active q runtime root :role:* subtree and profile defaults

examples:
  q |:q hello
  q |HELP:q $prompt
  q.coder |OTHER:q2 explain #code:main
"""

def handler(line: str, parser):
    try:
        command_token, tail = parse_command_tail_raw(
            line,
            usage="usage: q[.<profile>] <target> <prompt...>",
            label="q",
        )
        parts = str(tail or '').split(maxsplit=1)
        if len(parts) != 2:
            raise ValueError('usage: q[.<profile>] <target> <prompt...>')
        raw_target, prompt = str(parts[0] or '').strip(), str(parts[1] or '')
        if not raw_target or not prompt.strip():
            raise ValueError('usage: q[.<profile>] <target> <prompt...>')
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ""))

    try:
        caller_handle = str(get_layout_caller_handle(parser) or '').strip()
        if not caller_handle:
            ctx = get_ctx(parser)
            if isinstance(ctx, dict):
                try:
                    caller_handle = str(layout_registry.get_active_handle(ctx) or '').strip()
                except Exception:
                    caller_handle = ''
        resolved_target = resolve_querytarget(caller_handle, raw_target)
        ctx = get_ctx(parser)
        target_inst = layout_registry.get_instance(ctx, resolved_target) if isinstance(ctx, dict) else None
        if target_inst is None or getattr(target_inst, 'MODULE', '') != 'q':
            return HandlerResponse(error='target is not query-capable')
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or 'invalid querytarget'))

    final_message = ""

    try:
        def _on_chunk(_chunk: str, full_text: str, _chat_symbol: str, _key: str) -> None:
            nonlocal final_message
            final_message = str(full_text or "")
            force_render(parser)

        def _on_done(full_text: str, _chat_symbol: str, _key: str) -> None:
            nonlocal final_message
            final_message = str(full_text or "")
            force_render(parser)

        previous_q_root = get_runtime(parser, 'q_state_root', '')
        previous_layout_handle = get_runtime(parser, 'layout_caller_handle', '')
        set_runtime(parser, 'q_state_root', resolved_target)
        set_runtime(parser, 'layout_caller_handle', resolved_target)
        try:
            out = q_chat(
                parser,
                command_token,
                prompt,
                on_chunk=_on_chunk,
                on_done=_on_done,
            )
        finally:
            set_runtime(parser, 'q_state_root', previous_q_root)
            set_runtime(parser, 'layout_caller_handle', previous_layout_handle)

        returned_message = str((out or {}).get("message") or "")
        if len(returned_message) > len(final_message):
            final_message = returned_message

    except QCallError as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(str(exc) or ""), force_render=True)

    force_render(parser)
    if bool(get_runtime(parser, "layout_self_route", False)):
        return HandlerResponse(buffer_output="", force_render=True)
    return HandlerResponse(buffer_output=str(final_message or ""), force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )
