# Q Commands

Commands for stateful and stateless model calls.

## q

```text
q[.profile] <prompt...>
```

stateful chat command

rules:
- streams assistant output into active q state
- writes chat history to the current q runtime root (:ch)
- reads optional role from the current q runtime root (:role:name / :role:system_prompt)
- reads optional runtime params from the active q runtime root :role:* subtree and profile defaults

examples:
  q hello
  q $prompt
  q.coder explain #code:main

## qc

```text
qc[.profile] <output> <prompt...>
```

stateless structured q call

rules:
- output target is explicit
- no chat history is written
- accepted decoded output types: string, list, dict
- returns [ok] after writing decoded output to target

examples:
  qc #out hello
  qc.coder #out $prompt
