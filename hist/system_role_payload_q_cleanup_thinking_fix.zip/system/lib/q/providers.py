from __future__ import annotations

import json
import re
from typing import Any

from .common import deep_get, normalize_path_list, to_plain_string, extract_first_nonempty_scalar, normalize_think_value
from .errors import QCallError


_DEFAULT_RESPONSE_PATHS = (
    "response",
    "message.content",
    "message",
    "choices.0.message.content",
    "content",
)

_DEFAULT_STREAM_PATHS = (
    "response",
    "choices.0.delta.content",
    "delta.content",
    "message.content",
    "choices.0.message.content",
    "content",
)

_DEFAULT_THINKING_PATHS = (
    "message.thinking",
    "thinking",
    "choices.0.delta.reasoning_content",
    "delta.reasoning_content",
    "choices.0.message.reasoning_content",
    "message.reasoning_content",
    "reasoning_content",
)

_INLINE_THINK_OPEN = "<think>"
_INLINE_THINK_CLOSE = "</think>"
_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
_THINK_TAG_RE = re.compile(r"</?think>", re.IGNORECASE)
_OPENAI_REASONING_VALUES = {"none", "minimal", "low", "medium", "high", "xhigh"}


def _model_is_gpt_oss(model: Any) -> bool:
    return str(model or "").strip().lower().startswith("gpt-oss")


def _provider_is_ollama_like(provider: str, base_url: str) -> bool:
    return provider == "ollama" or "/api/chat" in base_url or base_url.endswith("/api/chat")


def _provider_is_openai_like(provider: str, base_url: str) -> bool:
    return "/chat/completions" in base_url or provider in {"openai", "openrouter"}


def _apply_think_payload(payload: dict[str, Any], *, provider: str, base_url: str, model: Any, think_value: Any) -> None:
    normalized = normalize_think_value(think_value, None)
    if normalized is None:
        return

    ollama_like = _provider_is_ollama_like(provider, base_url)
    openai_like = _provider_is_openai_like(provider, base_url)

    if ollama_like:
        if isinstance(normalized, bool):
            payload["think"] = normalized
            return
        if isinstance(normalized, str):
            if normalized == "none":
                payload["think"] = False
            elif normalized in {"minimal", "low", "medium", "high", "xhigh"}:
                payload["think"] = True
            return

    if openai_like:
        if isinstance(normalized, str) and normalized in _OPENAI_REASONING_VALUES:
            if _model_is_gpt_oss(model) and normalized not in {"low", "medium", "high"}:
                return
            payload["reasoning"] = {"effort": normalized}
            return
        if isinstance(normalized, bool):
            if normalized is False:
                payload["reasoning"] = {"effort": "none"}
            elif not _model_is_gpt_oss(model):
                payload["reasoning"] = {"effort": "medium"}
            return
        return

    payload["think"] = normalized


def chat_to_provider_messages(system_prompt: str, chat: dict, prompt: str) -> list[dict]:
    messages: list[dict] = []
    if str(system_prompt or "").strip():
        messages.append({"role": "system", "content": str(system_prompt)})
    rows: list[tuple[int, dict]] = []
    for key, value in (chat or {}).items():
        if not isinstance(value, dict):
            continue
        try:
            idx = int(str(key))
        except Exception:
            continue
        rows.append((idx, value))
    rows.sort(key=lambda x: x[0])
    for _, item in rows:
        item_prompt = str(item.get("prompt") or "")
        item_response = str(item.get("response") or "")
        if item_prompt:
            messages.append({"role": "user", "content": item_prompt})
        if item_response:
            messages.append({"role": "assistant", "content": item_response})
    messages.append({"role": "user", "content": prompt})
    return messages


def build_payload_from_effective(effective: dict[str, Any], prompt: str, chat: dict | None = None, *, stream: bool | None = None) -> dict[str, Any]:
    provider = str(effective.get("provider") or "").strip().lower()
    base_url = str(effective.get("base_url") or "").strip().lower()
    model = effective.get("model")
    system_prompt = str(effective.get("system_prompt") or "")
    stream_value = effective.get("stream") if stream is None else stream
    stream_enabled = bool(stream_value)

    if _provider_is_ollama_like(provider, base_url):
        if model in (None, ""):
            raise QCallError("model is required")
        payload = {
            "model": model,
            "messages": chat_to_provider_messages(system_prompt, dict(chat or {}), prompt),
            "stream": stream_enabled,
        }
        _apply_think_payload(payload, provider=provider, base_url=base_url, model=model, think_value=effective.get("think"))
        options: dict[str, Any] = {}
        for key in ("temperature", "top_k", "top_p", "repeat_penalty"):
            if effective.get(key) not in (None, ""):
                options[key] = effective[key]
        if effective.get("max_tokens") not in (None, ""):
            options["num_predict"] = effective["max_tokens"]
        if effective.get("seed") not in (None, ""):
            options["seed"] = effective["seed"]
        if effective.get("num_ctx") not in (None, ""):
            options["num_ctx"] = effective["num_ctx"]
        stop_values = effective.get("stop")
        if isinstance(stop_values, list) and stop_values:
            options["stop"] = list(stop_values)
        if options:
            payload["options"] = options
        return payload

    if _provider_is_openai_like(provider, base_url):
        if model in (None, ""):
            raise QCallError("model is required")
        payload = {
            "model": model,
            "messages": chat_to_provider_messages(system_prompt, dict(chat or {}), prompt),
            "stream": stream_enabled,
        }
        for key in ("temperature", "top_p", "max_tokens", "seed"):
            if effective.get(key) not in (None, ""):
                payload[key] = effective[key]
        stop_values = effective.get("stop")
        if isinstance(stop_values, list) and stop_values:
            payload["stop"] = list(stop_values)
        _apply_think_payload(payload, provider=provider, base_url=base_url, model=model, think_value=effective.get("think"))
        return payload

    payload = {
        "prompt": prompt,
        "role": system_prompt,
        "chat": dict(chat or {}),
    }
    if model not in (None, ""):
        payload["model"] = model
    if stream_enabled:
        payload["stream"] = True
    for key in ("temperature", "top_k", "top_p", "repeat_penalty", "max_tokens", "seed", "num_ctx"):
        if effective.get(key) not in (None, ""):
            payload[key] = effective[key]
    stop_values = effective.get("stop")
    if isinstance(stop_values, list) and stop_values:
        payload["stop"] = list(stop_values)
    _apply_think_payload(payload, provider=provider, base_url=base_url, model=model, think_value=effective.get("think"))
    return payload


def extract_raw_value(payload, chat_message_tag: str | list[str] | None):
    if isinstance(payload, str):
        return payload
    if isinstance(payload, (dict, list)):
        for path in normalize_path_list(chat_message_tag):
            value = deep_get(payload, path)
            if value is not None:
                return value
        for path in _DEFAULT_RESPONSE_PATHS:
            value = deep_get(payload, path)
            if value is not None:
                return value
        return payload
    raise QCallError(f"unsupported q response type: {type(payload).__name__}")


def _stream_error_message(payload: Any) -> str:
    if not isinstance(payload, dict):
        return ""
    payload_type = str(payload.get("type") or "").strip().lower()
    if payload_type == "error":
        error_obj = payload.get("error")
        if isinstance(error_obj, dict):
            for key in ("message", "detail", "type"):
                value = error_obj.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
            return json.dumps(error_obj, ensure_ascii=False)
        if isinstance(error_obj, str) and error_obj.strip():
            return error_obj.strip()
        message = payload.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
    if "error" in payload:
        error_obj = payload.get("error")
        if isinstance(error_obj, dict):
            for key in ("message", "detail", "type"):
                value = error_obj.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
            return json.dumps(error_obj, ensure_ascii=False)
        if isinstance(error_obj, str) and error_obj.strip():
            return error_obj.strip()
    return ""


def _is_terminal_stream_event(payload: Any, provider: str = "") -> bool:
    if not isinstance(payload, dict):
        return False
    if payload.get("done") is True:
        return True
    payload_type = str(payload.get("type") or "").strip().lower()
    provider = str(provider or "").strip().lower()
    if payload_type in {"message_stop", "response.completed", "response.complete", "completion.stop"}:
        return True
    if provider == "anthropic" and payload_type == "message_delta":
        stop_reason = payload.get("stop_reason")
        if isinstance(stop_reason, str) and stop_reason.strip():
            return True
    finish_reason = deep_get(payload, "choices.0.finish_reason")
    if isinstance(finish_reason, str) and finish_reason.strip():
        return True
    stop_reason = payload.get("stop_reason")
    if isinstance(stop_reason, str) and stop_reason.strip():
        return True
    return False


def _thinking_paths(thinking_message_tag: str | list[str] | None) -> list[str]:
    paths: list[str] = []
    paths.extend(normalize_path_list(thinking_message_tag))
    for path in _DEFAULT_THINKING_PATHS:
        if path not in paths:
            paths.append(path)
    return paths


def extract_chat(payload, chat_message_tag: str | list[str] | None) -> str:
    value = extract_raw_value(payload, chat_message_tag)
    return to_plain_string(value)


def strip_inline_think_markup(text: str) -> str:
    return _THINK_BLOCK_RE.sub("", _THINK_TAG_RE.sub("", str(text or ""))).strip()


def new_inline_thinking_state() -> dict[str, Any]:
    return {"buffer": "", "is_thinking": False}


def inline_thinking_active(state: dict[str, Any] | None) -> bool:
    if not isinstance(state, dict):
        return False
    return bool(state.get("buffer") or state.get("is_thinking"))


def split_inline_think_tags(text: str, state: dict[str, Any] | None = None, *, flush: bool = False) -> tuple[str, str]:
    buffer = "" if not isinstance(state, dict) else str(state.get("buffer") or "")
    text = buffer + str(text or "")
    thinking_parts: list[str] = []
    content_parts: list[str] = []
    is_thinking = bool(state.get("is_thinking")) if isinstance(state, dict) else False

    while text:
        if is_thinking:
            close_idx = text.lower().find(_INLINE_THINK_CLOSE)
            if close_idx == -1:
                thinking_parts.append(text)
                text = ""
                break
            thinking_parts.append(text[:close_idx])
            text = text[close_idx + len(_INLINE_THINK_CLOSE):]
            is_thinking = False
            continue

        open_idx = text.lower().find(_INLINE_THINK_OPEN)
        if open_idx == -1:
            content_parts.append(text)
            text = ""
            break
        if open_idx > 0:
            content_parts.append(text[:open_idx])
        text = text[open_idx + len(_INLINE_THINK_OPEN):]
        is_thinking = True

    if flush and text:
        (thinking_parts if is_thinking else content_parts).append(text)
        text = ""
        is_thinking = False

    if isinstance(state, dict):
        state["buffer"] = text
        state["is_thinking"] = is_thinking
    return ("".join(thinking_parts), "".join(content_parts))


def _extract_delta_text(payload: dict[str, Any]) -> str:
    if not isinstance(payload, dict):
        return ""
    delta = payload.get("delta")
    if isinstance(delta, str):
        return delta
    if isinstance(delta, dict):
        for path in ("text", "content", "reasoning_content"):
            value = deep_get(delta, path)
            if isinstance(value, str) and value:
                return value
    for path in ("delta", "text"):
        value = payload.get(path)
        if isinstance(value, str) and value:
            return value
    return ""


def _route_typed_stream_delta(payload: dict[str, Any], *, provider: str, done: int, error: str) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    payload_type = str(payload.get("type") or "").strip().lower()
    if not payload_type:
        return None
    delta_text = _extract_delta_text(payload)
    if not delta_text:
        return None

    if "reasoning" in payload_type or "thinking" in payload_type:
        return {"content": "", "thinking": delta_text, "done": done, "error": error, "raw": payload}

    if payload_type in {"response.output_text.delta", "response.content_part.delta", "response.text.delta"}:
        return {"content": delta_text, "thinking": "", "done": done, "error": error, "raw": payload}

    if provider in {"openai", "openrouter"} and payload_type.endswith(".delta") and "output" in payload_type:
        return {"content": delta_text, "thinking": "", "done": done, "error": error, "raw": payload}

    return None


def extract_stream_event(payload: Any, *, stream_message_tag: str | list[str] | None, chat_message_tag: str | list[str] | None, thinking_message_tag: str | list[str] | None, provider: str = "", inline_thinking_state: dict[str, Any] | None = None, allow_inline_thinking: bool = False) -> dict[str, Any]:
    if isinstance(payload, str):
        content = payload
        thinking = ""
        if allow_inline_thinking:
            thinking, content = split_inline_think_tags(content, inline_thinking_state)
        return {"content": content, "thinking": thinking, "done": 0, "error": "", "raw": payload}

    if not isinstance(payload, dict):
        return {"content": to_plain_string(payload), "thinking": "", "done": 0, "error": "", "raw": payload}

    error = _stream_error_message(payload)
    done = 1 if _is_terminal_stream_event(payload, provider=provider) else 0

    routed = _route_typed_stream_delta(payload, provider=provider, done=done, error=error)
    if routed is not None:
        return routed

    paths = normalize_path_list(stream_message_tag) or normalize_path_list(chat_message_tag)
    if not paths:
        paths = list(_DEFAULT_STREAM_PATHS)
    content = extract_first_nonempty_scalar(payload, paths)
    thinking = extract_first_nonempty_scalar(payload, _thinking_paths(thinking_message_tag))

    if allow_inline_thinking and content:
        inline_thinking, content = split_inline_think_tags(content, inline_thinking_state)
        if inline_thinking:
            thinking = (thinking or "") + inline_thinking

    return {
        "content": content,
        "thinking": thinking,
        "done": done,
        "error": error,
        "raw": payload,
    }


def decode_qc_output(payload, chat_message_tag: str | list[str] | None):
    raw = extract_raw_value(payload, chat_message_tag)
    if isinstance(raw, (dict, list, str)):
        return {"decoded": raw, "message": to_plain_string(raw)}
    return {"decoded": to_plain_string(raw), "message": to_plain_string(raw)}


def profile_has_stream(profile: dict) -> bool:
    return bool(profile.get('stream'))


__all__ = [
    'build_payload_from_effective',
    'decode_qc_output',
    'extract_chat',
    'extract_stream_event',
    'inline_thinking_active',
    'new_inline_thinking_state',
    'profile_has_stream',
    'split_inline_think_tags',
    'strip_inline_think_markup',
]
