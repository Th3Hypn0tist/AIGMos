from __future__ import annotations

import threading
from typing import Any

from system.cs.command_def import CommandDef
from system.cs.models import HandlerResponse
from system.cs.runtime_ctx import force_render, get_layout_caller_handle
from system.lib.q.errors import QCallError
from system.lib.q.profile import resolve_profile_name
from system.lib.q.qcue import (
    qcue_claim_next_runnable,
    qcue_complete,
    qcue_enqueue,
    qcue_lock,
    qcue_runtime,
    qcue_set_started,
    qcue_started,
    qcue_thread_get,
    qcue_thread_set,
    qcue_wake,
    qcue_wake_event,
)
from system.lib.q.session import q_chat, qc_raw
from system.lib.q.state import load_chat, write_full_chat_entry, write_text_symbol
from system.layout.lib.targets import resolve_querytarget
from system.state.api import write_value

command = 'q'
help_short = 'q[.profile] <target> <prompt...>'
help_full = """stateful chat/query dispatch

rules:
- target is explicit
- dispatches query asynchronously
- does not return successful assistant output to command buffer
- writes prompt/status into q runtime when the job actually starts
- one active slot per q runtime root; queued jobs show WAITING/CUE in the UI
- q jobs have priority over qc jobs

examples:
  q |:q hello
  q |HELP:q explain #HELP:README.md
  q.coder |:q refactor this
"""


def _parse_q_target_prompt(line: str) -> tuple[str, str, str]:
    raw = str(line or '').strip()
    parts = raw.split(maxsplit=2)
    if len(parts) < 3:
        raise ValueError('usage: q[.profile] <target> <prompt...>')
    command_token, target, prompt = parts[0], parts[1], parts[2]
    if not prompt or not prompt.strip():
        raise ValueError('q requires prompt')
    return command_token, target, prompt


def _qc_writer_name(profile_name: str) -> str:
    clean = str(profile_name or 'default').strip() or 'default'
    return f'q:{clean}'


def _write_qc_output(parser, output_symbol: str, payload: Any, profile_name: str) -> None:
    out = write_value(
        parser.state,
        output_symbol,
        payload,
        writer=_qc_writer_name(profile_name),
        op='qc',
    )
    if out.get('error'):
        raise QCallError(str(out['error']))


def _write_qc_error_output(parser, output_symbol: str, error: str, profile_name: str) -> None:
    clean_output = str(output_symbol or '').strip()
    if not clean_output:
        return
    _write_qc_output(parser, clean_output, f'ERROR: {str(error or "")}', profile_name)


def _set_active_live_state(parser, q_root: str, prompt: str, alias: str) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return
    write_text_symbol(parser.state, f'{clean_root}:prompt', str(prompt or ''), 'prompt_set')
    write_text_symbol(parser.state, f'{clean_root}:status', 'running', 'status_set')
    write_text_symbol(parser.state, f'{clean_root}:response', '', 'response_reset')
    write_text_symbol(parser.state, f'{clean_root}:thinking_text', '', 'thinking_reset')
    write_text_symbol(parser.state, f'{clean_root}:error', '', 'error_reset')
    write_text_symbol(parser.state, f'{clean_root}:queue_alias', str(alias or ''), 'queue_alias_set')
    try:
        write_text_symbol(parser.state, f'{clean_root}:cue', '', 'cue_clear')
    except Exception:
        pass


def _has_visible_chat_result(parser, q_root: str, prompt: str) -> bool:
    clean_root = str(q_root or '').strip()
    if not clean_root:
        return False
    try:
        chat = load_chat(parser.state, f'{clean_root}:ch')
    except Exception:
        return False
    if not isinstance(chat, dict) or not chat:
        return False
    keys = sorted(chat.keys(), key=lambda item: (0, int(str(item))) if str(item).isdigit() else (1, str(item)))
    latest = chat.get(keys[-1]) if keys else None
    if not isinstance(latest, dict):
        return False
    return str(latest.get('prompt') or '') == str(prompt or '') and int(latest.get('done') or 0) == 1


def _write_visible_q_error(parser, q_root: str, prompt: str, error: str) -> None:
    clean_root = str(q_root or '').strip()
    if not clean_root or _has_visible_chat_result(parser, clean_root, prompt):
        return
    write_full_chat_entry(parser.state, f'{clean_root}:ch', str(prompt or ''), f'ERROR: {str(error or "")}')


def _refresh_render(parser) -> None:
    try:
        force_render(parser)
    except Exception:
        pass


def _run_q_task(parser, task: dict[str, Any]) -> None:
    q_root = str(task.get('q_root') or '').strip()
    alias = str(task.get('alias') or 'default').strip() or 'default'
    command_token = str(task.get('command_token') or 'q')
    prompt = str(task.get('prompt') or '')
    caller_handle = str(task.get('caller_handle') or '').strip() or None
    profile_name = str(task.get('profile_name') or '').strip() or None
    task_id = str(task.get('task_id') or '').strip()

    _set_active_live_state(parser, q_root, prompt, alias)
    _refresh_render(parser)
    try:
        q_chat(
            parser,
            command_token,
            prompt,
            q_root_override=q_root,
            caller_handle_override=caller_handle,
            profile_name_override=profile_name,
            on_chunk=lambda *_args: _refresh_render(parser),
            on_done=lambda *_args: _refresh_render(parser),
        )
        qcue_complete(parser, alias, q_root, task_id, 'done')
    except Exception as exc:
        try:
            if q_root:
                write_text_symbol(parser.state, f'{q_root}:error', str(exc or ''), 'q_async_error')
                write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_async_error_status')
                _write_visible_q_error(parser, q_root, prompt, str(exc or ''))
        finally:
            qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
        raise
    finally:
        qcue_wake(parser)
        _refresh_render(parser)


def _run_qc_task(parser, task: dict[str, Any]) -> None:
    alias = str(task.get('alias') or 'default').strip() or 'default'
    command_token = str(task.get('command_token') or 'qc')
    prompt = str(task.get('prompt') or '')
    caller_handle = str(task.get('caller_handle') or '').strip() or None
    profile_name = str(task.get('profile_name') or '').strip() or None
    output_symbol = str(task.get('output_symbol') or '').strip()
    task_id = str(task.get('task_id') or '').strip()
    try:
        out = qc_raw(
            parser,
            command_token,
            prompt,
            caller_handle_override=caller_handle,
            profile_name_override=profile_name,
        )
        _write_qc_output(parser, output_symbol, out['decoded'], out.get('profile', profile_name or alias))
        qcue_complete(parser, alias, '', task_id, 'done')
    except Exception as exc:
        try:
            _write_qc_error_output(parser, output_symbol, str(exc or ''), profile_name or alias)
        finally:
            qcue_complete(parser, alias, '', task_id, 'error', error=str(exc or ''))
        raise
    finally:
        qcue_wake(parser)
        _refresh_render(parser)


def _start_worker(parser, task: dict[str, Any]) -> None:
    kind = str(task.get('kind') or 'q').strip().lower()

    def _worker() -> None:
        try:
            if kind == 'qc':
                _run_qc_task(parser, task)
            else:
                _run_q_task(parser, task)
        except Exception:
            pass

    thread = threading.Thread(target=_worker, name=f'qcue-{kind}-{task.get("task_id")}', daemon=True)
    thread.start()


def _scheduler_loop(parser) -> None:
    runtime = qcue_runtime(parser)
    wake = qcue_wake_event(parser)
    try:
        while True:
            wake.wait()
            while True:
                wake.clear()
                task = qcue_claim_next_runnable(parser)
                if task is None:
                    break
                try:
                    _start_worker(parser, task)
                except Exception as exc:
                    runtime['last_error'] = str(exc or '')
                    kind = str(task.get('kind') or 'q').strip().lower()
                    alias = str(task.get('alias') or 'default').strip() or 'default'
                    q_root = str(task.get('q_root') or '').strip()
                    task_id = str(task.get('task_id') or '').strip()
                    if kind == 'q' and q_root:
                        try:
                            write_text_symbol(parser.state, f'{q_root}:error', f'scheduler start error: {exc}', 'q_scheduler_start_error')
                            write_text_symbol(parser.state, f'{q_root}:status', 'error', 'q_scheduler_start_error_status')
                            _write_visible_q_error(parser, q_root, str(task.get('prompt') or ''), str(exc or ''))
                        except Exception:
                            pass
                    qcue_complete(parser, alias, q_root, task_id, 'error', error=str(exc or ''))
                    qcue_wake(parser)
                    _refresh_render(parser)
                    continue
    finally:
        with qcue_lock(parser):
            qcue_thread_set(parser, None)
            qcue_set_started(parser, False)


def _ensure_scheduler(parser) -> None:
    thread = threading.Thread(target=_scheduler_loop, args=(parser,), name='qcue-scheduler', daemon=True)
    with qcue_lock(parser):
        existing = qcue_thread_get(parser)
        if qcue_started(parser) and existing is not None and existing.is_alive():
            return
        qcue_thread_set(parser, None)
        qcue_set_started(parser, False)
    try:
        thread.start()
    except Exception:
        with qcue_lock(parser):
            qcue_thread_set(parser, None)
            qcue_set_started(parser, False)
        raise
    with qcue_lock(parser):
        qcue_thread_set(parser, thread)
        qcue_set_started(parser, True)


def enqueue_q_command(parser, command_token: str, raw_target: str, prompt: str) -> dict[str, Any]:
    caller_handle = get_layout_caller_handle(parser)
    q_root = resolve_querytarget(raw_target, caller_handle)
    profile_name = resolve_profile_name(parser, command_token, 'q')
    task = qcue_enqueue(
        parser,
        kind='q',
        alias=profile_name,
        command_token=command_token,
        prompt=prompt,
        q_root=q_root,
        caller_handle=caller_handle,
        profile_name=profile_name,
    )
    _ensure_scheduler(parser)
    qcue_wake(parser)
    _refresh_render(parser)
    return task


def enqueue_qc_command(parser, command_token: str, output_symbol: str, prompt: str) -> dict[str, Any]:
    caller_handle = get_layout_caller_handle(parser)
    profile_name = resolve_profile_name(parser, command_token, 'qc')
    task = qcue_enqueue(
        parser,
        kind='qc',
        alias=profile_name,
        command_token=command_token,
        prompt=prompt,
        caller_handle=caller_handle,
        profile_name=profile_name,
        output_symbol=str(output_symbol or '').strip(),
    )
    _ensure_scheduler(parser)
    qcue_wake(parser)
    _refresh_render(parser)
    return task


def handler(line: str, parser):
    try:
        command_token, raw_target, prompt = _parse_q_target_prompt(line)
        enqueue_q_command(parser, command_token, raw_target, prompt)
    except QCallError as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)
    except Exception as exc:
        return HandlerResponse(error=str(exc or ''), force_render=True)
    return HandlerResponse(buffer_output='', force_render=True)


def register() -> CommandDef:
    return CommandDef(
        command=command,
        handler=handler,
        help_short=help_short,
        help_full=help_full,
    )


__all__ = [
    'enqueue_q_command',
    'enqueue_qc_command',
    'register',
]
