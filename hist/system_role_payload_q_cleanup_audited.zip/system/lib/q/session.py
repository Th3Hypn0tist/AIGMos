from __future__ import annotations

from typing import Any, Callable

from .errors import QCallError
from .live import chunk_q_live, done_q_live, fail_q_live, open_q_live
from .profile import get_profile, resolve_model, resolve_profile_name, resolve_timeout, set_active_profile
from .prompt import expand_prompt_symbols
from .providers import decode_qc_output, strip_inline_think_markup
from .roles import BACKEND_ROLE_KEYS, load_role_from_canonical_source
from .state import merge_thinking_stream, append_response_stream, write_text_symbol, load_chat, open_chat_entry, save_chat, write_chat_entry
from .symbols import chat_symbol_for_runtime, response_symbol_for_runtime, thinking_symbol_for_runtime
from .transport import call_effective, stream_effective
from .common import coerce_bool, normalize_think_value, read_state_value


_INSTANCE_OVERRIDE_KEYS = BACKEND_ROLE_KEYS
_NUMERIC_FLOAT_KEYS = {"temperature", "top_p", "repeat_penalty"}
_NUMERIC_INT_KEYS = {"top_k", "max_tokens", "seed", "num_ctx"}


def _coerce_toggle(value: Any, default: bool = True) -> bool:
    if value in (None, ''):
        return bool(default)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    clean = str(value).strip().lower()
    if not clean:
        return bool(default)
    if clean in {'0', 'false', 'no', 'off'}:
        return False
    if clean in {'1', 'true', 'yes', 'on'}:
        return True
    return bool(default)


def _parent_layout_root(q_root: str) -> str:
    clean = str(q_root or '').strip()
    if not clean.startswith('|') or ':' not in clean:
        return ''
    return clean.rsplit(':', 1)[0]


def resolve_active_q_root(parser) -> str:
    runtime = getattr(parser, 'runtime', None)
    q_root = ''
    if isinstance(runtime, dict):
        q_root = str(runtime.get('q_state_root') or '').strip()
    if not q_root:
        raise QCallError('active q root missing')
    return q_root


def _resolve_show_thinking(state, q_root: str) -> bool:
    parent = _parent_layout_root(q_root)
    if not parent:
        return True
    raw = read_state_value(state, f'{parent}:show_thinking', 'on')
    return _coerce_toggle(raw, True)


def _read_q_root_value(state, q_root: str, field: str, default=None):
    return read_state_value(state, f'{q_root}:{field}', default)


def read_role_reference_from_active_q_root(state, q_root: str) -> str:
    return str(_read_q_root_value(state, q_root, 'role', '') or '').strip()


def _coerce_sampler_value(key: str, value: Any):
    if value in (None, ''):
        return None
    if key == 'think':
        return normalize_think_value(value, None)
    if key == 'stream':
        return coerce_bool(value, None)
    if key in _NUMERIC_FLOAT_KEYS:
        try:
            return float(value)
        except Exception as exc:
            raise QCallError(f'invalid sampler value for {key}: {value}') from exc
    if key in _NUMERIC_INT_KEYS:
        try:
            return int(value)
        except Exception as exc:
            raise QCallError(f'invalid sampler value for {key}: {value}') from exc
    if key == 'stop':
        if isinstance(value, list):
            return [str(item) for item in value if str(item)]
        text = str(value).strip()
        return [text] if text else None
    return value


def read_instance_q_overrides(state, q_root: str) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    for key in _INSTANCE_OVERRIDE_KEYS:
        raw = _read_q_root_value(state, q_root, key, None)
        if raw in (None, ''):
            continue
        overrides[key] = _coerce_sampler_value(key, raw)
    return overrides


def _base_effective_from_profile(parser, profile_name: str, profile: dict[str, Any]) -> dict[str, Any]:
    effective = dict(profile)
    effective['profile_name'] = profile_name
    effective['model'] = resolve_model(profile, parser.state, profile_name)
    effective['timeout_seconds'] = resolve_timeout(profile, 'timeout_seconds', state=parser.state, profile_name=profile_name, required=True)
    effective['stream_timeout_seconds'] = resolve_timeout(profile, 'stream_timeout_seconds', state=parser.state, profile_name=profile_name, default=None, required=False)
    effective['stream'] = coerce_bool(profile.get('stream'), False)
    effective['think'] = normalize_think_value(profile.get('think'), None)
    if effective['think'] is None:
        effective['think'] = normalize_think_value(profile.get('thinking'), None)
    for key in ('temperature', 'top_p', 'repeat_penalty'):
        if profile.get(key) not in (None, ''):
            effective[key] = float(profile.get(key))
    for key in ('top_k', 'max_tokens', 'seed', 'num_ctx'):
        if profile.get(key) not in (None, ''):
            effective[key] = int(profile.get(key))
    stop_value = profile.get('stop')
    if isinstance(stop_value, list):
        effective['stop'] = [str(item) for item in stop_value if str(item)]
    elif isinstance(stop_value, str) and stop_value.strip():
        effective['stop'] = [stop_value.strip()]
    effective['system_prompt'] = ''
    return effective


def merge_effective_q_config(base: dict[str, Any], role_overlay: dict[str, Any], instance_overrides: dict[str, Any]) -> dict[str, Any]:
    effective = dict(base)
    for layer in (role_overlay or {}, instance_overrides or {}):
        for key, value in dict(layer).items():
            if value in (None, ''):
                continue
            effective[key] = value
    return effective



def _normalize_effective_backend_fields(effective: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(effective or {})
    for key in _INSTANCE_OVERRIDE_KEYS:
        if key not in normalized:
            continue
        value = _coerce_sampler_value(key, normalized.get(key))
        if value in (None, ''):
            normalized.pop(key, None)
        else:
            normalized[key] = value
    return normalized


def resolve_effective_q_config(parser, command_token: str, prompt: str) -> dict[str, Any]:
    profile_name = resolve_profile_name(parser, command_token, 'q')
    profile = get_profile(parser, profile_name)
    set_active_profile(parser, profile_name)

    q_root = resolve_active_q_root(parser)
    chat_symbol = chat_symbol_for_runtime(parser, profile_name)
    response_symbol = response_symbol_for_runtime(parser, profile_name)
    thinking_symbol = thinking_symbol_for_runtime(parser, profile_name)
    chat = load_chat(parser.state, chat_symbol)
    expanded_prompt = expand_prompt_symbols(parser, prompt)

    role_ref = read_role_reference_from_active_q_root(parser.state, q_root)
    role_data = load_role_from_canonical_source(parser.state, role_ref) if role_ref else {}
    role_overlay = dict((role_data or {}).get('backend_overrides') or {})
    instance_overrides = read_instance_q_overrides(parser.state, q_root)
    base_effective = _base_effective_from_profile(parser, profile_name, profile)
    effective = _normalize_effective_backend_fields(merge_effective_q_config(base_effective, role_overlay, instance_overrides))
    effective['role_ref'] = str((role_data or {}).get('role') or role_ref or '')
    effective['system_prompt'] = str((role_data or {}).get('system_prompt') or '')
    effective['q_root'] = q_root
    effective['chat_symbol'] = chat_symbol
    effective['response_symbol'] = response_symbol
    effective['thinking_symbol'] = thinking_symbol
    effective['chat'] = chat
    effective['prompt'] = prompt
    effective['expanded_prompt'] = expanded_prompt
    effective['show_thinking'] = _resolve_show_thinking(parser.state, q_root)
    return dict(effective)


def prepare_q_session(parser, command_token: str, prompt: str) -> dict:
    effective = resolve_effective_q_config(parser, command_token, prompt)
    return {
        'profile_name': str(effective.get('profile_name') or 'default'),
        'effective': effective,
        'state': parser.state,
        'q_state_root': str(effective.get('q_root') or ''),
        'chat_symbol': str(effective.get('chat_symbol') or ''),
        'prompt': prompt,
        'expanded_prompt': str(effective.get('expanded_prompt') or prompt),
        'chat': dict(effective.get('chat') or {}),
        'stream_enabled': 1 if bool(effective.get('stream')) else 0,
        'think_value': effective.get('think'),
        'show_thinking': bool(effective.get('show_thinking', True)),
    }


def run_nonstream_session(session: dict) -> str:
    payload = call_effective(
        session['effective'],
        session['expanded_prompt'],
        chat=session['chat'],
    )
    return strip_inline_think_markup(str(decode_qc_output(payload, session['effective'].get('chat_message_tag')).get('message') or ''))


def q_chat(parser, command_token: str, prompt: str, on_chunk: Callable[[str, str, str, str], None] | None = None, on_done: Callable[[str, str, str], None] | None = None) -> dict:
    session = prepare_q_session(parser, command_token, prompt)
    profile_name = session['profile_name']
    chat_symbol = session['chat_symbol']
    response_symbol = str(session['effective'].get('response_symbol') or response_symbol_for_runtime(parser, profile_name))
    thinking_symbol = str(session['effective'].get('thinking_symbol') or thinking_symbol_for_runtime(parser, profile_name))
    think_value = session.get('think_value')
    show_thinking = bool(session.get('show_thinking', True))

    write_text_symbol(parser.state, response_symbol, '', 'response_reset')
    write_text_symbol(parser.state, thinking_symbol, '', 'thinking_reset')
    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key='', prompt=prompt, response='', thinking='')

    if not session['stream_enabled']:
        final_text = run_nonstream_session(session)
        chat_log = dict(session['chat'])
        key = str(max([int(k) for k in chat_log.keys() if str(k).isdigit()] + [0]) + 1)
        chat_log[key] = {'prompt': prompt, 'response': final_text, 'done': 1}
        save_chat(parser.state, chat_symbol, chat_log)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')
        if callable(on_done):
            on_done(final_text, chat_symbol, key)
        return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}

    key = open_chat_entry(parser.state, chat_symbol, prompt)
    final_text = ''
    final_thinking = ''
    last_written_response = ''

    open_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response='', thinking='')

    try:
        for event in stream_effective(session['effective'], session['expanded_prompt'], chat=session['chat']):
            raw_thinking_chunk = strip_inline_think_markup(event.get('thinking') or '')
            content_chunk = strip_inline_think_markup(event.get('content') or '')
            event_done = 1 if int(event.get('done') or 0) == 1 else 0

            thinking_chunk = raw_thinking_chunk
            if think_value is False:
                thinking_chunk = ''

            if thinking_chunk:
                final_thinking = merge_thinking_stream(final_thinking, thinking_chunk)
            if content_chunk:
                final_text = append_response_stream(final_text, content_chunk)

            visible_response = strip_inline_think_markup(final_text)
            visible_thinking = ''
            if show_thinking and not visible_response and final_thinking:
                visible_thinking = final_thinking

            write_text_symbol(parser.state, response_symbol, visible_response, 'response_partial')
            write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
            if visible_response != last_written_response:
                write_chat_entry(parser.state, chat_symbol, key, prompt, visible_response, done=0)
                last_written_response = visible_response
            chunk_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=visible_response, thinking=visible_thinking)

            if callable(on_chunk) and (thinking_chunk or content_chunk):
                on_chunk(content_chunk or thinking_chunk, visible_response, chat_symbol, key)

            if event_done == 1:
                break

        final_text = strip_inline_think_markup(final_text)
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=1)
        write_text_symbol(parser.state, response_symbol, '', 'response_finalize')
        write_text_symbol(parser.state, thinking_symbol, '', 'thinking_finalize')
        done_q_live(parser, profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking='')

        if callable(on_done):
            on_done(final_text, chat_symbol, key)

    except Exception:
        final_text = strip_inline_think_markup(final_text)
        visible_thinking = ''
        if show_thinking and not final_text and final_thinking:
            visible_thinking = final_thinking
        write_chat_entry(parser.state, chat_symbol, key, prompt, final_text, done=0)
        write_text_symbol(parser.state, response_symbol, final_text, 'response_partial')
        write_text_symbol(parser.state, thinking_symbol, visible_thinking, 'thinking_partial')
        fail_q_live(parser, 'q stream interrupted', profile=profile_name, chat_symbol=chat_symbol, response_symbol=response_symbol, thinking_symbol=thinking_symbol, key=key, prompt=prompt, response=final_text, thinking=visible_thinking)
        raise

    return {'profile': profile_name, 'chat_symbol': chat_symbol, 'response_symbol': response_symbol, 'thinking_symbol': thinking_symbol, 'chat_key': key, 'message': final_text}


def qc_raw(parser, command_token: str, *args: Any) -> dict:
    flat_args: list[Any] = []
    for item in args:
        if isinstance(item, (list, tuple)):
            flat_args.extend(item)
        else:
            flat_args.append(item)
    if not flat_args:
        raise QCallError('qc requires prompt')
    prompt = ' '.join(str(x) for x in flat_args).strip()
    if not prompt:
        raise QCallError('qc requires prompt')

    profile_name = resolve_profile_name(parser, command_token, 'qc')
    profile = get_profile(parser, profile_name)
    set_active_profile(parser, profile_name)
    effective = _base_effective_from_profile(parser, profile_name, profile)
    effective['expanded_prompt'] = expand_prompt_symbols(parser, prompt)
    payload = call_effective(effective, effective['expanded_prompt'], chat={})
    output = decode_qc_output(payload, profile.get('chat_message_tag'))
    return {'profile': profile_name, 'output': output, 'decoded': output.get('decoded')}


__all__ = [
    'resolve_active_q_root',
    'read_role_reference_from_active_q_root',
    'read_instance_q_overrides',
    'merge_effective_q_config',
    'resolve_effective_q_config',
    'prepare_q_session',
    'run_nonstream_session',
    'q_chat',
    'qc_raw',
]
