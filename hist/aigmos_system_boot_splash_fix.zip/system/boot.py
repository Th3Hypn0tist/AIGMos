from __future__ import annotations

from typing import Callable


GREETING_TEXT = """


   #    ###  #####  #     #
  # #    #  #     # ##   ##  ####   ####
 #   #   #  #       # # # # #    # #
#     #  #  #  #### #  #  # #    #  ####
#######  #  #     # #     # #    #      #
#     #  #  #     # #     # #    # #    #
#     # ###  #####  #     #  ####   ####

      The HGI Command Surface
"""


def boot_terminal_clear(state, flags) -> None:
    if isinstance(flags, dict):
        flags['boot_screen_clear'] = True


def boot_greeting(state, flags) -> None:
    if isinstance(flags, dict):
        flags['boot_greeting_text'] = GREETING_TEXT
        flags['boot_wait_for_key'] = True


BOOT_HOOKS: tuple[Callable[..., None], ...] = (
    boot_terminal_clear,
    boot_greeting,
)


def run_boot_hooks(state, flags) -> None:
    for hook in BOOT_HOOKS:
        hook(state, flags)
