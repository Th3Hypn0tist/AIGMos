"""table type placeholder."""
