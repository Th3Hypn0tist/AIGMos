from __future__ import annotations

from . import registry, terminal


class _CompatLayoutFacade:
    def __init__(self, ctx):
        self.ctx = ctx

    def read_input(self, _ctx=None):
        from .input import read_input
        return read_input(self.ctx)

    def handle_input(self, _ctx=None, command: str = ""):
        from .input import handle_input
        return handle_input(self.ctx, command)


def render(ctx, force: bool = False) -> str:
    registry.bootstrap(ctx)
    return terminal.render_now(ctx, lambda: registry.build_screen(ctx), force=force)


def render_layout(ctx, force: bool = False) -> str:
    return render(ctx, force=force)


def get_layout_name(ctx) -> str:
    registry.bootstrap(ctx)
    return registry.get_active_handle(ctx)


def get_layout_module(ctx):
    registry.bootstrap(ctx)
    return _CompatLayoutFacade(ctx)


def push_live_line(ctx, _text: str = "") -> None:
    from .ui_control import request_redraw
    registry.bootstrap(ctx)
    request_redraw(ctx, force=False)
