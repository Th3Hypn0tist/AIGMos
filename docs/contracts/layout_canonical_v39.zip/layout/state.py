from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

ACTIVE_KEY = "$SYSTEM:layout:active"
_RUNTIME_KEY = "layout_state"


def _runtime_store(ctx) -> dict[str, Any]:
    parser = ctx["parser"]
    runtime = parser.runtime.setdefault(_RUNTIME_KEY, {})
    runtime.setdefault("kv", {})
    runtime.setdefault("error_log", [])
    return runtime


def _state_obj(ctx):
    return ctx.get("state")


def _state_get(ctx, key: str) -> tuple[bool, Any]:
    state = _state_obj(ctx)
    if state is None or not hasattr(state, "get"):
        return False, None
    try:
        out = state.get(key)
    except Exception:
        return False, None
    if isinstance(out, dict):
        if out.get("error"):
            return False, None
        return True, out.get("result")
    return True, out


def _state_set(ctx, key: str, value: Any) -> bool:
    state = _state_obj(ctx)
    if state is None or not hasattr(state, "set"):
        return False
    try:
        out = state.set(key, value)
    except Exception:
        return False
    if isinstance(out, dict):
        return not bool(out.get("error"))
    return True


def _state_delete(ctx, key: str) -> bool:
    state = _state_obj(ctx)
    if state is None:
        return False
    for name in ("delete", "remove"):
        fn = getattr(state, name, None)
        if not callable(fn):
            continue
        try:
            out = fn(key)
        except Exception:
            return False
        if isinstance(out, dict):
            return not bool(out.get("error"))
        return True
    return False


def get_value(ctx, key: str, default: Any = None) -> Any:
    ok, value = _state_get(ctx, key)
    if ok:
        return default if value is None else value
    return _runtime_store(ctx)["kv"].get(key, default)


def set_value(ctx, key: str, value: Any) -> None:
    if _state_set(ctx, key, value):
        _runtime_store(ctx)["kv"][key] = value
        return
    _runtime_store(ctx)["kv"][key] = value


def delete_value(ctx, key: str) -> None:
    _state_delete(ctx, key)
    _runtime_store(ctx)["kv"].pop(key, None)


def meta_key(handle: str, field: str) -> str:
    return f"{str(handle).strip()}:{field}"


def get_active_handle(ctx, default: str = "¤BUFFER") -> str:
    value = get_value(ctx, ACTIVE_KEY, default)
    clean = str(value or default).strip()
    return clean or default


def set_active_handle(ctx, handle: str) -> None:
    set_value(ctx, ACTIVE_KEY, str(handle))


def set_meta(ctx, handle: str, field: str, value: Any) -> None:
    set_value(ctx, meta_key(handle, field), value)


def get_meta(ctx, handle: str, field: str, default: Any = None) -> Any:
    return get_value(ctx, meta_key(handle, field), default)


def clear_meta(ctx, handle: str, field: str) -> None:
    delete_value(ctx, meta_key(handle, field))


def set_instance_module(ctx, handle: str, module_name: str) -> None:
    set_meta(ctx, handle, "module", str(module_name or ""))


def set_title(ctx, handle: str, text: str) -> None:
    set_meta(ctx, handle, "title", str(text or ""))


def set_prompt(ctx, handle: str, text: str) -> None:
    set_meta(ctx, handle, "prompt", str(text or ""))


def set_status(ctx, handle: str, status: str) -> None:
    set_meta(ctx, handle, "status", str(status or ""))


def get_status(ctx, handle: str, default: str = "idle") -> str:
    return str(get_meta(ctx, handle, "status", default) or default)


def mark_dirty(ctx, handle: str) -> None:
    set_meta(ctx, handle, "dirty", "1")


def clear_dirty(ctx, handle: str) -> None:
    set_meta(ctx, handle, "dirty", "0")


def is_dirty(ctx, handle: str) -> bool:
    value = str(get_meta(ctx, handle, "dirty", "0")).strip().lower()
    return value in ("1", "true", "yes", "on")


def normalize_lines(value: Any) -> list[str]:
    if value is None:
        return []

    if isinstance(value, str):
        return value.splitlines()

    if isinstance(value, list):
        return [str(item) for item in value]

    if isinstance(value, dict):
        rows: list[tuple[int, str]] = []
        rest: list[tuple[str, str]] = []
        for key, item in value.items():
            try:
                rows.append((int(str(key)), str(item)))
            except Exception:
                rest.append((str(key), str(item)))
        rows.sort(key=lambda x: x[0])
        rest.sort(key=lambda x: x[0])
        return [item for _, item in rows] + [f"{k}: {v}" for k, v in rest]

    return [str(value)]


def stringify_payload(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload
    if isinstance(payload, (int, float, bool)):
        return str(payload)
    if isinstance(payload, list):
        return "\n".join(str(item) for item in payload)
    if isinstance(payload, dict):
        parts: list[str] = []
        numeric: list[tuple[int, str]] = []
        other: list[tuple[str, str]] = []
        for key, value in payload.items():
            try:
                numeric.append((int(str(key)), str(value)))
            except Exception:
                other.append((str(key), str(value)))
        numeric.sort(key=lambda x: x[0])
        other.sort(key=lambda x: x[0])
        parts.extend(item for _, item in numeric)
        parts.extend(f"{k}: {v}" for k, v in other)
        return "\n".join(parts)
    return str(payload)


def append_numeric_value(ctx, key: str, text: Any) -> None:
    clean = stringify_payload(text)
    current = get_value(ctx, key, None)

    if current is None:
        set_value(ctx, key, {"0": clean})
        return

    if isinstance(current, dict):
        next_index = 0
        for existing in current.keys():
            try:
                next_index = max(next_index, int(str(existing)) + 1)
            except Exception:
                continue
        payload = dict(current)
        payload[str(next_index)] = clean
        set_value(ctx, key, payload)
        return

    if isinstance(current, list):
        payload = list(current)
        payload.append(clean)
        set_value(ctx, key, payload)
        return

    if isinstance(current, str):
        if current:
            set_value(ctx, key, current + "\n" + clean)
        else:
            set_value(ctx, key, clean)
        return

    set_value(ctx, key, {"0": clean})


def clear_branch(ctx, key: str) -> None:
    delete_value(ctx, key)
    set_value(ctx, key, {})


def get_primary(ctx, handle: str) -> Any:
    from . import registry
    return get_value(ctx, registry.get_primary_target(ctx, handle), None)


def append_primary(ctx, handle: str, payload: Any) -> None:
    from . import registry
    append_numeric_value(ctx, registry.get_primary_target(ctx, handle), payload)
    mark_dirty(ctx, handle)


def clear_primary(ctx, handle: str) -> None:
    from . import registry
    key = registry.get_primary_target(ctx, handle)
    clear_branch(ctx, key)
    mark_dirty(ctx, handle)


def set_render_snapshot(ctx, handle: str, text: str) -> None:
    set_meta(ctx, handle, "render", str(text or ""))


def get_render_snapshot(ctx, handle: str, default: str = "") -> str:
    return str(get_meta(ctx, handle, "render", default) or default)


def timestamp_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def log_error(ctx, origin: str, reason: str, error: str = "error") -> None:
    line = f"{timestamp_utc()},{origin},{error},{reason}"
    append_numeric_value(ctx, "#SYSTEM:error:log", line)
    _runtime_store(ctx)["error_log"].append(line)
