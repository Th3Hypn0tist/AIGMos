from __future__ import annotations

import os
import select
import subprocess
import sys
import termios
import threading
import tty

_RUNTIME_KEY = "layout_terminal"


def _runtime(ctx) -> dict:
    parser = ctx["parser"]
    item = parser.runtime.get(_RUNTIME_KEY)
    if isinstance(item, dict):
        item.setdefault("lock", threading.RLock())
        item.setdefault("input_active", False)
        item.setdefault("line", "")
        item.setdefault("lines", [])
        item.setdefault("prompt", "")
        item.setdefault("hard_redraw_once", False)
        item.setdefault("ever_interacted", False)
        return item

    item = {
        "lock": threading.RLock(),
        "input_active": False,
        "line": "",
        "lines": [],
        "prompt": "",
        "hard_redraw_once": False,
        "ever_interacted": False,
    }
    parser.runtime[_RUNTIME_KEY] = item
    return item


def _terminal_clear_command() -> None:
    try:
        if os.name == "nt":
            subprocess.run(["cmd", "/c", "cls"], check=False)
        else:
            subprocess.run(["clear"], check=False)
    except Exception:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def _soft_clear_visible() -> None:
    sys.stdout.write("\033[H\033[J")
    sys.stdout.flush()


def _write_screen(lines: list[str], prompt: str, line: str, *, hard: bool = False) -> None:
    if hard:
        _terminal_clear_command()
    else:
        _soft_clear_visible()

    if lines:
        sys.stdout.write("\n".join(lines))
        sys.stdout.write("\n")
    sys.stdout.write(f"{prompt}{line}")
    sys.stdout.flush()


def _consume_hard_redraw(item: dict) -> bool:
    hard = bool(item.get("hard_redraw_once"))
    item["hard_redraw_once"] = False
    return hard


def _consume_force_render(ctx) -> bool:
    parser = ctx["parser"]
    flags = ctx.get("flags")

    should = bool(getattr(parser, "force_render", False))
    if isinstance(flags, dict):
        should = should or bool(flags.get("force_render"))

    if not should:
        return False

    parser.force_render = False
    if isinstance(flags, dict):
        flags["force_render"] = False
    return True


def queue_hard_redraw(ctx) -> None:
    item = _runtime(ctx)
    with item["lock"]:
        item["hard_redraw_once"] = True


def render_now(ctx, screen_provider, force: bool = False) -> str:
    lines, prompt = screen_provider()
    item = _runtime(ctx)
    with item["lock"]:
        item["lines"] = list(lines)
        item["prompt"] = str(prompt or "")
        hard = bool(force) or _consume_hard_redraw(item)
        _write_screen(item["lines"], item["prompt"], str(item.get("line") or ""), hard=hard)
    return str(prompt or "")


def request_redraw(ctx, screen_provider=None, *, force: bool = False) -> None:
    parser = ctx["parser"]
    parser.force_render = True
    flags = ctx.get("flags")
    if isinstance(flags, dict):
        flags["force_render"] = True
    if force:
        queue_hard_redraw(ctx)


def _read_char_posix(fd: int) -> str:
    data = os.read(fd, 1)
    if not data:
        return ""
    try:
        return data.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def _read_escape_tail_posix(fd: int) -> str:
    chars: list[str] = []
    while True:
        ready, _, _ = select.select([fd], [], [], 0.02)
        if not ready:
            break
        chars.append(_read_char_posix(fd))
        if len(chars) >= 8:
            break
    return "".join(chars)


def _normalize_escape_key(tail: str) -> str | None:
    if not tail:
        return "esc"
    if len(tail) == 1 and tail.isprintable():
        return f"alt+{tail.lower()}"
    if tail.startswith("[A"):
        return "up"
    if tail.startswith("[B"):
        return "down"
    if tail.startswith("[C"):
        return "right"
    if tail.startswith("[D"):
        return "left"
    if tail.startswith("[Z"):
        return "shift+tab"
    return None


def _normalize_control_key(ch: str) -> str | None:
    if ch == "\x0c":
        return "ctrl+l"
    if ch == "\t":
        return "tab"
    if ch in ("\x7f", "\b"):
        return "backspace"
    return None


def _redraw(item: dict, screen_provider, *, hard: bool = False) -> None:
    lines, prompt = screen_provider()
    with item["lock"]:
        item["lines"] = list(lines)
        item["prompt"] = str(prompt or "")
        hard = bool(hard) or _consume_hard_redraw(item)
        _write_screen(item["lines"], item["prompt"], str(item.get("line") or ""), hard=hard)


def _read_line_posix(ctx, screen_provider, key_dispatcher) -> str:
    item = _runtime(ctx)
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)

    try:
        tty.setcbreak(fd)
        lines, prompt = screen_provider()
        with item["lock"]:
            item["input_active"] = True
            item["line"] = ""
            item["lines"] = list(lines)
            item["prompt"] = str(prompt or "")
            item["hard_redraw_once"] = False

        while True:
            if _consume_force_render(ctx):
                with item["lock"]:
                    if bool(item.get("ever_interacted")):
                        _redraw(item, screen_provider, hard=False)

            ready, _, _ = select.select([fd], [], [], 0.05)
            if not ready:
                continue

            ch = _read_char_posix(fd)
            if ch == "":
                continue

            if ch in ("\r", "\n"):
                with item["lock"]:
                    item["ever_interacted"] = True
                    result = str(item.get("line") or "")
                    item["line"] = ""
                    item["input_active"] = False
                    item["hard_redraw_once"] = True
                return result

            if ch == "\x03":
                raise KeyboardInterrupt

            if ch == "\x1b":
                tail = _read_escape_tail_posix(fd)
                key = _normalize_escape_key(tail)
                with item["lock"]:
                    item["ever_interacted"] = True
                if key and key_dispatcher(ctx, key):
                    _redraw(item, screen_provider, hard=False)
                    continue
                if tail.startswith("[") or tail.startswith("O"):
                    continue
                _redraw(item, screen_provider, hard=False)
                continue

            key = _normalize_control_key(ch)
            if key == "backspace":
                with item["lock"]:
                    item["ever_interacted"] = True
                    current = str(item.get("line") or "")
                    item["line"] = current[:-1]
                _redraw(item, screen_provider, hard=False)
                continue

            if key:
                with item["lock"]:
                    item["ever_interacted"] = True
                if key_dispatcher(ctx, key):
                    _redraw(item, screen_provider, hard=False)
                    continue

            if ch.isprintable():
                with item["lock"]:
                    item["ever_interacted"] = True
                    item["line"] = str(item.get("line") or "") + ch
                _redraw(item, screen_provider, hard=False)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _read_line_fallback(ctx, screen_provider) -> str:
    render_now(ctx, screen_provider, force=True)
    try:
        return input(screen_provider()[1])
    finally:
        queue_hard_redraw(ctx)


def read_line(ctx, screen_provider, key_dispatcher) -> str:
    if os.name != "nt" and sys.stdin.isatty():
        return _read_line_posix(ctx, screen_provider, key_dispatcher)
    return _read_line_fallback(ctx, screen_provider)
