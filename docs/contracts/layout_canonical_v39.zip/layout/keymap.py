from __future__ import annotations

from typing import Any

SLOT_ORDER = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
COMMAND_PREFIX = "__AIGMOS_COMMAND__:"


def _runtime(ctx) -> dict[str, Any]:
    parser = ctx["parser"]
    runtime = parser.runtime.setdefault("layout_keymap", {})
    runtime.setdefault("global", {})
    return runtime


def normalize_key(key: str) -> str:
    raw = str(key or "").strip().lower()
    raw = raw.replace("ctrl-", "ctrl+").replace("alt-", "alt+").replace("shift-", "shift+")
    return raw


def normalize_slot(token: str) -> str:
    raw = str(token or "").strip().lower()
    if raw.startswith("alt+"):
        raw = raw[4:]
    elif raw.startswith("alt-"):
        raw = raw[4:]
    elif raw.startswith("alt") and len(raw) == 4 and raw[-1] in SLOT_ORDER:
        raw = raw[-1]
    if raw not in SLOT_ORDER:
        raise ValueError("slot must be alt-1..alt-9 or alt-0")
    return raw


def slot_label(slot: str) -> str:
    return f"alt-{normalize_slot(slot)}"


def state_symbol(slot: str) -> str:
    return f"#SYSTEM:keymap:alt:{normalize_slot(slot)}"


def _state_get_raw(state, symbol: str):
    out = state.get(symbol)
    if isinstance(out, dict):
        if out.get("error"):
            return None
        return out.get("result")
    return out


def get_binding(state, slot: str) -> str:
    value = _state_get_raw(state, state_symbol(slot))
    if value is None:
        return ""
    return str(value).strip()


def set_binding(state, slot: str, command: str) -> None:
    clean_slot = normalize_slot(slot)
    clean_command = str(command or "").strip()
    if not clean_command:
        raise ValueError("binding command cannot be empty")
    out = state.set(state_symbol(clean_slot), clean_command)
    if isinstance(out, dict) and out.get("error"):
        raise RuntimeError(out["error"])


def clear_binding(state, slot: str) -> None:
    clean_slot = normalize_slot(slot)
    out = state.delete(state_symbol(clean_slot))
    if isinstance(out, dict) and out.get("error"):
        raise RuntimeError(out["error"])


def list_bindings(state) -> dict[str, str]:
    out: dict[str, str] = {}
    for slot in SLOT_ORDER:
        value = get_binding(state, slot)
        if value:
            out[slot] = value
    return out


def dispatch_bound_command(state, slot: str) -> str:
    command = str(get_binding(state, slot) or "").strip()
    if not command:
        command = f"echo [unbound] {slot_label(slot)}"
    return COMMAND_PREFIX + command


def bind_global(ctx, key: str, action: Any) -> None:
    _runtime(ctx)["global"][normalize_key(key)] = action


def unbind_global(ctx, key: str) -> None:
    _runtime(ctx)["global"].pop(normalize_key(key), None)


def list_global(ctx) -> dict[str, Any]:
    return dict(_runtime(ctx)["global"])


def _compat_state_action(ctx, key: str) -> Any:
    normalized = normalize_key(key)
    if not normalized.startswith("alt+"):
        return None
    slot = normalized.split("+", 1)[1]
    if slot not in SLOT_ORDER:
        return None
    state = ctx.get("state")
    if state is None or not hasattr(state, "get"):
        return None
    value = _state_get_raw(state, state_symbol(slot))
    if value is None:
        return None
    clean = str(value).strip()
    return clean or None


def _execute_action(ctx, action: Any) -> bool:
    from . import registry
    from .ui_control import handle_ui_command, request_redraw

    if action is None:
        return False

    if callable(action):
        action(ctx)
        request_redraw(ctx, force=False)
        return True

    if isinstance(action, str):
        clean = action.strip()
        if not clean:
            return False
        if clean.startswith(COMMAND_PREFIX):
            clean = clean[len(COMMAND_PREFIX):].strip()
        if registry.has_instance(ctx, clean):
            registry.switch_active(ctx, clean)
            request_redraw(ctx, force=True)
            return True
        if clean.startswith("/") and handle_ui_command(ctx, clean):
            request_redraw(ctx, force=True)
            return True
        ctx["parser"].parse(clean)
        request_redraw(ctx, force=False)
        return True

    if isinstance(action, dict):
        kind = str(action.get("action") or "").strip().lower()

        if kind == "layout.switch":
            target = str(action.get("target") or "").strip()
            if target:
                try:
                    registry.ensure_instance(ctx, target)
                    if not target.startswith("¤"):
                        target = registry.route_to_handle(ctx, target)
                    registry.switch_active(ctx, target)
                    request_redraw(ctx, force=True)
                    return True
                except Exception:
                    return False
            return False

        if kind == "cs.parse":
            line = str(action.get("line") or "").strip()
            if not line:
                return False
            ctx["parser"].parse(line)
            request_redraw(ctx, force=False)
            return True

        if kind == "ui.command":
            line = str(action.get("line") or "").strip()
            if not line:
                return False
            handled = handle_ui_command(ctx, line)
            if handled:
                request_redraw(ctx, force=True)
            return handled

        if kind == "instance.input":
            line = str(action.get("line") or "").strip()
            if not line:
                return False
            result = registry.dispatch_input(ctx, line)
            if isinstance(result, dict) and result.get("mode") == "cs" and result.get("line"):
                ctx["parser"].parse(str(result["line"]))
            request_redraw(ctx, force=False)
            return True

    return False


def dispatch_key(ctx, key: str) -> bool:
    from . import registry
    normalized = normalize_key(key)

    global_action = _runtime(ctx)["global"].get(normalized)
    if _execute_action(ctx, global_action):
        return True

    compat_action = _compat_state_action(ctx, normalized)
    if _execute_action(ctx, compat_action):
        return True

    try:
        active = registry.get_active_handle(ctx)
        binds = registry.get_instance_keybinds(ctx, active)
    except Exception:
        return False

    action = binds.get(normalized)
    if _execute_action(ctx, action):
        return True

    instance = registry.get_instance(ctx, active)
    handler = getattr(instance, "handle_key", None)
    if callable(handler):
        result = handler(normalized)
        if isinstance(result, dict):
            mode = str(result.get("mode") or "none")
            if mode == "cs":
                line = str(result.get("line") or "").strip()
                if line:
                    ctx["parser"].parse(line)
                return True
            return mode != "none"
    return False
