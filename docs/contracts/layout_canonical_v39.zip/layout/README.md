# Canonical layout package v39

Highlights:
- one input surface
- active layout = `¤<STORAGE_PREFIX>[.<instance_suffix>]`
- one redraw path
- only the active `¤` instance determines what is painted
- module exports:
  - `STORAGE_PREFIX`
  - `PRIMARY_WRITE_FIELD`
- primary write target:
  - `¤Q -> $Q:ch`
  - `¤Q.llama -> $Q.llama:ch`
  - `¤BUFFER -> $BUFFER:history`
- cross-instance query writeback defaults to caller primary target

Bundled modules:
- `q`
- `buffer`

Compatibility:
- keeps `render_layout`, `get_layout_module`, `read_input`, `handle_input`
- keeps keymap exports like `SLOT_ORDER`
