from __future__ import annotations

from . import registry, terminal
from .keymap import dispatch_key
from .ui_control import handle_ui_command, request_redraw


def read_input(ctx) -> str:
    registry.bootstrap(ctx)
    return terminal.read_line(ctx, lambda: registry.build_screen(ctx), dispatch_key)


def handle_input(ctx, command: str) -> None:
    registry.bootstrap(ctx)
    line = str(command or "").strip()

    if not line:
        request_redraw(ctx, force=True)
        return

    if handle_ui_command(ctx, line):
        request_redraw(ctx, force=True)
        return

    result = registry.dispatch_input(ctx, line)
    if isinstance(result, dict):
        mode = str(result.get("mode") or "none")
        if mode == "cs":
            cs_line = str(result.get("line") or "").strip()
            if cs_line:
                ctx["parser"].parse(cs_line)

    request_redraw(ctx, force=False)
