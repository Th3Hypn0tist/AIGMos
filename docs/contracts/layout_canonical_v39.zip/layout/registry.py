from __future__ import annotations

import importlib
import pkgutil
from typing import Any

from . import state as layout_state


def _runtime(ctx) -> dict[str, Any]:
    parser = ctx["parser"]
    runtime = parser.runtime.setdefault("layout_registry", {})
    runtime.setdefault("bootstrapped", False)
    runtime.setdefault("modules", {})
    runtime.setdefault("instances", {})
    runtime.setdefault("module_order", [])
    return runtime


def _package_prefix() -> str:
    return f"{__package__}.modules"


def discover_module_names() -> list[str]:
    package = importlib.import_module(_package_prefix())
    names = [
        item.name
        for item in pkgutil.iter_modules(package.__path__)
        if not item.name.startswith("_")
    ]
    return sorted(set(names))


def load_module(ctx, name: str):
    runtime = _runtime(ctx)
    clean = str(name or "").strip().lower()
    if not clean:
        raise ValueError("module name cannot be empty")
    if clean in runtime["modules"]:
        return runtime["modules"][clean]

    module = importlib.import_module(f"{_package_prefix()}.{clean}")
    runtime["modules"][clean] = module
    if clean not in runtime["module_order"]:
        runtime["module_order"].append(clean)
    return module


def module_names(ctx) -> list[str]:
    bootstrap(ctx)
    return list(_runtime(ctx)["module_order"])


def _module_by_prefix(ctx, storage_prefix: str):
    clean = str(storage_prefix or "").strip().upper()
    if not clean:
        raise KeyError("storage prefix cannot be empty")
    for name in module_names(ctx):
        module = load_module(ctx, name)
        prefix = str(getattr(module, "STORAGE_PREFIX", "") or "").strip().upper()
        if prefix == clean:
            return module
    raise KeyError(f"unknown layout storage prefix: {clean}")


def split_handle(handle: str) -> tuple[str, str]:
    raw = str(handle or "").strip()
    if not raw.startswith("¤"):
        raise ValueError("layout handle must start with ¤")
    body = raw[1:].strip()
    if not body:
        raise ValueError("layout handle body cannot be empty")
    if "." in body:
        prefix, suffix = body.split(".", 1)
        prefix = prefix.strip()
        suffix = suffix.strip()
    else:
        prefix, suffix = body.strip(), ""
    if not prefix:
        raise ValueError("layout handle prefix cannot be empty")
    return prefix, suffix


def build_handle(storage_prefix: str, instance_suffix: str = "") -> str:
    prefix = str(storage_prefix or "").strip()
    suffix = str(instance_suffix or "").strip()
    if not prefix:
        raise ValueError("storage prefix cannot be empty")
    return f"¤{prefix}.{suffix}" if suffix else f"¤{prefix}"


def parse_route(route: str) -> tuple[str, str]:
    raw = str(route or "").strip()
    if raw.startswith("/"):
        raw = raw[1:]
    if not raw:
        raise ValueError("route cannot be empty")
    if "." in raw:
        module_name, alias = raw.split(".", 1)
        module_name = module_name.strip().lower()
        alias = alias.strip()
    else:
        module_name, alias = raw.strip().lower(), ""
    if not module_name:
        raise ValueError("route module cannot be empty")
    return module_name, alias


def handle_to_storage_root(handle: str) -> str:
    prefix, suffix = split_handle(handle)
    return f"${prefix}.{suffix}" if suffix else f"${prefix}"


def route_to_handle(ctx, route: str) -> str:
    module_name, alias = parse_route(route)
    module = load_module(ctx, module_name)
    prefix = str(getattr(module, "STORAGE_PREFIX", "") or "").strip()
    if not prefix:
        raise RuntimeError(f"layout module has no STORAGE_PREFIX: {module_name}")
    return build_handle(prefix, alias)


def route_to_module_and_handle(ctx, route: str) -> tuple[str, str]:
    module_name, alias = parse_route(route)
    module = load_module(ctx, module_name)
    prefix = str(getattr(module, "STORAGE_PREFIX", "") or "").strip()
    if not prefix:
        raise RuntimeError(f"layout module has no STORAGE_PREFIX: {module_name}")
    return module_name, build_handle(prefix, alias)


def _merge_default_config(module, config: dict[str, Any] | None) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    defaults = getattr(module, "DEFAULT_CONFIG", None)
    if isinstance(defaults, dict):
        payload.update(defaults)
    if isinstance(config, dict):
        payload.update(config)
    return payload


def _validate_handle_matches_module(module, handle: str) -> None:
    expected = str(getattr(module, "STORAGE_PREFIX", "") or "").strip()
    actual, _ = split_handle(handle)
    if not expected:
        raise RuntimeError(f"layout module has no STORAGE_PREFIX: {getattr(module, 'MODULE', '<unknown>')}")
    if actual != expected:
        raise ValueError(f"handle/module mismatch: {handle} != {expected}")


def create_instance(ctx, module_name: str, handle: str, config: dict[str, Any] | None = None, *, start: bool = True):
    runtime = _runtime(ctx)
    clean_handle = str(handle or "").strip()
    if not clean_handle:
        raise ValueError("layout handle cannot be empty")
    if clean_handle in runtime["instances"]:
        raise ValueError(f"instance exists: {clean_handle}")

    module = load_module(ctx, module_name)
    _validate_handle_matches_module(module, clean_handle)

    factory = getattr(module, "create_instance", None)
    if not callable(factory):
        raise RuntimeError(f"layout module has no create_instance(): {module_name}")

    merged = _merge_default_config(module, config)
    instance = factory(ctx, clean_handle, merged)
    runtime["instances"][clean_handle] = instance

    layout_state.set_instance_module(ctx, clean_handle, str(getattr(instance, "MODULE", module_name)))
    layout_state.set_title(ctx, clean_handle, str(instance.get_title() or ""))
    layout_state.set_prompt(ctx, clean_handle, str(instance.get_prompt() or "> "))
    layout_state.set_render_snapshot(ctx, clean_handle, str(instance.get_render() or ""))
    layout_state.set_status(ctx, clean_handle, "idle")
    layout_state.mark_dirty(ctx, clean_handle)

    if start:
        starter = getattr(instance, "start", None)
        if callable(starter):
            starter()
    return instance


def create_new(ctx, handle: str, route: str, config: dict[str, Any] | None = None, *, start: bool = True):
    module_name, resolved_handle = route_to_module_and_handle(ctx, route)
    clean_handle = str(handle or "").strip()
    if clean_handle != resolved_handle:
        raise ValueError(f"handle/route mismatch: {clean_handle} != {resolved_handle}")
    return create_instance(ctx, module_name, resolved_handle, config, start=start)


def ensure_instance(ctx, route_or_handle: str):
    raw = str(route_or_handle or "").strip()
    if not raw:
        raise ValueError("target cannot be empty")

    if raw.startswith("¤"):
        if has_instance(ctx, raw):
            return get_instance(ctx, raw)
        prefix, suffix = split_handle(raw)
        module = _module_by_prefix(ctx, prefix)
        return create_instance(ctx, str(getattr(module, "MODULE", "") or "").strip(), raw, {"instance_suffix": suffix}, start=True)

    module_name, handle = route_to_module_and_handle(ctx, raw)
    if has_instance(ctx, handle):
        return get_instance(ctx, handle)
    config: dict[str, Any] = {}
    _module_name, alias = parse_route(raw)
    if alias:
        config["instance_suffix"] = alias
    if module_name == "q":
        config["profile"] = alias or "default"
    return create_instance(ctx, module_name, handle, config, start=True)


def clone_instance(ctx, source_handle: str, new_handle: str):
    source = get_instance(ctx, source_handle)
    module = load_module(ctx, str(getattr(source, "MODULE", "")))
    _validate_handle_matches_module(module, new_handle)
    cloner = getattr(module, "clone_instance", None)
    if callable(cloner):
        instance = cloner(ctx, source, new_handle)
        _runtime(ctx)["instances"][new_handle] = instance
        layout_state.set_instance_module(ctx, new_handle, str(getattr(instance, "MODULE", getattr(source, "MODULE", ""))))
        layout_state.mark_dirty(ctx, new_handle)
        return instance
    return create_instance(ctx, str(getattr(source, "MODULE", "")), new_handle, dict(getattr(source, "config", {})), start=True)


def has_instance(ctx, handle: str) -> bool:
    return str(handle or "").strip() in _runtime(ctx)["instances"]


def get_instance(ctx, handle: str):
    clean = str(handle or "").strip()
    runtime = _runtime(ctx)
    if clean not in runtime["instances"]:
        raise KeyError(f"unknown layout instance: {clean}")
    return runtime["instances"][clean]


def list_instances(ctx) -> list[str]:
    return sorted(_runtime(ctx)["instances"].keys())


def switch_active(ctx, handle: str) -> None:
    clean = str(handle or "").strip()
    if not has_instance(ctx, clean):
        raise KeyError(f"unknown layout instance: {clean}")
    layout_state.set_active_handle(ctx, clean)


def _ensure_active_instance(ctx) -> str:
    active = layout_state.get_active_handle(ctx, "¤BUFFER")
    if has_instance(ctx, active):
        return active

    if active.startswith("¤"):
        prefix, suffix = split_handle(active)
        module = _module_by_prefix(ctx, prefix)
        module_name = str(getattr(module, "MODULE", "") or "").strip()
        config: dict[str, Any] = {"instance_suffix": suffix}
        if module_name == "q":
            config["profile"] = suffix or "default"
        create_instance(ctx, module_name, active, config, start=True)
        return active

    if not has_instance(ctx, "¤BUFFER"):
        create_instance(ctx, "buffer", "¤BUFFER", {"title": "BUFFER"}, start=True)
    layout_state.set_active_handle(ctx, "¤BUFFER")
    return "¤BUFFER"


def bootstrap(ctx) -> None:
    runtime = _runtime(ctx)
    if runtime["bootstrapped"]:
        return

    for name in discover_module_names():
        load_module(ctx, name)

    if not has_instance(ctx, "¤BUFFER"):
        create_instance(ctx, "buffer", "¤BUFFER", {"title": "BUFFER"}, start=True)

    _ensure_active_instance(ctx)
    runtime["bootstrapped"] = True


def get_active_instance_id(ctx) -> str:
    bootstrap(ctx)
    return _ensure_active_instance(ctx)


def get_active_handle(ctx) -> str:
    return get_active_instance_id(ctx)


def get_active_instance(ctx):
    return get_instance(ctx, get_active_instance_id(ctx))


def get_active_module(ctx):
    instance = get_active_instance(ctx)
    return load_module(ctx, str(getattr(instance, "MODULE", "")))


def get_primary_target(ctx, handle: str) -> str:
    instance = get_instance(ctx, handle)
    field = str(getattr(instance, "PRIMARY_WRITE_FIELD", "data") or "data").strip()
    return f"{handle_to_storage_root(handle)}:{field}"


def get_instance_keybinds(ctx, handle: str) -> dict[str, Any]:
    instance = get_instance(ctx, handle)

    getter = getattr(instance, "get_keybinds", None)
    if callable(getter):
        out = getter()
        if isinstance(out, dict):
            return out

    module = load_module(ctx, str(getattr(instance, "MODULE", "")))
    raw = getattr(module, "KEYBINDS", None)
    if isinstance(raw, dict):
        return dict(raw)
    return {}


def build_screen(ctx) -> tuple[list[str], str]:
    handle = get_active_instance_id(ctx)
    instance = get_instance(ctx, handle)

    title = str(instance.get_title() or handle)
    body = str(instance.get_render() or "")
    prompt = str(instance.get_prompt() or "> ")

    layout_state.set_title(ctx, handle, title)
    layout_state.set_prompt(ctx, handle, prompt)
    layout_state.set_render_snapshot(ctx, handle, body)
    layout_state.clear_dirty(ctx, handle)

    lines = [f"[{title}]"]
    if body:
        lines.extend(body.splitlines())
    return lines, prompt


def dispatch_input(ctx, line: str) -> dict[str, Any]:
    instance = get_active_instance(ctx)
    result = instance.handle_input(str(line))
    if not isinstance(result, dict):
        return {"mode": "none"}
    return result


def _default_writeback(ctx, caller_handle: str, payload: Any) -> None:
    layout_state.append_primary(ctx, caller_handle, payload)


def deliver_instance_response(ctx, caller_handle: str, source_handle: str, payload: Any) -> None:
    caller = get_instance(ctx, caller_handle)
    handler = getattr(caller, "on_response", None)
    if callable(handler):
        handler(str(source_handle), payload)
    else:
        _default_writeback(ctx, caller_handle, payload)
    layout_state.mark_dirty(ctx, caller_handle)


def query_instance(ctx, caller_handle: str, target_handle: str, payload: Any) -> Any:
    bootstrap(ctx)
    caller_clean = str(caller_handle or "").strip()
    target_clean = str(target_handle or "").strip()
    if not has_instance(ctx, caller_clean):
        raise KeyError(f"unknown caller instance: {caller_clean}")
    if not has_instance(ctx, target_clean):
        raise KeyError(f"unknown target instance: {target_clean}")

    target = get_instance(ctx, target_clean)
    handler = getattr(target, "on_query", None)
    response = handler(caller_clean, payload) if callable(handler) else payload
    deliver_instance_response(ctx, caller_clean, target_clean, response)

    from .ui_control import request_redraw
    request_redraw(ctx, force=False)
    return response
