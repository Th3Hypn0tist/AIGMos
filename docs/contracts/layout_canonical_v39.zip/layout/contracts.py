from __future__ import annotations

from typing import Any


def dispatch_self() -> dict[str, Any]:
    return {"mode": "self"}


def dispatch_none() -> dict[str, Any]:
    return {"mode": "none"}


def dispatch_cs(line: str) -> dict[str, Any]:
    return {"mode": "cs", "line": str(line or "").strip()}


class LayoutInstance:
    """
    Canonical layout-instance base.

    Required module exports:
    - MODULE
    - TITLE
    - STORAGE_PREFIX
    - PRIMARY_WRITE_FIELD
    - create_instance(ctx, handle, config=None)

    Required instance methods:
    - get_title()
    - get_prompt()
    - get_render()
    - handle_input(line)

    Optional:
    - handle_key(key)
    - start()
    - stop()
    - serialize()
    - restore(payload)
    - query(target_handle, payload)
    - on_query(source_handle, payload)
    - on_response(source_handle, payload)
    """

    MODULE = "base"
    TITLE = "BASE"
    STORAGE_PREFIX = "BASE"
    PRIMARY_WRITE_FIELD = "data"

    def __init__(self, ctx, handle: str, config: dict[str, Any] | None = None):
        self.ctx = ctx
        self.handle = str(handle)
        self.config = dict(config or {})

    @property
    def storage_root(self) -> str:
        from . import registry
        return registry.handle_to_storage_root(self.handle)

    @property
    def primary_target(self) -> str:
        return f"{self.storage_root}:{self.PRIMARY_WRITE_FIELD}"

    @property
    def primary_write_target(self) -> str:
        return self.primary_target

    @property
    def instance_suffix(self) -> str:
        from . import registry
        _, suffix = registry.split_handle(self.handle)
        return suffix

    def get_title(self) -> str:
        explicit = str(self.config.get("title") or "").strip()
        if explicit:
            return explicit
        return str(self.TITLE or self.STORAGE_PREFIX)

    def get_prompt(self) -> str:
        explicit = str(self.config.get("prompt") or "").strip()
        if explicit:
            return explicit
        return "> "

    def get_render(self) -> str:
        from . import state as layout_state
        return "\n".join(layout_state.normalize_lines(layout_state.get_primary(self.ctx, self.handle)))

    def handle_input(self, line: str) -> dict[str, Any]:
        return dispatch_none()

    def handle_key(self, key: str) -> dict[str, Any]:
        return dispatch_none()

    def start(self) -> None:
        return None

    def stop(self) -> None:
        return None

    def serialize(self) -> dict[str, Any]:
        return {
            "module": str(self.MODULE),
            "handle": self.handle,
            "config": dict(self.config),
        }

    def restore(self, payload: dict[str, Any] | None) -> None:
        if not isinstance(payload, dict):
            return
        config = payload.get("config")
        if isinstance(config, dict):
            self.config.update(config)

    def query(self, target_handle: str, payload: Any) -> Any:
        from .registry import query_instance
        return query_instance(self.ctx, self.handle, str(target_handle), payload)

    def on_query(self, source_handle: str, payload: Any) -> Any:
        return payload

    def on_response(self, source_handle: str, payload: Any) -> None:
        from . import state as layout_state
        layout_state.append_primary(self.ctx, self.handle, payload)
