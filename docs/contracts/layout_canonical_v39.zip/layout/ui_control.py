from __future__ import annotations

from . import registry


def force_render(ctx) -> None:
    parser = ctx["parser"]
    parser.force_render = True
    flags = ctx.get("flags")
    if isinstance(flags, dict):
        flags["force_render"] = True


def request_redraw(ctx, *, force: bool = False) -> None:
    from . import terminal

    if force:
        terminal.queue_hard_redraw(ctx)
    force_render(ctx)


def _switch_or_create(ctx, route_or_handle: str) -> str:
    instance = registry.ensure_instance(ctx, route_or_handle)
    handle = getattr(instance, "handle", str(route_or_handle))
    registry.switch_active(ctx, handle)
    return str(handle)


def handle_ui_command(ctx, line: str) -> bool:
    raw = str(line or "").strip()
    if not raw.startswith("/"):
        return False

    parts = raw.split()
    token = parts[0].strip()

    if token.lower() in ("/quit", "/exit") and len(parts) == 1:
        parser = ctx["parser"]
        flags = ctx.get("flags")
        if isinstance(flags, dict):
            flags["running"] = False
            flags["force_render"] = True
        parser.runtime["quit_requested"] = True
        return True

    if token.lower() == "/buffer" and len(parts) == 1:
        _switch_or_create(ctx, "/buffer")
        return True

    if token.lower().startswith("/buffer.") and len(parts) == 1:
        _switch_or_create(ctx, token)
        return True

    if token.lower() == "/q" and len(parts) == 1:
        _switch_or_create(ctx, "/q")
        return True

    if token.lower().startswith("/q.") and len(parts) == 1:
        _switch_or_create(ctx, token)
        return True

    if token.lower().startswith("/editor") and len(parts) == 1:
        _switch_or_create(ctx, token)
        return True

    if token.lower() == "/layout" and len(parts) == 2:
        target = str(parts[1]).strip()
        _switch_or_create(ctx, target)
        return True

    if token.lower() == "/layout.active" and len(parts) == 1:
        return True

    if token.lower() == "/layout.reload" and len(parts) == 1:
        ctx["parser"].runtime.pop("layout_registry", None)
        registry.bootstrap(ctx)
        return True

    return False
