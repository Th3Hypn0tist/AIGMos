from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

from ..contracts import LayoutInstance, dispatch_cs, dispatch_none, dispatch_self
from .. import state as layout_state
from ..ui_control import request_redraw

MODULE = "q"
TITLE = "Q"
STORAGE_PREFIX = "Q"
PRIMARY_WRITE_FIELD = "ch"

DEFAULT_CONFIG = {
    "profile": "default",
    "title": "Q",
}

CONFIG_SCHEMA = {
    "profile": "string",
    "title": "string?",
    "chat_symbol": "string?",
    "prompt": "string?",
    "instance_suffix": "string?",
}

KEYBINDS = {}

try:
    from system.cs.lib.qcall import (  # type: ignore
        QCallError,
        q_chat,
        set_active_profile,
        system_prompt_symbol_for_profile,
    )
except Exception:  # pragma: no cover
    QCallError = RuntimeError  # type: ignore
    q_chat = None
    set_active_profile = None
    system_prompt_symbol_for_profile = None

_ROLES_DIR = Path(__file__).resolve().parents[2] / "prompts" / "roles"


class QInstance(LayoutInstance):
    MODULE = MODULE
    TITLE = TITLE
    STORAGE_PREFIX = STORAGE_PREFIX
    PRIMARY_WRITE_FIELD = PRIMARY_WRITE_FIELD

    def __init__(self, ctx, handle: str, config: dict[str, Any] | None = None):
        super().__init__(ctx, handle, config)
        self._lock = threading.RLock()
        self._busy = False
        self._notice = ""
        self._stream_open = False
        self._pending_prompt = ""
        self._pending_text = ""
        self._pending_display_index = 0

    @property
    def profile(self) -> str:
        raw = str(self.config.get("profile") or "").strip()
        if raw:
            return raw
        suffix = self.instance_suffix
        return suffix or "default"

    def get_title(self) -> str:
        explicit = str(self.config.get("title") or "").strip()
        if explicit and explicit != "Q":
            return explicit
        return "Q" if self.profile == "default" else f"Q[{self.profile}]"

    def get_prompt(self) -> str:
        explicit = str(self.config.get("prompt") or "").strip()
        if explicit:
            return explicit
        return "q> " if self.profile == "default" else f"q.{self.profile}> "

    def _fmt_idx(self, idx: int) -> str:
        return f"{idx:05d}"

    def _row_count(self) -> int:
        current = layout_state.get_primary(self.ctx, self.handle)
        if isinstance(current, dict):
            return len(current)
        return len(layout_state.normalize_lines(current)) // 2

    def _append_exchange(self, prompt_text: str, response_text: str) -> None:
        idx = self._row_count()
        tag = self._fmt_idx(idx)
        layout_state.append_primary(self.ctx, self.handle, f"[{tag}] q> {prompt_text}")
        layout_state.append_primary(self.ctx, self.handle, f"[{tag}] a> {response_text}")

    def _read_role_prompt(self, role_value: str) -> str:
        value = str(role_value or "").strip()
        if not value:
            return ""
        if "\n" in value:
            return value

        candidates: list[Path] = []
        if value.endswith(".md"):
            candidates.append(_ROLES_DIR / value)
        else:
            candidates.append(_ROLES_DIR / f"{value}.md")
            candidates.append(_ROLES_DIR / value)

        for path in candidates:
            if path.is_file():
                return path.read_text(encoding="utf-8").strip()

        return value

    def _apply_role_system_prompt(self) -> None:
        if system_prompt_symbol_for_profile is None:
            return

        profile = self.profile
        symbols = [f"#SYSTEM:config:q:{profile}:role"]
        if profile != "default":
            symbols.append("#SYSTEM:config:q:default:role")

        role_value = ""
        for symbol in symbols:
            value = layout_state.get_value(self.ctx, symbol, "")
            if isinstance(value, str) and value.strip():
                role_value = value.strip()
                break

        if not role_value:
            return

        system_prompt = self._read_role_prompt(role_value)
        target = system_prompt_symbol_for_profile(profile)
        layout_state.set_value(self.ctx, target, system_prompt)

    def _open_stream(self, prompt_text: str) -> None:
        with self._lock:
            self._stream_open = True
            self._pending_prompt = str(prompt_text or "")
            self._pending_text = ""
            self._pending_display_index = self._row_count()
        layout_state.mark_dirty(self.ctx, self.handle)
        request_redraw(self.ctx, force=False)

    def _append_stream(self, text: str) -> None:
        with self._lock:
            self._pending_text = str(text or "")
        layout_state.mark_dirty(self.ctx, self.handle)
        request_redraw(self.ctx, force=False)

    def _close_stream(self) -> None:
        with self._lock:
            self._stream_open = False
            self._pending_prompt = ""
            self._pending_text = ""
            self._pending_display_index = 0
        layout_state.mark_dirty(self.ctx, self.handle)
        request_redraw(self.ctx, force=False)

    def get_render(self) -> str:
        lines = layout_state.normalize_lines(layout_state.get_primary(self.ctx, self.handle))
        out: list[str] = []
        if self._notice:
            out.append(self._notice)
        out.extend(lines)

        if self._stream_open:
            tag = self._fmt_idx(int(self._pending_display_index or 0))
            if out:
                # no extra blank line
                pass
            out.append(f"[{tag}] q> {self._pending_prompt}")
            out.append(f"[{tag}] a> {self._pending_text}")

        return "\n".join(out)

    def _run_q_request(self, prompt_text: str) -> None:
        parser = self.ctx["parser"]
        profile = self.profile
        final_text = ""

        old_buffer_suppress = parser.runtime.get("buffer_suppress", False)
        parser.runtime["buffer_suppress"] = True

        try:
            layout_state.set_status(self.ctx, self.handle, "run")
            if callable(set_active_profile):
                set_active_profile(parser, profile)
            self._apply_role_system_prompt()

            command_token = "q" if profile == "default" else f"q.{profile}"

            def _on_chunk(_chunk: str, full_text: str, _chat_symbol: str, _key: str) -> None:
                nonlocal final_text
                final_text = str(full_text or "")
                self._append_stream(final_text)

            def _on_done(full_text: str, _chat_symbol: str, _key: str) -> None:
                nonlocal final_text
                final_text = str(full_text or "")
                self._append_stream(final_text)

            if not callable(q_chat):
                raise RuntimeError("qcall unavailable")

            out = q_chat(
                parser,
                command_token,
                prompt_text,
                on_chunk=_on_chunk,
                on_done=_on_done,
            )

            returned_text = str((out or {}).get("message") or "")
            if len(returned_text) > len(final_text):
                final_text = returned_text

            self._append_exchange(prompt_text, final_text)
            self._notice = ""
            layout_state.set_status(self.ctx, self.handle, "ok")

        except QCallError as exc:  # type: ignore[misc]
            self._notice = f"[error] {exc}"
            layout_state.set_status(self.ctx, self.handle, "error")
            layout_state.log_error(self.ctx, self.handle, str(exc), error="ERR_RUNTIME")
        except Exception as exc:
            self._notice = f"[error] {exc}"
            layout_state.set_status(self.ctx, self.handle, "error")
            layout_state.log_error(self.ctx, self.handle, str(exc), error="ERR_RUNTIME")
        finally:
            parser.runtime["buffer_suppress"] = old_buffer_suppress
            with self._lock:
                self._busy = False
            self._close_stream()
            request_redraw(self.ctx, force=False)

    def handle_input(self, line: str) -> dict[str, Any]:
        clean = str(line or "").strip()
        if not clean:
            return dispatch_none()

        if clean.lower().startswith("cs "):
            return dispatch_cs(clean[3:].strip())

        with self._lock:
            if self._busy:
                self._notice = "[busy] q request already in flight"
                layout_state.mark_dirty(self.ctx, self.handle)
                return dispatch_self()
            self._busy = True

        self._notice = ""
        self._open_stream(clean)
        thread = threading.Thread(
            target=self._run_q_request,
            args=(clean,),
            daemon=True,
            name=f"aigmos-layout-q-{self.handle}",
        )
        thread.start()
        return dispatch_self()

    def serialize(self) -> dict[str, Any]:
        payload = super().serialize()
        payload["notice"] = self._notice
        return payload

    def restore(self, payload: dict[str, Any] | None) -> None:
        super().restore(payload)
        if not isinstance(payload, dict):
            return
        self._notice = str(payload.get("notice") or "")


def create_instance(ctx, handle: str, config: dict[str, Any] | None = None):
    return QInstance(ctx, handle, config)


def clone_instance(ctx, src_instance, new_handle: str):
    payload = src_instance.serialize() if hasattr(src_instance, "serialize") else {"config": dict(getattr(src_instance, "config", {}))}
    instance = QInstance(ctx, new_handle, dict(getattr(src_instance, "config", {})))
    instance.restore(payload)
    return instance
