from __future__ import annotations

from typing import Any

from ..contracts import LayoutInstance, dispatch_none, dispatch_self
from .. import state as layout_state

MODULE = "editor"
TITLE = "EDITOR"
STORAGE_PREFIX = "EDITOR"
PRIMARY_WRITE_FIELD = "content"

DEFAULT_CONFIG = {
    "title": "EDITOR",
}

CONFIG_SCHEMA = {
    "title": "string?",
    "prompt": "string?",
    "instance_suffix": "string?",
}

KEYBINDS = {}


class EditorInstance(LayoutInstance):
    MODULE = MODULE
    TITLE = TITLE
    STORAGE_PREFIX = STORAGE_PREFIX
    PRIMARY_WRITE_FIELD = PRIMARY_WRITE_FIELD

    def get_title(self) -> str:
        explicit = str(self.config.get("title") or "").strip()
        if explicit:
            return explicit
        suffix = self.instance_suffix
        return "EDITOR" if not suffix else f"EDITOR[{suffix}]"

    def get_prompt(self) -> str:
        explicit = str(self.config.get("prompt") or "").strip()
        if explicit:
            return explicit
        suffix = self.instance_suffix
        return "editor> " if not suffix else f"editor.{suffix}> "

    def get_render(self) -> str:
        return "\n".join(layout_state.normalize_lines(layout_state.get_primary(self.ctx, self.handle)))

    def handle_input(self, line: str) -> dict[str, Any]:
        clean = str(line or "")
        layout_state.append_primary(self.ctx, self.handle, clean)
        return dispatch_self()

    def handle_key(self, key: str) -> dict[str, Any]:
        if str(key).lower() != "ctrl+l":
            return dispatch_none()
        layout_state.clear_primary(self.ctx, self.handle)
        return dispatch_self()


def create_instance(ctx, handle: str, config: dict[str, Any] | None = None):
    return EditorInstance(ctx, handle, config)


def clone_instance(ctx, src_instance, new_handle: str):
    payload = src_instance.serialize() if hasattr(src_instance, "serialize") else {"config": dict(getattr(src_instance, "config", {}))}
    instance = EditorInstance(ctx, new_handle, dict(getattr(src_instance, "config", {})))
    instance.restore(payload)
    return instance
