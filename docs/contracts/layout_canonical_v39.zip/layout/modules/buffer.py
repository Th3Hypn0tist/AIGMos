from __future__ import annotations

import threading
from typing import Any

from ..contracts import LayoutInstance, dispatch_none, dispatch_self
from .. import state as layout_state
from ..ui_control import request_redraw

MODULE = "buffer"
TITLE = "BUFFER"
STORAGE_PREFIX = "BUFFER"
PRIMARY_WRITE_FIELD = "history"

DEFAULT_CONFIG = {
    "title": "BUFFER",
    "prompt": "cs> ",
}

CONFIG_SCHEMA = {
    "title": "string?",
    "prompt": "string?",
    "instance_suffix": "string?",
}

KEYBINDS = {}


class BufferInstance(LayoutInstance):
    MODULE = MODULE
    TITLE = TITLE
    STORAGE_PREFIX = STORAGE_PREFIX
    PRIMARY_WRITE_FIELD = PRIMARY_WRITE_FIELD

    def __init__(self, ctx, handle: str, config: dict[str, Any] | None = None):
        super().__init__(ctx, handle, config)
        self._lock = threading.RLock()
        self._busy = False
        self._notice = ""

    def get_title(self) -> str:
        explicit = str(self.config.get("title") or "").strip()
        if explicit:
            return explicit
        suffix = self.instance_suffix
        return "BUFFER" if not suffix else f"BUFFER[{suffix}]"

    def get_prompt(self) -> str:
        explicit = str(self.config.get("prompt") or "").strip()
        if explicit:
            return explicit
        suffix = self.instance_suffix
        return "cs> " if not suffix else f"cs.{suffix}> "

    def _append_history_line(self, text: str) -> None:
        layout_state.append_primary(self.ctx, self.handle, str(text or ""))

    def get_render(self) -> str:
        lines: list[str] = []
        if self._notice:
            lines.append(self._notice)

        primary = layout_state.normalize_lines(layout_state.get_primary(self.ctx, self.handle))
        compat = layout_state.normalize_lines(layout_state.get_value(self.ctx, "$SYSTEM.BUFFER", None))

        if primary:
            lines.extend(primary)
        elif compat:
            lines.extend(compat)

        return "\n".join(lines)

    def _run_command(self, line: str) -> None:
        try:
            layout_state.set_status(self.ctx, self.handle, "run")
            self.ctx["parser"].parse(line)
            layout_state.set_status(self.ctx, self.handle, "ok")
        except Exception as exc:
            self._notice = f"[error] {exc}"
            layout_state.set_status(self.ctx, self.handle, "error")
            layout_state.log_error(self.ctx, self.handle, str(exc), error="ERR_RUNTIME")
        finally:
            with self._lock:
                self._busy = False
            request_redraw(self.ctx, force=False)

    def handle_input(self, line: str) -> dict[str, Any]:
        clean = str(line or "").strip()
        if not clean:
            return dispatch_none()

        with self._lock:
            if self._busy:
                self._notice = "[busy] command already in flight"
                layout_state.mark_dirty(self.ctx, self.handle)
                return dispatch_self()
            self._busy = True

        self._notice = ""
        self._append_history_line(f"cs> {clean}")
        self._append_history_line("")
        thread = threading.Thread(
            target=self._run_command,
            args=(clean,),
            daemon=True,
            name=f"aigmos-layout-buffer-{self.handle}",
        )
        thread.start()
        return dispatch_self()

    def handle_key(self, key: str) -> dict[str, Any]:
        if str(key).lower() != "ctrl+l":
            return dispatch_none()
        self._notice = ""
        layout_state.clear_primary(self.ctx, self.handle)
        layout_state.mark_dirty(self.ctx, self.handle)
        return dispatch_self()

    def serialize(self) -> dict[str, Any]:
        payload = super().serialize()
        payload["notice"] = self._notice
        return payload

    def restore(self, payload: dict[str, Any] | None) -> None:
        super().restore(payload)
        if not isinstance(payload, dict):
            return
        self._notice = str(payload.get("notice") or "")


def create_instance(ctx, handle: str, config: dict[str, Any] | None = None):
    return BufferInstance(ctx, handle, config)


def clone_instance(ctx, src_instance, new_handle: str):
    payload = src_instance.serialize() if hasattr(src_instance, "serialize") else {"config": dict(getattr(src_instance, "config", {}))}
    instance = BufferInstance(ctx, new_handle, dict(getattr(src_instance, "config", {})))
    instance.restore(payload)
    return instance
